
INSERT INTO contact_type (id)
    VALUES (1);


INSERT INTO country (id,code)
    VALUES (1,'AF');


INSERT INTO country (id,code)
    VALUES (2,'AL');


INSERT INTO country (id,code)
    VALUES (3,'DZ');


INSERT INTO country (id,code)
    VALUES (4,'AS');


INSERT INTO country (id,code)
    VALUES (5,'AD');


INSERT INTO country (id,code)
    VALUES (6,'AO');


INSERT INTO country (id,code)
    VALUES (7,'AI');


INSERT INTO country (id,code)
    VALUES (8,'AQ');


INSERT INTO country (id,code)
    VALUES (9,'AG');


INSERT INTO country (id,code)
    VALUES (10,'AR');


INSERT INTO country (id,code)
    VALUES (11,'AM');


INSERT INTO country (id,code)
    VALUES (12,'AW');


INSERT INTO country (id,code)
    VALUES (13,'AU');


INSERT INTO country (id,code)
    VALUES (14,'AT');


INSERT INTO country (id,code)
    VALUES (15,'AZ');


INSERT INTO country (id,code)
    VALUES (16,'BS');


INSERT INTO country (id,code)
    VALUES (17,'BH');


INSERT INTO country (id,code)
    VALUES (18,'BD');


INSERT INTO country (id,code)
    VALUES (19,'BB');


INSERT INTO country (id,code)
    VALUES (20,'BY');


INSERT INTO country (id,code)
    VALUES (21,'BE');


INSERT INTO country (id,code)
    VALUES (22,'BZ');


INSERT INTO country (id,code)
    VALUES (23,'BJ');


INSERT INTO country (id,code)
    VALUES (24,'BM');


INSERT INTO country (id,code)
    VALUES (25,'BT');


INSERT INTO country (id,code)
    VALUES (26,'BO');


INSERT INTO country (id,code)
    VALUES (27,'BA');


INSERT INTO country (id,code)
    VALUES (28,'BW');


INSERT INTO country (id,code)
    VALUES (29,'BV');


INSERT INTO country (id,code)
    VALUES (30,'BR');


INSERT INTO country (id,code)
    VALUES (31,'IO');


INSERT INTO country (id,code)
    VALUES (32,'BN');


INSERT INTO country (id,code)
    VALUES (33,'BG');


INSERT INTO country (id,code)
    VALUES (34,'BF');


INSERT INTO country (id,code)
    VALUES (35,'BI');


INSERT INTO country (id,code)
    VALUES (36,'KH');


INSERT INTO country (id,code)
    VALUES (37,'CM');


INSERT INTO country (id,code)
    VALUES (38,'CA');


INSERT INTO country (id,code)
    VALUES (39,'CV');


INSERT INTO country (id,code)
    VALUES (40,'KY');


INSERT INTO country (id,code)
    VALUES (41,'CF');


INSERT INTO country (id,code)
    VALUES (42,'TD');


INSERT INTO country (id,code)
    VALUES (43,'CL');


INSERT INTO country (id,code)
    VALUES (44,'CN');


INSERT INTO country (id,code)
    VALUES (45,'CX');


INSERT INTO country (id,code)
    VALUES (46,'CC');


INSERT INTO country (id,code)
    VALUES (47,'CO');


INSERT INTO country (id,code)
    VALUES (48,'KM');


INSERT INTO country (id,code)
    VALUES (49,'CG');


INSERT INTO country (id,code)
    VALUES (50,'CK');


INSERT INTO country (id,code)
    VALUES (51,'CR');


INSERT INTO country (id,code)
    VALUES (52,'CI');


INSERT INTO country (id,code)
    VALUES (53,'HR');


INSERT INTO country (id,code)
    VALUES (54,'CU');


INSERT INTO country (id,code)
    VALUES (55,'CY');


INSERT INTO country (id,code)
    VALUES (56,'CZ');


INSERT INTO country (id,code)
    VALUES (57,'CD');


INSERT INTO country (id,code)
    VALUES (58,'DK');


INSERT INTO country (id,code)
    VALUES (59,'DJ');


INSERT INTO country (id,code)
    VALUES (60,'DM');


INSERT INTO country (id,code)
    VALUES (61,'DO');


INSERT INTO country (id,code)
    VALUES (62,'TP');


INSERT INTO country (id,code)
    VALUES (63,'EC');


INSERT INTO country (id,code)
    VALUES (64,'EG');


INSERT INTO country (id,code)
    VALUES (65,'SV');


INSERT INTO country (id,code)
    VALUES (66,'GQ');


INSERT INTO country (id,code)
    VALUES (67,'ER');


INSERT INTO country (id,code)
    VALUES (68,'EE');


INSERT INTO country (id,code)
    VALUES (69,'ET');


INSERT INTO country (id,code)
    VALUES (70,'FK');


INSERT INTO country (id,code)
    VALUES (71,'FO');


INSERT INTO country (id,code)
    VALUES (72,'FJ');


INSERT INTO country (id,code)
    VALUES (73,'FI');


INSERT INTO country (id,code)
    VALUES (74,'FR');


INSERT INTO country (id,code)
    VALUES (75,'GF');


INSERT INTO country (id,code)
    VALUES (76,'PF');


INSERT INTO country (id,code)
    VALUES (77,'TF');


INSERT INTO country (id,code)
    VALUES (78,'GA');


INSERT INTO country (id,code)
    VALUES (79,'GM');


INSERT INTO country (id,code)
    VALUES (80,'GE');


INSERT INTO country (id,code)
    VALUES (81,'DE');


INSERT INTO country (id,code)
    VALUES (82,'GH');


INSERT INTO country (id,code)
    VALUES (83,'GI');


INSERT INTO country (id,code)
    VALUES (84,'GR');


INSERT INTO country (id,code)
    VALUES (85,'GL');


INSERT INTO country (id,code)
    VALUES (86,'GD');


INSERT INTO country (id,code)
    VALUES (87,'GP');


INSERT INTO country (id,code)
    VALUES (88,'GU');


INSERT INTO country (id,code)
    VALUES (89,'GT');


INSERT INTO country (id,code)
    VALUES (90,'GN');


INSERT INTO country (id,code)
    VALUES (91,'GW');


INSERT INTO country (id,code)
    VALUES (92,'GY');


INSERT INTO country (id,code)
    VALUES (93,'HT');


INSERT INTO country (id,code)
    VALUES (94,'HM');


INSERT INTO country (id,code)
    VALUES (95,'HN');


INSERT INTO country (id,code)
    VALUES (96,'HK');


INSERT INTO country (id,code)
    VALUES (97,'HU');


INSERT INTO country (id,code)
    VALUES (98,'IS');


INSERT INTO country (id,code)
    VALUES (99,'IN');


INSERT INTO country (id,code)
    VALUES (100,'ID');


INSERT INTO country (id,code)
    VALUES (101,'IR');


INSERT INTO country (id,code)
    VALUES (102,'IQ');


INSERT INTO country (id,code)
    VALUES (103,'IE');


INSERT INTO country (id,code)
    VALUES (104,'IL');


INSERT INTO country (id,code)
    VALUES (105,'IT');


INSERT INTO country (id,code)
    VALUES (106,'JM');


INSERT INTO country (id,code)
    VALUES (107,'JP');


INSERT INTO country (id,code)
    VALUES (108,'JO');


INSERT INTO country (id,code)
    VALUES (109,'KZ');


INSERT INTO country (id,code)
    VALUES (110,'KE');


INSERT INTO country (id,code)
    VALUES (111,'KI');


INSERT INTO country (id,code)
    VALUES (112,'KR');


INSERT INTO country (id,code)
    VALUES (113,'KW');


INSERT INTO country (id,code)
    VALUES (114,'KG');


INSERT INTO country (id,code)
    VALUES (115,'LA');


INSERT INTO country (id,code)
    VALUES (116,'LV');


INSERT INTO country (id,code)
    VALUES (117,'LB');


INSERT INTO country (id,code)
    VALUES (118,'LS');


INSERT INTO country (id,code)
    VALUES (119,'LR');


INSERT INTO country (id,code)
    VALUES (120,'LY');


INSERT INTO country (id,code)
    VALUES (121,'LI');


INSERT INTO country (id,code)
    VALUES (122,'LT');


INSERT INTO country (id,code)
    VALUES (123,'LU');


INSERT INTO country (id,code)
    VALUES (124,'MO');


INSERT INTO country (id,code)
    VALUES (125,'MK');


INSERT INTO country (id,code)
    VALUES (126,'MG');


INSERT INTO country (id,code)
    VALUES (127,'MW');


INSERT INTO country (id,code)
    VALUES (128,'MY');


INSERT INTO country (id,code)
    VALUES (129,'MV');


INSERT INTO country (id,code)
    VALUES (130,'ML');


INSERT INTO country (id,code)
    VALUES (131,'MT');


INSERT INTO country (id,code)
    VALUES (132,'MH');


INSERT INTO country (id,code)
    VALUES (133,'MQ');


INSERT INTO country (id,code)
    VALUES (134,'MR');


INSERT INTO country (id,code)
    VALUES (135,'MU');


INSERT INTO country (id,code)
    VALUES (136,'YT');


INSERT INTO country (id,code)
    VALUES (137,'MX');


INSERT INTO country (id,code)
    VALUES (138,'FM');


INSERT INTO country (id,code)
    VALUES (139,'MD');


INSERT INTO country (id,code)
    VALUES (140,'MC');


INSERT INTO country (id,code)
    VALUES (141,'MN');


INSERT INTO country (id,code)
    VALUES (142,'MS');


INSERT INTO country (id,code)
    VALUES (143,'MA');


INSERT INTO country (id,code)
    VALUES (144,'MZ');


INSERT INTO country (id,code)
    VALUES (145,'MM');


INSERT INTO country (id,code)
    VALUES (146,'NA');


INSERT INTO country (id,code)
    VALUES (147,'NR');


INSERT INTO country (id,code)
    VALUES (148,'NP');


INSERT INTO country (id,code)
    VALUES (149,'NL');


INSERT INTO country (id,code)
    VALUES (150,'AN');


INSERT INTO country (id,code)
    VALUES (151,'NC');


INSERT INTO country (id,code)
    VALUES (152,'NZ');


INSERT INTO country (id,code)
    VALUES (153,'NI');


INSERT INTO country (id,code)
    VALUES (154,'NE');


INSERT INTO country (id,code)
    VALUES (155,'NG');


INSERT INTO country (id,code)
    VALUES (156,'NU');


INSERT INTO country (id,code)
    VALUES (157,'NF');


INSERT INTO country (id,code)
    VALUES (158,'KP');


INSERT INTO country (id,code)
    VALUES (159,'MP');


INSERT INTO country (id,code)
    VALUES (160,'NO');


INSERT INTO country (id,code)
    VALUES (161,'OM');


INSERT INTO country (id,code)
    VALUES (162,'PK');


INSERT INTO country (id,code)
    VALUES (163,'PW');


INSERT INTO country (id,code)
    VALUES (164,'PA');


INSERT INTO country (id,code)
    VALUES (165,'PG');


INSERT INTO country (id,code)
    VALUES (166,'PY');


INSERT INTO country (id,code)
    VALUES (167,'PE');


INSERT INTO country (id,code)
    VALUES (168,'PH');


INSERT INTO country (id,code)
    VALUES (169,'PN');


INSERT INTO country (id,code)
    VALUES (170,'PL');


INSERT INTO country (id,code)
    VALUES (171,'PT');


INSERT INTO country (id,code)
    VALUES (172,'PR');


INSERT INTO country (id,code)
    VALUES (173,'QA');


INSERT INTO country (id,code)
    VALUES (174,'RE');


INSERT INTO country (id,code)
    VALUES (175,'RO');


INSERT INTO country (id,code)
    VALUES (176,'RU');


INSERT INTO country (id,code)
    VALUES (177,'RW');


INSERT INTO country (id,code)
    VALUES (178,'WS');


INSERT INTO country (id,code)
    VALUES (179,'SM');


INSERT INTO country (id,code)
    VALUES (180,'ST');


INSERT INTO country (id,code)
    VALUES (181,'SA');


INSERT INTO country (id,code)
    VALUES (182,'SN');


INSERT INTO country (id,code)
    VALUES (183,'YU');


INSERT INTO country (id,code)
    VALUES (184,'SC');


INSERT INTO country (id,code)
    VALUES (185,'SL');


INSERT INTO country (id,code)
    VALUES (186,'SG');


INSERT INTO country (id,code)
    VALUES (187,'SK');


INSERT INTO country (id,code)
    VALUES (188,'SI');


INSERT INTO country (id,code)
    VALUES (189,'SB');


INSERT INTO country (id,code)
    VALUES (190,'SO');


INSERT INTO country (id,code)
    VALUES (191,'ZA');


INSERT INTO country (id,code)
    VALUES (192,'GS');


INSERT INTO country (id,code)
    VALUES (193,'ES');


INSERT INTO country (id,code)
    VALUES (194,'LK');


INSERT INTO country (id,code)
    VALUES (195,'SH');


INSERT INTO country (id,code)
    VALUES (196,'KN');


INSERT INTO country (id,code)
    VALUES (197,'LC');


INSERT INTO country (id,code)
    VALUES (198,'PM');


INSERT INTO country (id,code)
    VALUES (199,'VC');


INSERT INTO country (id,code)
    VALUES (200,'SD');


INSERT INTO country (id,code)
    VALUES (201,'SR');


INSERT INTO country (id,code)
    VALUES (202,'SJ');


INSERT INTO country (id,code)
    VALUES (203,'SZ');


INSERT INTO country (id,code)
    VALUES (204,'SE');


INSERT INTO country (id,code)
    VALUES (205,'CH');


INSERT INTO country (id,code)
    VALUES (206,'SY');


INSERT INTO country (id,code)
    VALUES (207,'TW');


INSERT INTO country (id,code)
    VALUES (208,'TJ');


INSERT INTO country (id,code)
    VALUES (209,'TZ');


INSERT INTO country (id,code)
    VALUES (210,'TH');


INSERT INTO country (id,code)
    VALUES (211,'TG');


INSERT INTO country (id,code)
    VALUES (212,'TK');


INSERT INTO country (id,code)
    VALUES (213,'TO');


INSERT INTO country (id,code)
    VALUES (214,'TT');


INSERT INTO country (id,code)
    VALUES (215,'TN');


INSERT INTO country (id,code)
    VALUES (216,'TR');


INSERT INTO country (id,code)
    VALUES (217,'TM');


INSERT INTO country (id,code)
    VALUES (218,'TC');


INSERT INTO country (id,code)
    VALUES (219,'TV');


INSERT INTO country (id,code)
    VALUES (220,'UG');


INSERT INTO country (id,code)
    VALUES (221,'UA');


INSERT INTO country (id,code)
    VALUES (222,'AE');


INSERT INTO country (id,code)
    VALUES (223,'UK');


INSERT INTO country (id,code)
    VALUES (224,'US');


INSERT INTO country (id,code)
    VALUES (225,'UM');


INSERT INTO country (id,code)
    VALUES (226,'UY');


INSERT INTO country (id,code)
    VALUES (227,'UZ');


INSERT INTO country (id,code)
    VALUES (228,'VU');


INSERT INTO country (id,code)
    VALUES (229,'VA');


INSERT INTO country (id,code)
    VALUES (230,'VE');


INSERT INTO country (id,code)
    VALUES (231,'VN');


INSERT INTO country (id,code)
    VALUES (232,'VG');


INSERT INTO country (id,code)
    VALUES (233,'VI');


INSERT INTO country (id,code)
    VALUES (234,'WF');


INSERT INTO country (id,code)
    VALUES (235,'YE');


INSERT INTO country (id,code)
    VALUES (236,'ZM');


INSERT INTO country (id,code)
    VALUES (237,'ZW');


INSERT INTO currency (id,symbol,code,country_code)
    VALUES (1,'US$','USD','US');


INSERT INTO currency (id,symbol,code,country_code)
    VALUES (2,'C$','CAD','CA');


INSERT INTO currency (id,symbol,code,country_code)
    VALUES (3,'&#8364;','EUR','EU');


INSERT INTO currency (id,symbol,code,country_code)
    VALUES (4,'&#165;','JPY','JP');


INSERT INTO currency (id,symbol,code,country_code)
    VALUES (5,'&#163;','GBP','UK');


INSERT INTO currency (id,symbol,code,country_code)
    VALUES (6,'&#8361;','KRW','KR');


INSERT INTO currency (id,symbol,code,country_code)
    VALUES (7,'Sf','CHF','CH');


INSERT INTO currency (id,symbol,code,country_code)
    VALUES (8,'SeK','SEK','SE');


INSERT INTO currency (id,symbol,code,country_code)
    VALUES (9,'S$','SGD','SG');


INSERT INTO currency (id,symbol,code,country_code)
    VALUES (10,'M$','MYR','MY');


INSERT INTO currency (id,symbol,code,country_code)
    VALUES (11,'$','AUD','AU');


INSERT INTO currency_exchange (id,entity_id,currency_id,rate,create_datetime,OPTLOCK)
    VALUES (1,0,2,1.325,'2004-03-09 00:00:00',1);


INSERT INTO currency_exchange (id,entity_id,currency_id,rate,create_datetime,OPTLOCK)
    VALUES (2,0,3,0.8118,'2004-03-09 00:00:00',1);


INSERT INTO currency_exchange (id,entity_id,currency_id,rate,create_datetime,OPTLOCK)
    VALUES (3,0,4,111.4,'2004-03-09 00:00:00',1);


INSERT INTO currency_exchange (id,entity_id,currency_id,rate,create_datetime,OPTLOCK)
    VALUES (4,0,5,0.5479,'2004-03-09 00:00:00',1);


INSERT INTO currency_exchange (id,entity_id,currency_id,rate,create_datetime,OPTLOCK)
    VALUES (5,0,6,1171,'2004-03-09 00:00:00',1);


INSERT INTO currency_exchange (id,entity_id,currency_id,rate,create_datetime,OPTLOCK)
    VALUES (6,0,7,1.23,'2004-07-06 00:00:00',1);


INSERT INTO currency_exchange (id,entity_id,currency_id,rate,create_datetime,OPTLOCK)
    VALUES (7,0,8,7.47,'2004-07-06 00:00:00',1);


INSERT INTO currency_exchange (id,entity_id,currency_id,rate,create_datetime,OPTLOCK)
    VALUES (10,0,9,1.68,'2004-10-12 00:00:00',1);


INSERT INTO currency_exchange (id,entity_id,currency_id,rate,create_datetime,OPTLOCK)
    VALUES (11,0,10,3.8,'2004-10-12 00:00:00',1);


INSERT INTO currency_exchange (id,entity_id,currency_id,rate,create_datetime,OPTLOCK)
    VALUES (12,0,11,1.288,'2007-01-25 00:00:00',1);


INSERT INTO event_log_message (id)
    VALUES (1);


INSERT INTO event_log_message (id)
    VALUES (2);


INSERT INTO event_log_message (id)
    VALUES (3);


INSERT INTO event_log_message (id)
    VALUES (4);


INSERT INTO event_log_message (id)
    VALUES (5);


INSERT INTO event_log_message (id)
    VALUES (6);


INSERT INTO event_log_message (id)
    VALUES (7);


INSERT INTO event_log_message (id)
    VALUES (8);


INSERT INTO event_log_message (id)
    VALUES (9);


INSERT INTO event_log_message (id)
    VALUES (10);


INSERT INTO event_log_message (id)
    VALUES (11);


INSERT INTO event_log_message (id)
    VALUES (12);


INSERT INTO event_log_message (id)
    VALUES (13);


INSERT INTO event_log_message (id)
    VALUES (14);


INSERT INTO event_log_message (id)
    VALUES (15);


INSERT INTO event_log_message (id)
    VALUES (16);


INSERT INTO event_log_message (id)
    VALUES (17);


INSERT INTO event_log_message (id)
    VALUES (18);


INSERT INTO event_log_message (id)
    VALUES (19);


INSERT INTO event_log_message (id)
    VALUES (20);


INSERT INTO event_log_message (id)
    VALUES (21);


INSERT INTO event_log_message (id)
    VALUES (22);


INSERT INTO event_log_message (id)
    VALUES (23);


INSERT INTO event_log_message (id)
    VALUES (24);


INSERT INTO event_log_message (id)
    VALUES (25);


INSERT INTO event_log_message (id)
    VALUES (26);


INSERT INTO event_log_message (id)
    VALUES (27);


INSERT INTO event_log_message (id)
    VALUES (28);


INSERT INTO event_log_message (id)
    VALUES (29);


INSERT INTO event_log_message (id)
    VALUES (30);


INSERT INTO event_log_message (id)
    VALUES (31);


INSERT INTO event_log_message (id)
    VALUES (32);


INSERT INTO event_log_message (id)
    VALUES (33);


INSERT INTO event_log_module (id)
    VALUES (1);


INSERT INTO event_log_module (id)
    VALUES (2);


INSERT INTO event_log_module (id)
    VALUES (3);


INSERT INTO event_log_module (id)
    VALUES (4);


INSERT INTO event_log_module (id)
    VALUES (5);


INSERT INTO event_log_module (id)
    VALUES (6);


INSERT INTO event_log_module (id)
    VALUES (7);


INSERT INTO event_log_module (id)
    VALUES (8);


INSERT INTO event_log_module (id)
    VALUES (9);


INSERT INTO event_log_module (id)
    VALUES (10);


INSERT INTO event_log_module (id)
    VALUES (11);


INSERT INTO event_log_module (id)
    VALUES (12);


INSERT INTO event_log_module (id)
    VALUES (13);


INSERT INTO event_log_module (id)
    VALUES (14);


INSERT INTO event_log_module (id)
    VALUES (15);


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,20,'description',1,'Manual invoice deletion');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,9,'description',1,'Invoice maintenance');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,11,'description',1,'Pluggable tasks maintenance');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,16,'description',1,'A purchase order as been manually applied to an invoice.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,17,'description',1,'Payment (failed)');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,16,'description',1,'Payment (successful)');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,7,'display',1,'Create New User');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,76,'display',1,'Numbering');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,92,'display',1,'Download');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,111,'description',1,'Menu Reports invoice details option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,111,'title',1,'Menu Reports Invoice Details');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,112,'description',1,'Menu Reports users option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,112,'title',1,'Menu Reports Users');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,8,'description',1,'User');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (35,6,'description',1,'Discovery');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (35,7,'description',1,'Diners');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,109,'title',1,'Menu Payment ACH');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,109,'description',1,'Menu Payment ACH');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,75,'display',1,'ACH');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,16,'description',1,'Days before expiration for order notification 2');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,17,'description',1,'Days before expiration for order notification 3');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,13,'description',1,'Order about to expire. Step 1');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,14,'description',1,'Order about to expire. Step 2');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,15,'description',1,'Order about to expire. Step 3');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,91,'display',1,'Periods');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,113,'title',1,'Invoice delete');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,110,'description',1,'Menu Invoice Numbering');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,110,'title',1,'Menu Invoice Numbering');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (35,4,'description',1,'AMEX');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (35,5,'description',1,'ACH');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,114,'title',1,'User edit links');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,14,'description',1,'Include customer notes in invoice');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,115,'title',1,'User create - inital left menu');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,18,'description',1,'Invoice number prefix');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,234,'description',1,'Wallis and Futuna');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,235,'description',1,'Yemen');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,236,'description',1,'Zambia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,237,'description',1,'Zimbabwe');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,1,'description',1,'Order');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,2,'description',1,'Invoice');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,3,'description',1,'Payment');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,4,'description',1,'Refund');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,5,'description',1,'Customer');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,6,'description',1,'Partner');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,7,'description',1,'Partner selected');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,15,'description',1,'Days before expiration for order notification');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,21,'description',1,'Use invoice reminders');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,22,'description',1,'Number of days after the invoice generation for the first reminder');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,23,'description',1,'Number of days for next reminder');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,227,'description',1,'Uzbekistan');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,107,'title',1,'Menu Notif Preferences');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,107,'description',1,'Menu Notification preferences');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,74,'display',1,'Preferences');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,108,'title',1,'Order left menu options');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,108,'description',1,'Order options: g.invoice,');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,147,'description',1,'Nauru');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,148,'description',1,'Nepal');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,149,'description',1,'Netherlands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,150,'description',1,'Netherlands Antilles');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,151,'description',1,'New Caledonia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,152,'description',1,'New Zealand');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,153,'description',1,'Nicaragua');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,154,'description',1,'Niger');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,155,'description',1,'Nigeria');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,156,'description',1,'Niue');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,157,'description',1,'Norfolk Island');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,158,'description',1,'North Korea');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,159,'description',1,'Northern Mariana Islands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,160,'description',1,'Norway');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,161,'description',1,'Oman');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,162,'description',1,'Pakistan');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,163,'description',1,'Palau');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,164,'description',1,'Panama');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,165,'description',1,'Papua New Guinea');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,166,'description',1,'Paraguay');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,167,'description',1,'Peru');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,168,'description',1,'Philippines');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,169,'description',1,'Pitcairn Islands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,170,'description',1,'Poland');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,171,'description',1,'Portugal');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,172,'description',1,'Puerto Rico');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,173,'description',1,'Qatar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,174,'description',1,'Reunion');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,175,'description',1,'Romania');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,176,'description',1,'Russia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,177,'description',1,'Rwanda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,178,'description',1,'Samoa');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,179,'description',1,'San Marino');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,180,'description',1,'Sao Tome and Principe');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,181,'description',1,'Saudi Arabia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,182,'description',1,'Senegal');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,183,'description',1,'Serbia and Montenegro');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,184,'description',1,'Seychelles');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,185,'description',1,'Sierra Leone');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,186,'description',1,'Singapore');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,187,'description',1,'Slovakia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,188,'description',1,'Slovenia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,189,'description',1,'Solomon Islands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,190,'description',1,'Somalia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,191,'description',1,'South Africa');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,192,'description',1,'South Georgia and the South Sandwich Islands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,193,'description',1,'Spain');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,194,'description',1,'Sri Lanka');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,195,'description',1,'St. Helena');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,196,'description',1,'St. Kitts and Nevis');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,197,'description',1,'St. Lucia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,198,'description',1,'St. Pierre and Miquelon');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,199,'description',1,'St. Vincent and the Grenadines');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,200,'description',1,'Sudan');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,201,'description',1,'Suriname');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,202,'description',1,'Svalbard and Jan Mayen');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,203,'description',1,'Swaziland');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,204,'description',1,'Sweden');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,205,'description',1,'Switzerland');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,206,'description',1,'Syria');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,207,'description',1,'Taiwan');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,208,'description',1,'Tajikistan');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,209,'description',1,'Tanzania');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,210,'description',1,'Thailand');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,211,'description',1,'Togo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,212,'description',1,'Tokelau');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,213,'description',1,'Tonga');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,214,'description',1,'Trinidad and Tobago');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,215,'description',1,'Tunisia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,216,'description',1,'Turkey');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,217,'description',1,'Turkmenistan');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,218,'description',1,'Turks and Caicos Islands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,219,'description',1,'Tuvalu');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,220,'description',1,'Uganda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,221,'description',1,'Ukraine');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,222,'description',1,'United Arab Emirates');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,223,'description',1,'United Kingdom');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,224,'description',1,'United States');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,225,'description',1,'United States Minor Outlying Islands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,226,'description',1,'Uruguay');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,228,'description',1,'Vanuatu');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,229,'description',1,'Vatican City');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,230,'description',1,'Venezuela');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,231,'description',1,'Viet Nam');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,232,'description',1,'Virgin Islands - British');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,233,'description',1,'Virgin Islands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,57,'description',1,'Congo - DRC');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,58,'description',1,'Denmark');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,59,'description',1,'Djibouti');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,60,'description',1,'Dominica');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,61,'description',1,'Dominican Republic');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,62,'description',1,'East Timor');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,63,'description',1,'Ecuador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,64,'description',1,'Egypt');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,65,'description',1,'El Salvador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,66,'description',1,'Equatorial Guinea');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,67,'description',1,'Eritrea');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,68,'description',1,'Estonia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,69,'description',1,'Ethiopia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,70,'description',1,'Malvinas Islands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,71,'description',1,'Faroe Islands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,72,'description',1,'Fiji Islands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,73,'description',1,'Finland');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,74,'description',1,'France');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,75,'description',1,'French Guiana');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,76,'description',1,'French Polynesia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,77,'description',1,'French Southern and Antarctic Lands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,78,'description',1,'Gabon');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,79,'description',1,'Gambia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,80,'description',1,'Georgia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,81,'description',1,'Germany');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,82,'description',1,'Ghana');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,83,'description',1,'Gibraltar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,84,'description',1,'Greece');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,85,'description',1,'Greenland');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,86,'description',1,'Grenada');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,87,'description',1,'Guadeloupe');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,88,'description',1,'Guam');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,89,'description',1,'Guatemala');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,90,'description',1,'Guinea');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,91,'description',1,'Guinea-Bissau');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,92,'description',1,'Guyana');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,93,'description',1,'Haiti');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,94,'description',1,'Heard Island and McDonald Islands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,95,'description',1,'Honduras');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,96,'description',1,'Hong Kong SAR');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,97,'description',1,'Hungary');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,98,'description',1,'Iceland');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,99,'description',1,'India');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,100,'description',1,'Indonesia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,101,'description',1,'Iran');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,102,'description',1,'Iraq');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,103,'description',1,'Ireland');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,104,'description',1,'Israel');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,105,'description',1,'Italy');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,106,'description',1,'Jamaica');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,107,'description',1,'Japan');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,108,'description',1,'Jordan');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,109,'description',1,'Kazakhstan');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,110,'description',1,'Kenya');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,111,'description',1,'Kiribati');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,112,'description',1,'Korea');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,113,'description',1,'Kuwait');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,114,'description',1,'Kyrgyzstan');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,115,'description',1,'Laos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,116,'description',1,'Latvia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,117,'description',1,'Lebanon');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,118,'description',1,'Lesotho');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,119,'description',1,'Liberia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,120,'description',1,'Libya');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,121,'description',1,'Liechtenstein');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,122,'description',1,'Lithuania');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,123,'description',1,'Luxembourg');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,124,'description',1,'Macao SAR');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,125,'description',1,'Macedonia, Former Yugoslav Republic of');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,126,'description',1,'Madagascar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,127,'description',1,'Malawi');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,128,'description',1,'Malaysia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,129,'description',1,'Maldives');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,130,'description',1,'Mali');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,131,'description',1,'Malta');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,132,'description',1,'Marshall Islands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,133,'description',1,'Martinique');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,134,'description',1,'Mauritania');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,135,'description',1,'Mauritius');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,136,'description',1,'Mayotte');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,137,'description',1,'Mexico');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,138,'description',1,'Micronesia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,139,'description',1,'Moldova');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,140,'description',1,'Monaco');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,141,'description',1,'Mongolia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,142,'description',1,'Montserrat');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,143,'description',1,'Morocco');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,144,'description',1,'Mozambique');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,145,'description',1,'Myanmar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,146,'description',1,'Namibia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,37,'display',1,'Process');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,38,'display',1,'List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,39,'display',1,'Configuration');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,40,'display',1,'Latest');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,41,'display',1,'Review');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,42,'display',1,'Notification');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,43,'display',1,'Compose');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,44,'display',1,'Parameters');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,45,'display',1,'Emails list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,46,'display',1,'Customers');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,47,'display',1,'Reports');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,48,'display',1,'Reports');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,49,'display',1,'Reports');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,50,'display',1,'Reports');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,51,'display',1,'Reports');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,52,'display',1,'List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,53,'display',1,'List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,54,'display',1,'New');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,55,'display',1,'Branding');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,56,'display',1,'Currencies');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,57,'display',1,'Ageing');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,58,'display',1,'Create');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,59,'display',1,'Partners');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,60,'display',1,'Customers');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,61,'display',1,'New');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,62,'display',1,'List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,63,'display',1,'Defaults');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,64,'display',1,'Reports');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,65,'display',1,'Reports');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,66,'display',1,'List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,67,'display',1,'New');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,68,'display',1,'Statement');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,69,'display',1,'Latest');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,70,'display',1,'Payouts');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,71,'display',1,'Reports');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,72,'display',1,'Partners Due Payout');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,73,'display',1,'List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,1,'description',1,'Afghanistan');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,2,'description',1,'Albania');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,3,'description',1,'Algeria');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,4,'description',1,'American Samoa');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,5,'description',1,'Andorra');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,6,'description',1,'Angola');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,7,'description',1,'Anguilla');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,8,'description',1,'Antarctica');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,9,'description',1,'Antigua and Barbuda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,10,'description',1,'Argentina');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,11,'description',1,'Armenia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,12,'description',1,'Aruba');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,13,'description',1,'Australia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,14,'description',1,'Austria');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,15,'description',1,'Azerbaijan');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,16,'description',1,'Bahamas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,17,'description',1,'Bahrain');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,18,'description',1,'Bangladesh');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,19,'description',1,'Barbados');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,20,'description',1,'Belarus');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,21,'description',1,'Belgium');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,22,'description',1,'Belize');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,23,'description',1,'Benin');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,24,'description',1,'Bermuda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,25,'description',1,'Bhutan');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,26,'description',1,'Bolivia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,27,'description',1,'Bosnia and Herzegovina');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,28,'description',1,'Botswana');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,29,'description',1,'Bouvet Island');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,30,'description',1,'Brazil');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,31,'description',1,'British Indian Ocean Territory');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,32,'description',1,'Brunei');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,33,'description',1,'Bulgaria');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,34,'description',1,'Burkina Faso');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,35,'description',1,'Burundi');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,36,'description',1,'Cambodia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,37,'description',1,'Cameroon');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,38,'description',1,'Canada');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,39,'description',1,'Cape Verde');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,40,'description',1,'Cayman Islands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,41,'description',1,'Central African Republic');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,42,'description',1,'Chad');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,43,'description',1,'Chile');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,44,'description',1,'China');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,45,'description',1,'Christmas Island');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,46,'description',1,'Cocos - Keeling Islands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,47,'description',1,'Colombia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,48,'description',1,'Comoros');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,49,'description',1,'Congo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,50,'description',1,'Cook Islands');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,51,'description',1,'Costa Rica');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,52,'description',1,'Cote d Ivoire');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,53,'description',1,'Croatia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,54,'description',1,'Cuba');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,55,'description',1,'Cyprus');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,56,'description',1,'Czech Republic');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,89,'title',1,'Menu Partner - New');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,90,'description',1,'Menu Partner option - List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,90,'title',1,'Menu Partner - List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,91,'description',1,'Menu Partner option - Defaults');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,91,'title',1,'Menu Partner - Defaults');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,92,'description',1,'Menu Partner option - Reports');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,92,'title',1,'Menu Partner - Reports');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,93,'description',1,'Menu Customer option - Reports');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,93,'title',1,'Menu Customer - Reports');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,94,'description',1,'Menu Customer option - List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,94,'title',1,'Menu Customer - List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,95,'description',1,'Menu Customer option - New');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,95,'title',1,'Menu Customer - New');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,96,'description',1,'Menu Statement option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,96,'title',1,'Menu Statement');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,97,'description',1,'Menu Statement option - latest');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,97,'title',1,'Menu Statement latest');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,98,'description',1,'Menu Statement option - Payouts');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,98,'title',1,'Menu Statement payouts');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,99,'description',1,'Report Partners customers orders');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,99,'title',1,'Report partner ordres');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,100,'description',1,'Report Partners customers payments');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,100,'title',1,'Report partner payments');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,101,'description',1,'Report partners customers refunds');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,101,'title',1,'Report partner refunds');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,102,'description',1,'Report General partners');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,102,'title',1,'Report General partners');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,103,'description',1,'Report General payouts');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,103,'title',1,'Report General payouts');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,104,'description',1,'Menu Reports parterns option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,1,'description',1,'United States Dollar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,2,'description',1,'Canadian Dollar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,3,'description',1,'Euro');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,4,'description',1,'Yen');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,5,'description',1,'Pound Sterling');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,6,'description',1,'Won');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,7,'description',1,'Swiss Franc');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,8,'description',1,'Swedish Krona');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (6,1,'description',1,'Month');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (6,2,'description',1,'Week');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (6,3,'description',1,'Day');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (6,4,'description',1,'Year');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (7,1,'description',1,'Email');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (7,2,'description',1,'Paper');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (9,1,'description',1,'Active');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (9,2,'description',1,'Overdue');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (9,3,'description',1,'Overdue 2');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (9,4,'description',1,'Overdue 3');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (9,5,'description',1,'Suspended');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (9,6,'description',1,'Suspended 2');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (9,7,'description',1,'Suspended 3');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (9,8,'description',1,'Deleted');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (81,1,'description',1,'Active');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (81,2,'description',1,'Pending Unsubscription');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (81,3,'description',1,'Unsubscribed');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (81,4,'description',1,'Pending Expiration');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (81,5,'description',1,'Expired');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (81,6,'description',1,'Nonsubscriber');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (81,7,'description',1,'Discontinued');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,104,'title',1,'Menu Reports');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,105,'description',1,'Menu Partner option - due payment');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,105,'title',1,'Menu Partner - payable');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,106,'description',1,'Menu Reports list parterns option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,106,'title',1,'Menu Reports List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,1,'description',1,'An internal user with all the permissions');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,1,'title',1,'Internal');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,2,'description',1,'The super user of an entity');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,2,'title',1,'Super user');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,3,'description',1,'A billing clerk');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,3,'title',1,'Clerk');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,4,'description',1,'A partner that will bring customers');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,4,'title',1,'Partner');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,5,'description',1,'A customer that will query his/her account');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,5,'title',1,'Customer');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,1,'display',1,'Orders');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,2,'display',1,'Payments');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,3,'display',1,'Reports');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (17,1,'description',1,'One time');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (18,1,'description',1,'Items');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (18,2,'description',1,'Tax');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (19,1,'description',1,'pre paid');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (19,2,'description',1,'post paid');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (20,1,'description',1,'Active');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (20,2,'description',1,'Finished');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (20,3,'description',1,'Suspended');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,1,'description',1,'Takes the quantity and the price to calculate the totals for each line and the order total');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,1,'title',1,'Basic calculation of totals');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,2,'description',1,'Adds a line with a 7% and update the order total');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,2,'title',1,'GST calculation');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,3,'description',1,'Adds one month to the billing date for the due date');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,3,'title',1,'Due date calculation');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,4,'description',1,'Copies all the lines to generate the invoice');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,4,'title',1,'Basic invoice generation');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,5,'description',1,'Considers the active period and the last process');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,5,'title',1,'Basic order filter');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,6,'description',1,'Takes only those invoices with due date past the process date');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,6,'title',1,'Basic invoice filter');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,7,'description',1,'Most common logic to calculate the billable period of an order');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,7,'title',1,'Basic period calculator');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,8,'description',1,'Authorize.net payment process');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,8,'title',1,'Authorize.net payment');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,9,'description',1,'Simple email notification');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,9,'title',1,'Simple email notification');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,10,'description',1,'Gets a valid cc from the user');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,10,'title',1,'Simple payment instrument finder');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,11,'description',1,'Test partner payout processor');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,11,'title',1,'Test partner payout');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,12,'description',1,'Paper invoice notification with JasperReports');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,12,'title',1,'Paper invoice notificaiton');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (35,1,'description',1,'Cheque');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (35,2,'description',1,'Visa');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (35,3,'description',1,'MasterCard');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (41,1,'description',1,'Successful');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (41,2,'description',1,'Failed');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (41,3,'description',1,'Processor unavailable');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (41,4,'description',1,'Entered');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,1,'description',1,'Billing Process');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,2,'description',1,'User maintenance');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,3,'description',1,'Item maintenance');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,4,'description',1,'Item type maintenance');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,5,'description',1,'Item user price maintenance');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,6,'description',1,'Promotion maintenance');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,7,'description',1,'Order maintenance');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,8,'description',1,'Credit card maintenance');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,1,'description',1,'A prepaid order has unbilled time before the billing process date');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,2,'description',1,'Order has no active time at the date of process.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,3,'description',1,'At least one complete period has to be billable.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,4,'description',1,'Already billed for the current date.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,5,'description',1,'This order had to be maked for exclusion in the last process.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,6,'description',1,'Pre-paid order is being process after its expiration.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,7,'description',1,'A row was marked as deleted.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,8,'description',1,'A user password was changed.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,9,'description',1,'A row was updated.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,4,'display',1,'System');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,10,'description',1,'Running a billing process, but a review is found unapproved.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,11,'description',1,'Running a billing process, review is required but not present.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,12,'description',1,'A user status was changed.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,13,'description',1,'An order status was changed.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,14,'description',1,'A user had to be aged, but there''s no more steps configured.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,15,'description',1,'A partner has a payout ready, but no payment instrument.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,1,'description',1,'Process payment with billing process');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,2,'description',1,'URL of CSS file');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,3,'description',1,'URL of logo graphic');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,4,'description',1,'Grace period');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,5,'description',1,'Partner percentage rate');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,6,'description',1,'Partner referral fee');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,7,'description',1,'Partner one time payout');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,8,'description',1,'Partner period unit payout');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,9,'description',1,'Partner period value payout');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,10,'description',1,'Partner automatic payout');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,11,'description',1,'User in charge of partners ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,12,'description',1,'Partner fee currency');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,13,'description',1,'Self delivery of paper invoices');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,1,'description',1,'Invoice (email)');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,2,'description',1,'User Reactivated');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,3,'description',1,'User Overdue');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,4,'description',1,'User Overdue 2');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,5,'description',1,'User Overdue 3');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,6,'description',1,'User Suspended');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,7,'description',1,'User Suspended 2');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,8,'description',1,'User Suspended 3');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,9,'description',1,'User Deleted');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,10,'description',1,'Payout Remainder');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,11,'description',1,'Partner Payout');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,12,'description',1,'Invoice (paper)');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,1,'description',1,'Menu Order option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,1,'title',1,'Menu Order option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,2,'description',1,'Menu Payment option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,2,'title',1,'Menu Payment option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,3,'description',1,'Menu Report option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,3,'title',1,'Menu Report option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,4,'description',1,'Menu System option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,4,'title',1,'Menu System option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,5,'description',1,'Menu System-User option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,5,'title',1,'Menu System-User option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,6,'description',1,'Menu System-User-All option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,6,'title',1,'Menu System-User-All option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,7,'description',1,'Selection of user type when creating a user');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,7,'title',1,'User type selection');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,8,'description',1,'Can create root users');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,8,'title',1,'Can create root users');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,9,'description',1,'Can create clerk users');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,9,'title',1,'Can create clerk users');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,10,'description',1,'Can create partner users');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,10,'title',1,'Can create partner users');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,11,'description',1,'Can create customer users');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,11,'title',1,'Can create customer users');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,12,'description',1,'Can change entity when editing a user');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,12,'title',1,'Can change entity');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,13,'description',1,'Can change type when editing a user');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,13,'title',1,'Can change type');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,14,'description',1,'Can view type when editing a user');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,14,'title',1,'Can view type');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,15,'description',1,'Can change username when editing a user');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,15,'title',1,'Can change username');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,16,'description',1,'Can change password when editing a user');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,16,'title',1,'Can change password');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,17,'description',1,'Can change langauge when editing a user');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,17,'title',1,'Can change langauge');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,18,'description',1,'Can view language when editing a user');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,18,'title',1,'Can view language');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,19,'description',1,'Menu System-User-Maintain option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,19,'title',1,'Menu System-User-Maintain option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,20,'description',1,'Can change user status when editing a user');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,20,'title',1,'Can change status');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,21,'description',1,'Can view status when editing a user');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,21,'title',1,'Can view status');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,22,'description',1,'Menu Account sub-option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,22,'title',1,'Menu Account sub-option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,23,'description',1,'Menu change password lm-option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,23,'title',1,'Menu change password lm-option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,24,'description',1,'Menu edit contact info lm-option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,24,'title',1,'Menu edit contact info lm-option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,25,'description',1,'Menu account option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,25,'title',1,'Menu account option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,26,'description',1,'Menu change password sub-option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,26,'title',1,'Menu change password sub-option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,27,'description',1,'Menu edit contact info sub-option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,27,'title',1,'Menu edit contact info sub-option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,28,'description',1,'Menu logout option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,28,'title',1,'Menu logout option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,29,'description',1,'Menu items option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,29,'title',1,'Menu items option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,30,'description',1,'Menu Items - Types option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,30,'title',1,'Menu Items - Types option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,31,'description',1,'Menu Items - Create option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,31,'title',1,'Menu Items - Create option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,32,'description',1,'Menu Items - List option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,32,'title',1,'Menu Items - List option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,33,'description',1,'Menu Items - Types - Create option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,33,'title',1,'Menu Items - Types - Create option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,34,'description',1,'Can edit item fields (read-write)');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,34,'title',1,'Can edit item fields');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,35,'description',1,'Menu Items - Types - List option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,35,'title',1,'Menu Items - Types - List option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,36,'description',1,'Menu Promotion');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,36,'title',1,'Menu Promotion');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,37,'description',1,'Menu Promotion create');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,37,'title',1,'Menu Promotion create');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,38,'description',1,'Menu Promotion list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,38,'title',1,'Menu Promotion list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,39,'description',1,'Menu Payments new cheque');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,39,'title',1,'Menu Payments new cheque');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,40,'description',1,'Menu Payments new credit card');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,40,'title',1,'Menu Payments new cc');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,41,'description',1,'Menu Payments list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,41,'title',1,'Menu Payments list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,42,'description',1,'Menu Order create');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,42,'title',1,'Menu Order create');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,43,'description',1,'Menu Order list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,43,'title',1,'Menu Order list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,44,'description',1,'Menu Credit Card edit');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,44,'title',1,'Menu Credit Card');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,45,'description',1,'Menu Credit Card edit');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,45,'title',1,'Menu Credit Card');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,46,'description',1,'Menu Refund option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,46,'title',1,'Menu Refund option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,47,'description',1,'Menu Refund option - cheque');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,47,'title',1,'Menu Refund option - cheque');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,48,'description',1,'Menu Refund option - credit card');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,48,'title',1,'Menu Refund option - cc');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,49,'description',1,'Menu Refund option - list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,49,'title',1,'Menu Refund list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,50,'description',1,'Menu Invoice option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,50,'title',1,'Menu Invoice');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,51,'description',1,'Menu Invoice option - list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,51,'title',1,'Menu Invoice list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,52,'description',1,'Menu Process option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,52,'title',1,'Menu Process option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,53,'description',1,'Menu Process - list option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,53,'title',1,'Menu Process list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,54,'description',1,'Menu Process - edit configuration option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,54,'title',1,'Menu Process - Configuration');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,55,'description',1,'Menu Process - see latest option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,55,'title',1,'Menu Process - Latest');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,56,'description',1,'Menu Process - Review option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,56,'title',1,'Menu Process review');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,57,'description',1,'Menu Notification');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,57,'title',1,'Menu Notification');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,58,'description',1,'Menu Notification - Compose');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,58,'title',1,'Menu Notification Compose');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,59,'description',1,'Menu Notification - Parameters');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,59,'title',1,'Menu Notificaiton Parameters');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,60,'description',1,'Menu Notification - Emails list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,60,'title',1,'Menu Notification Emails');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,61,'description',1,'Menu Customers ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,61,'title',1,'Menu Customers');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,62,'description',1,'Menu Reports - Orders');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,62,'title',1,'Menu Reports Orders');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,63,'description',1,'Menu Reports - Invoice');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,63,'title',1,'Menu Reports Invoice');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,64,'description',1,'Menu Reports - Payment');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,64,'title',1,'Menu Reports Payment');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,65,'description',1,'Menu Reports - Refund');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,65,'title',1,'Menu Reports Refund');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,66,'description',1,'Menu Reports - Customer');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,66,'title',1,'Menu Reports Customer');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,67,'description',1,'Report General orders');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,67,'title',1,'Report General orders');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,68,'description',1,'Report General invoices');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,68,'title',1,'Report General invoices');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,69,'description',1,'Report General payments');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,69,'title',1,'Report General payments');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,70,'description',1,'Report General order lines');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,70,'title',1,'Report General order lines');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,71,'description',1,'Report General Refunds ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,71,'title',1,'Report General Refunds ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,72,'description',1,'Report Total invoiced by date range ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,72,'title',1,'Report Total invoiced ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,73,'description',1,'Report Total payments by date range ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,73,'title',1,'Report Total payments');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,74,'description',1,'Report Total refunds by date range ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,74,'title',1,'Report Total refunds');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,75,'description',1,'Report Total ordered by date range ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,75,'title',1,'Report Total ordered');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,76,'description',1,'Invoices overdue ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,76,'title',1,'Report Invoices overdue ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,77,'description',1,'Menu Customer option - list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,77,'title',1,'Menu Customer list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,78,'description',1,'Menu Report option - list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,78,'title',1,'Menu Report list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,79,'description',1,'Menu Customer option - new');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,79,'title',1,'Menu Customer New');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,80,'description',1,'Menu System option - Branding');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,80,'title',1,'Menu System - Branding');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,81,'description',1,'Can change currency when editing a user');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,81,'title',1,'Can change langauge');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,82,'description',1,'Can view currency when editing a user');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,82,'title',1,'Can view language');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,83,'description',1,'Menu System option - Currencies');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,83,'title',1,'Menu System - Currencies');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,84,'description',1,'Invoices carring a balance ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,84,'title',1,'Report Invoices carring a balance ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,85,'description',1,'Menu System option - Ageing');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,85,'title',1,'Menu System - Ageing');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,86,'description',1,'Menu Users option - All create');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,86,'title',1,'Menu Users - All create');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,87,'description',1,'Menu Partner option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,87,'title',1,'Menu Partner');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,88,'description',1,'Menu Customer option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,88,'title',1,'Menu Customer');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,89,'description',1,'Menu Partner option - New');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,18,'description',1,'Invoice Reminder');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,113,'description',1,'Invoice delete left menu option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,114,'description',1,'User edit links');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,115,'description',1,'User create - inital left menu');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,77,'display',1,'Edit ACH');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,116,'description',1,'Menu edit ach option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,116,'title',1,'Menu edit ach option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,5,'display',1,'Users');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,8,'display',1,'My Account');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,9,'display',1,'Change Password');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,10,'display',1,'Edit Contact Information');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,11,'display',1,'Account');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,12,'display',1,'Change Password');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,13,'display',1,'Edit Contact Information');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,14,'display',1,'OBSOLETED');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,15,'display',1,'Items');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,16,'display',1,'Types');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,17,'display',1,'Create');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,18,'display',1,'List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,19,'display',1,'Create Type');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,20,'display',1,'List/Edit Types');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,22,'display',1,'Create');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,23,'display',1,'List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,24,'display',1,'Cheque');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,25,'display',1,'Credit Card');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,26,'display',1,'List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,27,'display',1,'Create');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,28,'display',1,'List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,29,'display',1,'Edit Credit Card');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,30,'display',1,'Edit Credit Card');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,31,'display',1,'Refunds');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,32,'display',1,'Cheque');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,33,'display',1,'Credit Card');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,34,'display',1,'List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,35,'display',1,'Invoices');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,36,'display',1,'List');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,24,'description',1,'Data Fattura Fine Mese');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,9,'description',1,'Singapore Dollar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,10,'description',1,'Malaysian Ringgit');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,11,'description',1,'Australian Dollar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,19,'description',1,'Next invoice number');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,83,'display',1,'Help');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,84,'display',1,'Help');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,85,'display',1,'Help');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,86,'display',1,'Help');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,87,'display',1,'Help');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,88,'display',1,'Help');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,89,'display',1,'Help');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (7,3,'description',1,'Email + Paper');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,79,'display',1,'Help');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (35,8,'description',1,'PayPal');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,90,'display',1,'PayPal');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,78,'display',1,'Sub-accounts');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,6,'display',1,'Staff');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,9,'description',1,'Item');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,82,'display',1,'Help');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,81,'display',1,'Help');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,80,'display',1,'Help');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,19,'description',1,'Update Credit Card');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (20,4,'description',1,'Suspended (auto)');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (18,3,'description',1,'Penalty');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,20,'description',1,'Lost password');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,93,'display',1,'Plug-ins');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,94,'display',1,'Logo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,97,'display',1,'Blacklist');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (88,1,'description',1,'Active');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (88,2,'description',1,'Inactive');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (88,3,'description',1,'Pending Active');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (88,4,'description',1,'Pending Inactive');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (88,5,'description',1,'Failed');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (88,6,'description',1,'Unavailable');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,20,'description',2,'Elimina��o manual de facturas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,9,'description',2,'Manuten��o de facturas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,11,'description',2,'Manuten��o de tarefas de plug-ins');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,16,'description',2,'Uma ordem de compra foi aplicada manualmente a uma factura.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,17,'description',2,'Payment (sem sucesso)');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,16,'description',2,'Payment (com sucesso)');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,7,'display',2,'Criar Novo Utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,76,'display',2,'Numera��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,92,'display',2,'Baixar Ficheiro');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,111,'description',2,'Menu Relat�rios op��o de detalhes de facturas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,111,'title',2,'Menu Relat�rios Detalhes de Facturas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,112,'description',2,'Menu Relat�rios op��o de utilizadores');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,112,'title',2,'Menu Relat�rios de Utilizadores');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,8,'description',2,'Utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (35,6,'description',2,'Discovery');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (35,7,'description',2,'Diners');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,109,'title',2,'Menu Pagamento CCA');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,109,'description',2,'Menu Pagamento CCA');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,75,'display',2,'CCA');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,16,'description',2,'Dias antes da expira��o para notifica��o de ordens 2');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,17,'description',2,'Dias antes da expira��o para notifica��o de ordens 3');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,13,'description',2,'Ordem de compra a expirar. Passo 1');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,14,'description',2,'Ordem de compra a expirar. Passo 2');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,15,'description',2,'Ordem de compra a expirar. Passo 3');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,91,'display',2,'Per�odos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,113,'title',2,'Eliminar factura');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,110,'description',2,'Menu Numera��o de Facturas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,110,'title',2,'Menu Numera��o de Facturas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (35,4,'description',2,'AMEX');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (35,5,'description',2,'CCA');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,114,'title',2,'Utilizador editar liga��es');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,14,'description',2,'Incluir notas do cliente na factura');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,115,'title',2,'Utilizador criar - menu inicial � esquerda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,18,'description',2,'N�mero de prefixo da factura');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,234,'description',2,'Wallis and Futuna');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,235,'description',2,'Yemen');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,236,'description',2,'Z�mbia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,237,'description',2,'Zimbabwe');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,1,'description',2,'Ordem');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,2,'description',2,'Factura');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,3,'description',2,'Pagamento');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,4,'description',2,'Devolu��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,5,'description',2,'Cliente');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,6,'description',2,'Parceiro');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,7,'description',2,'Parceiro seleccionado');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,15,'description',2,'Dias antes da expira��o para notifica��o de ordens');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,21,'description',2,'Usar os lembretes de factura');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,22,'description',2,'N�mero de dias ap�s a gera��o da factura para o primeiro lembrete');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,23,'description',2,'N�mero de dias para o pr�ximo lembrete');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,227,'description',2,'Uzbekist�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,107,'title',2,'Menu Prefer�ncias de Notifica��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,107,'description',2,'Menu Prefer�ncias de Notifica��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,74,'display',2,'Prefer�ncias');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,108,'title',2,'Ordem op��es menu esquerdo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,108,'description',2,'Ordem op��es: g.invoice,');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,147,'description',2,'Nauru');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,148,'description',2,'Nepal');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,149,'description',2,'Holanda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,150,'description',2,'Antilhas Holandesas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,151,'description',2,'Nova Caled�nia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,152,'description',2,'Nova Zel�ndia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,153,'description',2,'Nicar�gua');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,154,'description',2,'Niger');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,155,'description',2,'Nig�ria');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,156,'description',2,'Niue');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,157,'description',2,'Ilhas Norfolk');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,158,'description',2,'Coreia do Norte');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,159,'description',2,'Ilhas Mariana do Norte');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,160,'description',2,'Noruega');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,161,'description',2,'Oman');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,162,'description',2,'Pakist�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,163,'description',2,'Palau');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,164,'description',2,'Panama');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,165,'description',2,'Papua Nova Guin�');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,166,'description',2,'Paraguai');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,167,'description',2,'Per�');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,168,'description',2,'Filipinas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,169,'description',2,'Ilhas Pitcairn');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,170,'description',2,'Pol�nia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,171,'description',2,'Portugal');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,172,'description',2,'Porto Rico');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,173,'description',2,'Qatar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,174,'description',2,'Reuni�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,175,'description',2,'Rom�nia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,176,'description',2,'R�ssia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,177,'description',2,'Rwanda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,178,'description',2,'Samoa');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,179,'description',2,'S�o Marino');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,180,'description',2,'S�o Tom� e Princepe');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,181,'description',2,'Ar�bia Saudita');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,182,'description',2,'Senegal');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,183,'description',2,'S�rvia e Montenegro');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,184,'description',2,'Seychelles');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,185,'description',2,'Serra Leoa');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,186,'description',2,'Singapure');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,187,'description',2,'Eslov�quia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,188,'description',2,'Eslov�nia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,189,'description',2,'Ilhas Salom�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,190,'description',2,'Som�lia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,191,'description',2,'�frica do Sul');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,192,'description',2,'Georgia do Sul e Ilhas Sandwich South');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,193,'description',2,'Espanha');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,194,'description',2,'Sri Lanka');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,195,'description',2,'Sta. Helena');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,196,'description',2,'Sta. Kitts e Nevis');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,197,'description',2,'Sta. Lucia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,198,'description',2,'Sta. Pierre e Miquelon');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,199,'description',2,'Sto. Vicente e Grenadines');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,200,'description',2,'Sud�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,201,'description',2,'Suriname');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,202,'description',2,'Svalbard e Jan Mayen');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,203,'description',2,'Swazil�ndia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,204,'description',2,'Su�cia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,205,'description',2,'Su��a');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,206,'description',2,'S�ria');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,207,'description',2,'Taiwan');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,208,'description',2,'Tajikist�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,209,'description',2,'Tanz�nia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,210,'description',2,'Thail�ndia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,211,'description',2,'Togo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,212,'description',2,'Tokelau');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,213,'description',2,'Tonga');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,214,'description',2,'Trinidade e Tobago');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,215,'description',2,'Tun�sia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,216,'description',2,'Turquia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,217,'description',2,'Turkmenist�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,218,'description',2,'Ilhas Turks e Caicos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,219,'description',2,'Tuvalu');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,220,'description',2,'Uganda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,221,'description',2,'Ucr�nia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,222,'description',2,'Emiados �rabes Unidos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,223,'description',2,'Reino Unido');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,224,'description',2,'Estados Unidos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,225,'description',2,'Estados Unidos e Ilhas Menores Circundantes');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,226,'description',2,'Uruguai');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,228,'description',2,'Vanuatu');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,229,'description',2,'Cidade do Vaticano');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,230,'description',2,'Venezuela');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,231,'description',2,'Vietname');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,232,'description',2,'Ilhas Virgens Brit�nicas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,233,'description',2,'Ilhas Virgens');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,57,'description',2,'Rep�blica Democr�tica do Congo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,58,'description',2,'Dinamarca');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,59,'description',2,'Djibouti');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,60,'description',2,'Dominica');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,61,'description',2,'Rep�blica Dominicana');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,62,'description',2,'Timor Leste');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,63,'description',2,'Ecuador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,64,'description',2,'Egipto');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,65,'description',2,'El Salvador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,66,'description',2,'Guin� Equatorial');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,67,'description',2,'Eritreia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,68,'description',2,'Est�nia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,69,'description',2,'Etiopia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,70,'description',2,'Ilhas Malvinas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,71,'description',2,'Ilhas Faro�');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,72,'description',2,'Ilhas Fiji');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,73,'description',2,'Finl�ndia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,74,'description',2,'Fran�a');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,75,'description',2,'Guiana Francesa');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,76,'description',2,'Polin�sia Francesa');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,77,'description',2,'Terras Ant�rticas e do Sul Francesas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,78,'description',2,'Gab�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,79,'description',2,'G�mbia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,80,'description',2,'Georgia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,81,'description',2,'Alemanha');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,82,'description',2,'Gana');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,83,'description',2,'Gibraltar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,84,'description',2,'Gr�cia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,85,'description',2,'Gronel�ndia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,86,'description',2,'Granada');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,87,'description',2,'Guadalupe');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,88,'description',2,'Guantanamo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,89,'description',2,'Guatemala');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,90,'description',2,'Guin�');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,91,'description',2,'Guin�-Bissau');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,92,'description',2,'Guiana');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,93,'description',2,'Haiti');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,94,'description',2,'Ilhas Heard e McDonald');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,95,'description',2,'Honduras');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,96,'description',2,'Hong Kong SAR');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,97,'description',2,'Hungria');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,98,'description',2,'Isl�ndia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,99,'description',2,'�ndia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,100,'description',2,'Indon�sia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,101,'description',2,'Ir�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,102,'description',2,'Iraque');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,103,'description',2,'Irlanda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,104,'description',2,'Israel');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,105,'description',2,'It�lia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,106,'description',2,'Jamaica');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,107,'description',2,'Jap�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,108,'description',2,'Jord�nia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,109,'description',2,'Kazaquist�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,110,'description',2,'K�nia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,111,'description',2,'Kiribati');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,112,'description',2,'Coreia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,113,'description',2,'Kuwait');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,114,'description',2,'Kirgist�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,115,'description',2,'Laos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,116,'description',2,'Latvia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,117,'description',2,'L�bano');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,118,'description',2,'Lesoto');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,119,'description',2,'Lib�ria');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,120,'description',2,'L�bia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,121,'description',2,'Liechtenstein');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,122,'description',2,'Litu�nia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,123,'description',2,'Luxemburgo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,124,'description',2,'Macau SAR');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,125,'description',2,'Maced�nia, Antiga Rep�blica Jugoslava da');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,126,'description',2,'Madag�scar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,127,'description',2,'Malaui');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,128,'description',2,'Mal�sia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,129,'description',2,'Maldivas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,130,'description',2,'Mali');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,131,'description',2,'Malta');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,132,'description',2,'Ilhas Marshall');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,133,'description',2,'Martinica');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,134,'description',2,'Maurit�nia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,135,'description',2,'Maur�cias');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,136,'description',2,'Maiote');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,137,'description',2,'M�xico');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,138,'description',2,'Micron�sia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,139,'description',2,'Moldova');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,140,'description',2,'M�naco');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,141,'description',2,'Mong�lia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,142,'description',2,'Monserrate');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,143,'description',2,'Marrocos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,144,'description',2,'Mo�ambique');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,145,'description',2,'Mianmar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,146,'description',2,'Nam�bia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,37,'display',2,'Processo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,38,'display',2,'Lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,39,'display',2,'Configura��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,40,'display',2,'�ltima');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,41,'display',2,'Rev�r');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,42,'display',2,'Notifica��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,43,'display',2,'Comp�r');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,44,'display',2,'Par�metros');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,45,'display',2,'Lista de Emails');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,46,'display',2,'Clientes');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,47,'display',2,'Relat�rios');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,48,'display',2,'Relat�rios');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,49,'display',2,'Relat�rios');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,50,'display',2,'Relat�rios');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,51,'display',2,'Relat�rios');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,52,'display',2,'Lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,53,'display',2,'Lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,54,'display',2,'Novo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,55,'display',2,'Branding');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,56,'display',2,'Moedas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,57,'display',2,'Antiguidade');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,58,'display',2,'Criar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,59,'display',2,'Parceiros');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,60,'display',2,'Clientes');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,61,'display',2,'Novo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,62,'display',2,'Lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,63,'display',2,'Por Defeito');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,64,'display',2,'Relat�rios');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,65,'display',2,'Relat�rios');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,66,'display',2,'Lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,67,'display',2,'Novo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,68,'display',2,'Extracto');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,69,'display',2,'�ltima');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,70,'display',2,'Pagamentos (Fornecedores)');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,71,'display',2,'Relat�rios');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,72,'display',2,'Parceiros Pagamentos Devidos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,73,'display',2,'Lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,1,'description',2,'Afganist�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,2,'description',2,'Alb�nia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,3,'description',2,'Alg�ria');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,4,'description',2,'Samoa Americana');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,5,'description',2,'Andorra');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,6,'description',2,'Angola');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,7,'description',2,'Anguilha');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,8,'description',2,'Ant�rtida');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,9,'description',2,'Antigua e Barbuda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,10,'description',2,'Argentina');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,11,'description',2,'Arm�nia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,12,'description',2,'Aruba');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,13,'description',2,'Austr�lia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,14,'description',2,'�ustria');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,15,'description',2,'Azerbeij�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,16,'description',2,'Bahamas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,17,'description',2,'Bahrain');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,18,'description',2,'Bangladesh');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,19,'description',2,'Barbados');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,20,'description',2,'Belar�ssia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,21,'description',2,'B�lgica');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,22,'description',2,'Belize');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,23,'description',2,'Benin');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,24,'description',2,'Bermuda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,25,'description',2,'But�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,26,'description',2,'Bol�via');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,27,'description',2,'Bosnia e Herzegovina');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,28,'description',2,'Botswana');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,29,'description',2,'Ilha Bouvet');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,30,'description',2,'Brasil');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,31,'description',2,'Territ�rio Brit�nico do Oceano �ndico');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,32,'description',2,'Brunei');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,33,'description',2,'Bulg�ria');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,34,'description',2,'Burquina Faso');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,35,'description',2,'Burundi');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,36,'description',2,'Cambodia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,37,'description',2,'Camar�es');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,38,'description',2,'Canada');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,39,'description',2,'Cabo Verde');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,40,'description',2,'Ilhas Caim�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,41,'description',2,'Rep�blica Centro Africana');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,42,'description',2,'Chade');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,43,'description',2,'Chile');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,44,'description',2,'China');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,45,'description',2,'Ilha Natal');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,46,'description',2,'Ilha Cocos e Keeling');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,47,'description',2,'Col�mbia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,48,'description',2,'Comoros');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,49,'description',2,'Congo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,50,'description',2,'Ilhas Cook');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,51,'description',2,'Costa Rica');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,52,'description',2,'Costa do Marfim');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,53,'description',2,'Cro�cia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,54,'description',2,'Cuba');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,55,'description',2,'Chipre');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (64,56,'description',2,'Rep�blica Checa');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,89,'title',2,'Menu Parceiro - Novo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,90,'description',2,'Menu Parceiro op��o - Listar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,90,'title',2,'Menu Parceiro - Listar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,91,'description',2,'Menu Parceiro op��o - Valores por Defeito');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,91,'title',2,'Menu Parceiro - Valores por Defeito');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,92,'description',2,'Menu Parceiro op��o - Relat�rios');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,92,'title',2,'Menu Parceiro - Relat�rios');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,93,'description',2,'Menu Cliente op��o - Relat�rios');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,93,'title',2,'Menu Cliente - Relat�rios');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,94,'description',2,'Menu Cliente op��o - Lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,94,'title',2,'Menu Cliente - Lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,95,'description',2,'Menu Cliente op��o - Novo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,95,'title',2,'Menu Cliente - Novo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,96,'description',2,'Menu Extracto op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,96,'title',2,'Menu Extracto');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,97,'description',2,'Menu Extracto op��o - �ltimo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,97,'title',2,'Menu Extracto �ltimo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,98,'description',2,'Menu Extracto op��o - Pagamentos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,98,'title',2,'Menu Extracto pagamentos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,99,'description',2,'Relat�rio Parceiros ordens de clientes');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,99,'title',2,'Relat�rio Parceiros ordens');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,100,'description',2,'Relat�rio Parceiros pagamentos de clientes');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,100,'title',2,'Relat�rio Parceiros pagamentos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,101,'description',2,'Relat�rio Parceiros devolu��es a clientes');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,101,'title',2,'Relat�rio Parceiros devolu��es');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,102,'description',2,'Relat�rio Geral parceiros');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,102,'title',2,'Relat�rio Geral parceiros');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,103,'description',2,'Relat�rio Geral pagamentos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,103,'title',2,'Relat�rio Geral pagamentos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,104,'description',2,'Menu Relat�rio Parceiros op��es');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,1,'description',2,'D�lares Norte Americanos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,2,'description',2,'D�lares Canadianos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,3,'description',2,'Euro');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,4,'description',2,'Ien');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,5,'description',2,'Libras Estrelinas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,6,'description',2,'Won');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,7,'description',2,'Franco Su��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,8,'description',2,'Coroa Sueca');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (6,1,'description',2,'M�s');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (6,2,'description',2,'Semana');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (6,3,'description',2,'Dia');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (6,4,'description',2,'Ano');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (7,1,'description',2,'Email');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (7,2,'description',2,'Papel');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (9,1,'description',2,'Activo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (9,2,'description',2,'Em aberto');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (9,3,'description',2,'Em aberto 2');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (9,4,'description',2,'Em aberto 3');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (9,5,'description',2,'Suspensa');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (9,6,'description',2,'Suspensa 2');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (9,7,'description',2,'Suspensa 3');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (9,8,'description',2,'Eliminado');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,104,'title',2,'Menu Relat�rios');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,105,'description',2,'Menu Parceiro op��es - pagamentos devidos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,105,'title',2,'Menu Parceiro - a pagamento');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,106,'description',2,'Menu Relat�rios op��o de lista de padr�es');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,106,'title',2,'Menu Relat�rios Lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,1,'description',2,'Um utilizador interno com todas as permiss�es');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,1,'title',2,'Interno');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,2,'description',2,'O super utilizador de uma entidade');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,2,'title',2,'Super utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,3,'description',2,'Um operador de factura��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,3,'title',2,'Operador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,4,'description',2,'Um parceiro que vai angariar clientes');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,4,'title',2,'Parceiro');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,5,'description',2,'Um cliente que vai fazer pesquisas na sua conta');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (60,5,'title',2,'Cliente');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,1,'display',2,'Ordens');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,2,'display',2,'Pagamentos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,3,'display',2,'Relat�rios');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (17,1,'description',2,'Vez �nica');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (18,1,'description',2,'Items');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (18,2,'description',2,'Imposto');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (19,1,'description',2,'Pr� pago');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (19,2,'description',2,'P�s pago');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (20,1,'description',2,'Activo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (20,2,'description',2,'Terminado');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (20,3,'description',2,'Suspenso');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,1,'description',2,'Leva a quantidade e pre�o em conta para calcular o total por linha e o valor total da ordem');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,1,'title',2,'C�lculo b�sico de totais');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,2,'description',2,'Adiciona uma linha com 7% e actualiza o total da ordem');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,2,'title',2,'C�lculo de Imposto');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,3,'description',2,'Adiciona um m�s � data de factura��o para a data limite');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,3,'title',2,'Calculo da data limite');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,4,'description',2,'Copia todas as linhas para gerar a factura');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,4,'title',2,'Gera��o b�sica da factura');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,5,'description',2,'Considera o per�odo activo e o �ltimo processamento');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,5,'title',2,'Filtro de ordem b�sico');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,6,'description',2,'Leva em considera��o apenas as facturas com data acima da data limite');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,6,'title',2,'Fltro b�sico de facturas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,7,'description',2,'L�gica mais comum para calcular o per�odo factur�vel de uma ordem');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,7,'title',2,'C�lculo de per�odo b�sico');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,8,'description',2,'Processo de Pagamento Authorize.net');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,8,'title',2,'Pagamento Authorize.net');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,9,'description',2,'Notifica��o simples de email');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,9,'title',2,'Notifica��o simples de email');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,10,'description',2,'Recebe um CC v�lido do utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,10,'title',2,'Localizador simples de instrumentos de pagamento');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,11,'description',2,'Teste o processador de pagamentos do parceiro');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,11,'title',2,'Teste o pagamento de parceiros');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,12,'description',2,'Notifi��o de facturas de papel com o JasperReports');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (24,12,'title',2,'Notifica��o de factura em papel');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (35,1,'description',2,'Cheque');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (35,2,'description',2,'Visa');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (35,3,'description',2,'MasterCard');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (41,1,'description',2,'Com sucesso');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (41,2,'description',2,'Sem sucesso');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (41,3,'description',2,'Processador indispon�vel');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (41,4,'description',2,'Inserido');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,1,'description',2,'Processo de Factura��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,2,'description',2,'Manuten��o de Utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,3,'description',2,'Item de manuten��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,4,'description',2,'Item tipo de manuten��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,5,'description',2,'Item manuten��o de pre�o de utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,6,'description',2,'Manuten��o de promo��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,7,'description',2,'Manuten��o por ordem');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (46,8,'description',2,'Manuten��o de cart�o de cr�dito');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,1,'description',2,'Uma ordem pr�-paga tem tempo n�o facturado anterior � data de factura��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,2,'description',2,'A ordem n�o tem nenhum per�odo activo � data de processamento.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,3,'description',2,'Pelo menos um per�odo completo tem de ser factur�vel.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,4,'description',2,'J� h� factura��o para o per�odo.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,5,'description',2,'Esta ordem teve de ser marcada para exclus�o do �ltimo processo.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,6,'description',2,'Pre-paid order is being process after its expiration.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,7,'description',2,'A linha marcada foi eliminada.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,8,'description',2,'A senha de utilizador foi alterada.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,9,'description',2,'Uma linha foi actualizada.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,4,'display',2,'Sistema');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,10,'description',2,'A correr um processo de factura��o, foi encontrada uma revis�o rejeitada.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,11,'description',2,'A correr um processo de factura��o, uma � necess�ria mas n�o encontrada.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,12,'description',2,'Um status de utilizador foi alterado.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,13,'description',2,'Um status de uma ordem foi alterado.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,14,'description',2,'Um utilizador foi inserido no processo de antiguidade, mas n�o h� mais passos configurados.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (47,15,'description',2,'Um parceiro tem um pagamento a receber, mas n�o tem instrumento de pagamento.');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,1,'description',2,'Processar pagamento com processo de factura��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,2,'description',2,'URL ou ficheiro CSS');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,3,'description',2,'URL ou gr�fico de logotipo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,4,'description',2,'Per�odo de gra�a');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,5,'description',2,'Percentagem do parceiro');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,6,'description',2,'Valor de refer�ncia do parceiro');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,7,'description',2,'Parceiro pagamento �nico');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,8,'description',2,'Parceiro unidade do per�odo de pagamento');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,9,'description',2,'Parceiro valor do per�odo de pagamento');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,10,'description',2,'Parceiro pagamento autom�tico');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,11,'description',2,'Utilizador respons�vel pelos parceiros');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,12,'description',2,'Parceiro moeda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,13,'description',2,'Entrega pelo mesmo das facturas em papel');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,1,'description',2,'Factura (email)');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,2,'description',2,'Utilizador Reactivado');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,3,'description',2,'Utilizador Em Atraso');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,4,'description',2,'Utilizador Em Atraso 2');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,5,'description',2,'Utilizador Em Atraso 3');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,6,'description',2,'Utilizador Suspenso');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,7,'description',2,'Utilizador Suspenso 2');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,8,'description',2,'Utilizador Suspenso 3');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,9,'description',2,'Utilizador Eliminado');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,10,'description',2,'Pagamento Remascente');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,11,'description',2,'Parceiro Pagamento');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,12,'description',2,'Factura (papel)');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,1,'description',2,'Menu Ordem op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,1,'title',2,'Menu Ordem op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,2,'description',2,'Menu Pagamento op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,2,'title',2,'Menu Pagamento op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,3,'description',2,'Menu Relat�rio op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,3,'title',2,'Menu Relat�rio op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,4,'description',2,'Menu Sistema op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,4,'title',2,'Menu Sistema op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,5,'description',2,'Menu Sistema-Utilizador op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,5,'title',2,'Menu Sistema-Utilizador op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,6,'description',2,'Menu Sistema-Utilizador-Todos op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,6,'title',2,'Menu Sistema-Utilizador-Todos op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,7,'description',2,'Selec��o de tipo de utilizador aquando da cria��o de um utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,7,'title',2,'Utilizador selecc��o de tipo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,8,'description',2,'Pode criar utilizadores super');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,8,'title',2,'Pode criar utilizadores super');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,9,'description',2,'Pode criar utilizadores operadores');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,9,'title',2,'Pode criar utilizadores operadores');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,10,'description',2,'Pode criar utilizadores parceiros');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,10,'title',2,'Pode criar utilizadores parceiros');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,11,'description',2,'Pode criar utilizadores clientes');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,11,'title',2,'Pode criar utilizadores clientes');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,12,'description',2,'Pode mudar entidade quando editar um utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,12,'title',2,'Pode mudar entidade');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,13,'description',2,'Pode mudar tipo quando editar um utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,13,'title',2,'Pode mudar tipo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,14,'description',2,'Pode ver tipo quando editar um utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,14,'title',2,'Pode ver tipo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,15,'description',2,'Pode mudar nome de utilizador quando editar um utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,15,'title',2,'Pode mudar nome de utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,16,'description',2,'Pode mudar senha quando editar um utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,16,'title',2,'Pode mudar senha');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,17,'description',2,'Pode mudar l�ngua quando editar um utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,17,'title',2,'Pode mudar l�ngua');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,18,'description',2,'Pode ver l�ngua quando editar um utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,18,'title',2,'Pode ver l�ngua');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,19,'description',2,'Menu Sistema-Utilizador-Manter op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,19,'title',2,'Menu Sistema-Utilizador-Manter op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,20,'description',2,'Pode mudar status quando editar um utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,20,'title',2,'Pode mudar status');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,21,'description',2,'Pode ver status quando editar um utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,21,'title',2,'Pode ver status');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,22,'description',2,'Menu Conta sub-op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,22,'title',2,'Menu Conta sub-op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,23,'description',2,'Menu alterar senha lm-op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,23,'title',2,'Menu mudar senha lm-op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,24,'description',2,'Menu editar informa��o de contacto lm-option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,24,'title',2,'Menu editar informa��o de contacto lm-option');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,25,'description',2,'Menu op��o de conta');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,25,'title',2,'Menu op��o de conta');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,26,'description',2,'Menu alterar senha sub-op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,26,'title',2,'Menu alterar senha sub-op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,27,'description',2,'Menu editar informa��o de contacto sub-op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,27,'title',2,'Menu editar informa��o de contacto sub-op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,28,'description',2,'Menu sa�da op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,28,'title',2,'Menu sa�da op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,29,'description',2,'Menu items op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,29,'title',2,'Menu items op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,30,'description',2,'Menu Items - Tipos op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,30,'title',2,'Menu Items - Tipos op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,31,'description',2,'Menu Items - Criar op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,31,'title',2,'Menu Items - Criar op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,32,'description',2,'Menu Items - Lista op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,32,'title',2,'Menu Items - Lista op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,33,'description',2,'Menu Items - Tipos - Criar op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,33,'title',2,'Menu Items - Tipos - Criar op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,34,'description',2,'Pode editar campos de item (ler-escrever)');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,34,'title',2,'Pode editar campos de items');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,35,'description',2,'Menu Items - Tipos - Lista op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,35,'title',2,'Menu Items - Tipos - Lista op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,36,'description',2,'Menu Promo��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,36,'title',2,'Menu Promo��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,37,'description',2,'Menu Promo��o criar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,37,'title',2,'Menu Promo��o criar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,38,'description',2,'Menu Promo��o lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,38,'title',2,'Menu Promo��o lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,39,'description',2,'Menu Pagamentos novo cheque');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,39,'title',2,'Menu Pagamentos novo cheque');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,40,'description',2,'Menu Pagamentos novo cart�o de cr�dito');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,40,'title',2,'Menu Pagamentos novo cart�o de cr�dito');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,41,'description',2,'Menu Pagamentos lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,41,'title',2,'Menu Pagamentos lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,42,'description',2,'Menu Ordem criar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,42,'title',2,'Menu Ordem criar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,43,'description',2,'Menu Ordem lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,43,'title',2,'Menu Ordem lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,44,'description',2,'Menu Cart�o de Cr�dito editar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,44,'title',2,'Menu Cart�o de Cr�dito');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,45,'description',2,'Menu Cart�o de Cr�dito editar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,45,'title',2,'Menu Cart�o de Cr�dito');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,46,'description',2,'Menu Devolu��o op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,46,'title',2,'Menu Devolu��o op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,47,'description',2,'Menu Devolu��o op��o - cheque');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,47,'title',2,'Menu Devolu��o op��o - cheque');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,48,'description',2,'Menu Devolu��o op��o - cart�o de cr�dito');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,48,'title',2,'Menu Devolu��o op��o - cart�o de cr�dito');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,49,'description',2,'Menu Devolu��o op��o - list');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,49,'title',2,'Menu Devolu��o lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,50,'description',2,'Menu Factura op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,50,'title',2,'Menu Factura');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,51,'description',2,'Menu Factura op��o - lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,51,'title',2,'Menu Factura lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,52,'description',2,'Menu Processo op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,52,'title',2,'Menu Processo op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,53,'description',2,'Menu Processo - lista op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,53,'title',2,'Menu Processo lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,54,'description',2,'Menu Processo - editar configura��o op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,54,'title',2,'Menu Processo - Configura��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,55,'description',2,'Menu Processo - ver �ltimo op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,55,'title',2,'Menu Processo - �ltimo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,56,'description',2,'Menu Processo - Revis�o op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,56,'title',2,'Menu Processo revis�o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,57,'description',2,'Menu Notifica��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,57,'title',2,'Menu Notifica��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,58,'description',2,'Menu Notifica��o - Comp�r');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,58,'title',2,'Menu Notifica��o Comp�r');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,59,'description',2,'Menu Notifica��o - Par�metros');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,59,'title',2,'Menu Notifica��o Par�metros');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,60,'description',2,'Menu Notifica��o - Emails lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,60,'title',2,'Menu Notifica��o Emails');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,61,'description',2,'Menu Clientes ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,61,'title',2,'Menu Clientes');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,62,'description',2,'Menu Relat�rios - Ordens');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,62,'title',2,'Menu Relat�rios Ordens');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,63,'description',2,'Menu Relat�rios - Factura');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,63,'title',2,'Menu Relat�rios Factura');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,64,'description',2,'Menu Relat�rios - Pagamento');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,64,'title',2,'Menu Relat�rios Pagamento');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,65,'description',2,'Menu Relat�rios - Devolu��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,65,'title',2,'Menu Relat�rios Devolu��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,66,'description',2,'Menu Relat�rios - Cliente');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,66,'title',2,'Menu Relat�rios Cliente');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,67,'description',2,'Relat�rio Geral ordens');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,67,'title',2,'Relat�rio Geral ordens');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,68,'description',2,'Relat�rio Geral facturas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,68,'title',2,'Relat�rio Geral facturas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,69,'description',2,'Relat�rio Geral pagamentos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,69,'title',2,'Relat�rio Geral pagamentos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,70,'description',2,'Relat�rio Geral linhas de ordens');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,70,'title',2,'Relat�rio Geral linhas de ordens');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,71,'description',2,'Relat�rio Geral Devolu��es ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,71,'title',2,'Relat�rio Geral Devolu��es ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,72,'description',2,'Relat�rio Total Facturado por intervalo de datas ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,72,'title',2,'Relat�rio Total Facturado ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,73,'description',2,'Relat�rio Total Pagamentos por intervalo de datas ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,73,'title',2,'Relat�rio Total Pagamentos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,74,'description',2,'Relat�rio Total devolu��es por intervalo de datas ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,74,'title',2,'Relat�rio Total devolu��es');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,75,'description',2,'Relat�rio Total ordens por intervalo de datas ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,75,'title',2,'Relat�rio Total ordens');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,76,'description',2,'Facturas em atraso ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,76,'title',2,'Report Facturas em atraso ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,77,'description',2,'Menu Cliente op��o - lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,77,'title',2,'Menu Cliente lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,78,'description',2,'Menu Relat�rio op��o - lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,78,'title',2,'Menu Relat�rio lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,79,'description',2,'Menu Cliente op��o - novo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,79,'title',2,'Menu Cliente Novo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,80,'description',2,'Menu Sistema op��o - Branding');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,80,'title',2,'Menu Sistema - Branding');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,81,'description',2,'Pode alterar moeda quando editar um utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,81,'title',2,'Pode alterar moeda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,82,'description',2,'Pode ver moeda quando alterar um utilizador');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,82,'title',2,'Pode ver moeda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,83,'description',2,'Menu Sistema op��o - Moedas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,83,'title',2,'Menu Sistema - Moedas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,84,'description',2,'Facturas com saldos anteriores ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,84,'title',2,'Relat�rio Facturas com saldos anteriores ');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,85,'description',2,'Menu Sistema op��o - Antiguidade');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,85,'title',2,'Menu Sistema - Antiguidade');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,86,'description',2,'Menu Utilizadores op��o - Todos criar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,86,'title',2,'Menu Utilizadores - Todos criar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,87,'description',2,'Menu Parceiro op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,87,'title',2,'Menu Parceiro');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,88,'description',2,'Menu Cliente op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,88,'title',2,'Menu Cliente');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,89,'description',2,'Menu Parceiro op��o - Novo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,18,'description',2,'Lembrete de Factura');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,113,'description',2,'Factura eliminar menu esquerdo op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,114,'description',2,'Utilizador editar hiperliga��es');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,115,'description',2,'Utilizador criar - menu inicial esquerdo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,77,'display',2,'Editar CCA');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,116,'description',2,'Menu editar cca op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (59,116,'title',2,'Menu editar cca op��o');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,5,'display',2,'Utilizadores');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,8,'display',2,'Minha conta');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,9,'display',2,'Alterar senha');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,10,'display',2,'Editar Informa��o de Contacto');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,11,'display',2,'Conta');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,12,'display',2,'Alterar senha');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,13,'display',2,'Editar Informa��o de Contacto');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,14,'display',2,'OBSOLETO');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,15,'display',2,'Items');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,16,'display',2,'Tipos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,17,'display',2,'Criar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,18,'display',2,'Lista');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,19,'display',2,'Criar Tipo');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,20,'display',2,'Listar/Editar Tipos');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,21,'display',2,'Promo��es');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,22,'display',2,'Criar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,23,'display',2,'Listar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,24,'display',2,'Cheque');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,25,'display',2,'Cart�o de Cr�dito');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,26,'display',2,'Listar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,27,'display',2,'Criar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,28,'display',2,'Listar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,29,'display',2,'Editar Cart�o de Cr�dito');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,30,'display',2,'Editar Cart�o de Cr�dito');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,31,'display',2,'Devolu��es');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,32,'display',2,'Cheque');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,33,'display',2,'Cart�o de Cr�dito');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,34,'display',2,'Listar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,35,'display',2,'Facturas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,36,'display',2,'Listar');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,24,'description',2,'Data Factura Fim do M�s');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,9,'description',2,'D�lar da Singapura');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,10,'description',2,'Ringgit Malasiano');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (4,11,'description',2,'D�lar Australiano');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (50,19,'description',2,'Pr�ximo n�mero de factura');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,83,'display',2,'Ajuda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,84,'display',2,'Ajuda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,85,'display',2,'Ajuda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,86,'display',2,'Ajuda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,87,'display',2,'Ajuda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,88,'display',2,'Ajuda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,89,'display',2,'Ajuda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (7,3,'description',2,'Email + Papel');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,79,'display',2,'Ajuda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (35,8,'description',2,'PayPal');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,90,'display',2,'PayPal');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,78,'display',2,'Sub-contas');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,6,'display',2,'Staff');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (73,9,'description',2,'Item');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,82,'display',2,'Ajuda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,81,'display',2,'Ajuda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,80,'display',2,'Ajuda');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,19,'description',2,'Actualizar Cart�o de Cr�dito');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (20,4,'description',2,'Suspender (auto)');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (18,3,'description',2,'Penalidade');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (52,20,'description',2,'Senha esquecida');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,93,'display',2,'Plug-ins');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,95,'display',1,'Mediation');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (63,96,'display',1,'Mediation');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (89,1,'description',1,'None');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (89,2,'description',1,'Pre-paid balance');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (89,3,'description',1,'Credit limit');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (91,1,'description',1,'Done and billable');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (91,2,'description',1,'Done and not billable');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (91,3,'description',1,'Error detected');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (91,4,'description',1,'Error declared');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (92,1,'description',1,'Running');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (92,2,'description',1,'Finished: successful');


INSERT INTO international_description (table_id,foreign_id,psudo_column,language_id,content)
    VALUES (92,3,'description',1,'Finished: failed');


INSERT INTO invoice_delivery_method (id)
    VALUES (1);


INSERT INTO invoice_delivery_method (id)
    VALUES (2);


INSERT INTO invoice_delivery_method (id)
    VALUES (3);


INSERT INTO invoice_line_type (id,description,order_position)
    VALUES (5,'sub account',4);


INSERT INTO invoice_line_type (id,description,order_position)
    VALUES (3,'due invoice',1);


INSERT INTO invoice_line_type (id,description,order_position)
    VALUES (1,'item',2);


INSERT INTO invoice_line_type (id,description,order_position)
    VALUES (4,'interests',3);


INSERT INTO invoice_line_type (id,description,order_position)
    VALUES (2,'tax',5);


INSERT INTO jbilling_table (id,name)
    VALUES (8,'entity_delivery_method_map');


INSERT INTO jbilling_table (id,name)
    VALUES (62,'user_role_map');


INSERT INTO jbilling_table (id,name)
    VALUES (36,'entity_payment_method_map');


INSERT INTO jbilling_table (id,name)
    VALUES (72,'report_entity_map');


INSERT INTO jbilling_table (id,name)
    VALUES (68,'currency_entity_map');


INSERT INTO jbilling_table (id,name)
    VALUES (74,'report_type_map');


INSERT INTO jbilling_table (id,name)
    VALUES (45,'user_credit_card_map');


INSERT INTO jbilling_table (id,name)
    VALUES (61,'permission_role_map');


INSERT INTO jbilling_table (id,name)
    VALUES (29,'contact_map');


INSERT INTO jbilling_table (id,name)
    VALUES (58,'permission_type');


INSERT INTO jbilling_table (id,name)
    VALUES (6,'period_unit');


INSERT INTO jbilling_table (id,name)
    VALUES (7,'invoice_delivery_method');


INSERT INTO jbilling_table (id,name)
    VALUES (9,'user_status');


INSERT INTO jbilling_table (id,name)
    VALUES (18,'order_line_type');


INSERT INTO jbilling_table (id,name)
    VALUES (19,'order_billing_type');


INSERT INTO jbilling_table (id,name)
    VALUES (63,'menu_option');


INSERT INTO jbilling_table (id,name)
    VALUES (20,'order_status');


INSERT INTO jbilling_table (id,name)
    VALUES (23,'pluggable_task_type_category');


INSERT INTO jbilling_table (id,name)
    VALUES (24,'pluggable_task_type');


INSERT INTO jbilling_table (id,name)
    VALUES (30,'invoice_line_type');


INSERT INTO jbilling_table (id,name)
    VALUES (4,'currency');


INSERT INTO jbilling_table (id,name)
    VALUES (73,'report_type');


INSERT INTO jbilling_table (id,name)
    VALUES (35,'payment_method');


INSERT INTO jbilling_table (id,name)
    VALUES (41,'payment_result');


INSERT INTO jbilling_table (id,name)
    VALUES (46,'event_log_module');


INSERT INTO jbilling_table (id,name)
    VALUES (47,'event_log_message');


INSERT INTO jbilling_table (id,name)
    VALUES (50,'preference_type');


INSERT INTO jbilling_table (id,name)
    VALUES (52,'notification_message_type');


INSERT INTO jbilling_table (id,name)
    VALUES (60,'role');


INSERT INTO jbilling_table (id,name)
    VALUES (64,'country');


INSERT INTO jbilling_table (id,name)
    VALUES (77,'list_entity');


INSERT INTO jbilling_table (id,name)
    VALUES (59,'permission');


INSERT INTO jbilling_table (id,name)
    VALUES (78,'list_field_entity');


INSERT INTO jbilling_table (id,name)
    VALUES (67,'currency_exchange');


INSERT INTO jbilling_table (id,name)
    VALUES (26,'pluggable_task_parameter');


INSERT INTO jbilling_table (id,name)
    VALUES (34,'billing_process_configuration');


INSERT INTO jbilling_table (id,name)
    VALUES (17,'order_period');


INSERT INTO jbilling_table (id,name)
    VALUES (0,'report');


INSERT INTO jbilling_table (id,name)
    VALUES (79,'partner_range');


INSERT INTO jbilling_table (id,name)
    VALUES (15,'item_price');


INSERT INTO jbilling_table (id,name)
    VALUES (11,'partner');


INSERT INTO jbilling_table (id,name)
    VALUES (5,'entity');


INSERT INTO jbilling_table (id,name)
    VALUES (28,'contact_type');


INSERT INTO jbilling_table (id,name)
    VALUES (65,'promotion');


INSERT INTO jbilling_table (id,name)
    VALUES (25,'pluggable_task');


INSERT INTO jbilling_table (id,name)
    VALUES (75,'ach');


INSERT INTO jbilling_table (id,name)
    VALUES (43,'payment_info_cheque');


INSERT INTO jbilling_table (id,name)
    VALUES (70,'partner_payout');


INSERT INTO jbilling_table (id,name)
    VALUES (38,'process_run_total_pm');


INSERT INTO jbilling_table (id,name)
    VALUES (71,'report_user');


INSERT INTO jbilling_table (id,name)
    VALUES (1,'report_field');


INSERT INTO jbilling_table (id,name)
    VALUES (66,'payment_authorization');


INSERT INTO jbilling_table (id,name)
    VALUES (32,'billing_process');


INSERT INTO jbilling_table (id,name)
    VALUES (33,'process_run');


INSERT INTO jbilling_table (id,name)
    VALUES (37,'process_run_total');


INSERT INTO jbilling_table (id,name)
    VALUES (31,'paper_invoice_batch');


INSERT INTO jbilling_table (id,name)
    VALUES (51,'preference');


INSERT INTO jbilling_table (id,name)
    VALUES (53,'notification_message');


INSERT INTO jbilling_table (id,name)
    VALUES (54,'notification_message_section');


INSERT INTO jbilling_table (id,name)
    VALUES (55,'notification_message_line');


INSERT INTO jbilling_table (id,name)
    VALUES (69,'ageing_entity_step');


INSERT INTO jbilling_table (id,name)
    VALUES (13,'item_type');


INSERT INTO jbilling_table (id,name)
    VALUES (14,'item');


INSERT INTO jbilling_table (id,name)
    VALUES (48,'event_log');


INSERT INTO jbilling_table (id,name)
    VALUES (21,'purchase_order');


INSERT INTO jbilling_table (id,name)
    VALUES (22,'order_line');


INSERT INTO jbilling_table (id,name)
    VALUES (39,'invoice');


INSERT INTO jbilling_table (id,name)
    VALUES (40,'invoice_line');


INSERT INTO jbilling_table (id,name)
    VALUES (49,'order_process');


INSERT INTO jbilling_table (id,name)
    VALUES (42,'payment');


INSERT INTO jbilling_table (id,name)
    VALUES (56,'notification_message_arch');


INSERT INTO jbilling_table (id,name)
    VALUES (57,'notification_message_arch_line');


INSERT INTO jbilling_table (id,name)
    VALUES (10,'base_user');


INSERT INTO jbilling_table (id,name)
    VALUES (12,'customer');


INSERT INTO jbilling_table (id,name)
    VALUES (27,'contact');


INSERT INTO jbilling_table (id,name)
    VALUES (76,'contact_field');


INSERT INTO jbilling_table (id,name)
    VALUES (44,'credit_card');


INSERT INTO jbilling_table (id,name)
    VALUES (3,'language');


INSERT INTO jbilling_table (id,name)
    VALUES (80,'payment_invoice');


INSERT INTO jbilling_table (id,name)
    VALUES (81,'subscriber_status');


INSERT INTO jbilling_table (id,name)
    VALUES (82,'mediation_cfg');


INSERT INTO jbilling_table (id,name)
    VALUES (83,'mediation_process');


INSERT INTO jbilling_table (id,name)
    VALUES (85,'blacklist');


INSERT INTO jbilling_table (id,name)
    VALUES (86,'mediation_record_line');


INSERT INTO jbilling_table (id,name)
    VALUES (87,'generic_status');


INSERT INTO jbilling_table (id,name)
    VALUES (88,'order_line_provisioning_status');


INSERT INTO jbilling_table (id,name)
    VALUES (89,'balance_type');


INSERT INTO jbilling_table (id,name)
    VALUES (91,'mediation_record_status');


INSERT INTO jbilling_table (id,name)
    VALUES (92,'process_run_status');


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('entity_delivery_method_map',4);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('user_role_map',13);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('entity_payment_method_map',26);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('report_entity_map',113);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('currency_entity_map',10);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('report_type_map',19);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('user_credit_card_map',5);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('permission_role_map',279);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('contact_map',6780);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('permission_type',9);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('period_unit',5);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('invoice_delivery_method',4);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('user_status',9);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('order_line_type',4);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('order_billing_type',3);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('menu_option',92);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('order_status',5);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('pluggable_task_type_category',22);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('pluggable_task_type',70);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('invoice_line_type',6);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('currency',11);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('report_type',10);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('payment_method',9);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('payment_result',5);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('event_log_module',10);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('event_log_message',17);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('preference_type',37);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('notification_message_type',20);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('role',6);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('country',238);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('list_entity',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('permission',135);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('list_field_entity',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('currency_exchange',25);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('pluggable_task_parameter',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('billing_process_configuration',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('order_period',2);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('report',20);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('partner_range',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('item_price',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('partner',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('entity',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('contact_type',2);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('promotion',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('pluggable_task',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('ach',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('payment_info_cheque',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('partner_payout',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('process_run_total_pm',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('report_user',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('report_field',1604);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('payment_authorization',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('billing_process',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('process_run',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('process_run_total',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('paper_invoice_batch',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('preference',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('notification_message',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('notification_message_section',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('notification_message_line',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('ageing_entity_step',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('item_type',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('item',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('event_log',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('purchase_order',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('order_line',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('invoice',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('invoice_line',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('order_process',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('payment',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('notification_message_arch',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('notification_message_arch_line',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('base_user',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('customer',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('contact',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('contact_field',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('credit_card',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('language',2);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('payment_invoice',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('subscriber_status',7);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('mediation_cfg',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('mediation_process',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('blacklist',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('mediation_record_line',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('generic_status',26);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('order_line_provisioning_status',1);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('balance_type',0);


INSERT INTO jbilling_seqs (name,next_id)
    VALUES ('mediation_record',0);


INSERT INTO language (id,code,description)
    VALUES (1,'en','English');


INSERT INTO language (id,code,description)
    VALUES (2,'pt','Portugu�s');


INSERT INTO list (id,legacy_name,title_key,OPTLOCK)
    VALUES (1,'customerSimple','list.customers.title',1);


INSERT INTO list (id,legacy_name,title_key,OPTLOCK)
    VALUES (2,'invoiceGeneral','list.invoices.title',1);


INSERT INTO list (id,legacy_name,title_key,OPTLOCK)
    VALUES (3,'order','list.orders.title',1);


INSERT INTO list (id,legacy_name,title_key,OPTLOCK)
    VALUES (4,'payment','list.payments.title',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (1,1,'user.prompt.id','c.id',1,1,'integer',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (2,1,'contact.list.organization','a.organization_name',0,1,'string',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (3,1,'customer.last_name','a.last_name',0,1,'string',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (4,1,'customer.first_name','a.first_name',0,1,'string',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (5,1,'user.prompt.username','c.user_name',0,1,'string',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (6,2,'invoice.id.prompt','i.id',0,0,'integer',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (7,2,'invoice.number','i.public_number',0,1,'string',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (8,2,'user.prompt.username','bu.user_name',0,1,'string',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (9,2,'invoice.id.prompt','i.id',1,1,'integer',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (12,2,' ','c.symbol',0,0,'string',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (13,2,'invoice.total','i.total',0,0,'float',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (14,2,'invoice.balance','i.balance',0,0,'float',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (15,2,'invoice.is_payable','i.to_process',0,0,'integer',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (16,3,'order.prompt.id','po.id',1,1,'integer',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (17,3,'user.prompt.username','bu.user_name',0,1,'string',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (18,3,'contact.list.organization','c.organization_name',0,1,'string',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (19,3,'order.prompt.createDate','po.create_datetime',0,1,'date',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (20,4,'payment.id','p.id',1,1,'integer',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (21,4,'user.prompt.username','u.user_name',0,1,'string',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (22,4,'contact.list.organization','co.organization_name',0,1,'string',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (23,4,'payment.date','p.create_datetime',0,1,'date',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (24,1,'creditcard.list.filter','CUSTOM_CC',0,1,'string',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (10,2,'invoice.create_date','i.create_datetime',0,1,'date',1);


INSERT INTO list_field (id,list_id,title_key,column_name,ordenable,searchable,data_type,OPTLOCK)
    VALUES (11,2,'contact.list.organization','co.organization_name',0,1,'string',1);


INSERT INTO menu_option (id,link,level_field)
    VALUES (1,'/order/list.jsp',1);


INSERT INTO menu_option (id,link,level_field)
    VALUES (2,'/payment/list.jsp',1);


INSERT INTO menu_option (id,link,level_field)
    VALUES (3,'/report/list.jsp',1);


INSERT INTO menu_option (id,link,level_field)
    VALUES (4,'/userAccount.do',1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (77,'/achMaintain.do?action=setup&mode=ach',2,11);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (59,'/user/listPartner.jsp',2,5);


INSERT INTO menu_option (id,link,level_field)
    VALUES (78,'/user/listSubAccounts.jsp?own=yes',1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (8,'/userAccount.do',2,4);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (9,'/user/edit.jsp',3,8);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (10,'/user/editContact.jsp',3,8);


INSERT INTO menu_option (id,link,level_field)
    VALUES (11,'/userAccount.do',1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (12,'/user/edit.jsp',2,11);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (13,'/contactEdit.do?action=setup',2,11);


INSERT INTO menu_option (id,link,level_field)
    VALUES (14,'/logout.do',1);


INSERT INTO menu_option (id,link,level_field)
    VALUES (15,'/item/list.jsp',1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (16,'/item/listType.jsp',2,15);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (17,'/item/create.jsp?create=yes',2,15);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (18,'/item/list.jsp',2,15);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (19,'/item/createType.jsp?create=yes',3,16);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (20,'/item/listType.jsp',3,16);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (24,'/payment/customerSelect.jsp?create=yes&cheque=yes',2,2);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (25,'/payment/customerSelect.jsp?create=yes&cc=yes',2,2);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (26,'/payment/list.jsp',2,2);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (27,'/order/newOrder.jsp',2,1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (28,'/order/list.jsp',2,1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (29,'/creditCardMaintain.do?action=setup&mode=creditCard',3,8);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (30,'/creditCardMaintain.do?action=setup&mode=creditCard',2,11);


INSERT INTO menu_option (id,link,level_field)
    VALUES (31,'/payment/listRefund.jsp',1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (32,'/payment/customerSelect.jsp?create=yes&cheque=yes&refund=yes',2,31);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (33,'/payment/customerSelect.jsp?create=yes&cc=yes&refund=yes',2,31);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (34,'/payment/listRefund.jsp',2,31);


INSERT INTO menu_option (id,link,level_field)
    VALUES (35,'/invoice/list.jsp',1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (36,'/invoice/list.jsp',2,35);


INSERT INTO menu_option (id,link,level_field)
    VALUES (37,'/processMaintain.do?action=view&latest=yes',1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (38,'/process/list.jsp',2,37);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (39,'/processConfigurationMaintain.do?action=setup&mode=configuration',2,37);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (40,'/processMaintain.do?action=view&latest=yes',2,37);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (41,'/processMaintain.do?action=review',2,37);


INSERT INTO menu_option (id,link,level_field)
    VALUES (42,'/notification/listTypes.jsp',1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (43,'/notification/listTypes.jsp',2,42);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (44,'/parameterMaintain.do?action=setup&mode=parameter&type=notification',2,42);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (45,'/notification/emails.jsp',2,42);


INSERT INTO menu_option (id,link,level_field)
    VALUES (46,'/user/list.jsp',1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (47,'/reportList.do?type=1',2,1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (48,'/reportList.do?type=2',2,35);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (49,'/reportList.do?type=3',2,2);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (50,'/reportList.do?type=4',2,31);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (51,'/reportList.do?type=5',2,46);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (52,'/user/list.jsp',2,46);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (53,'/report/list.jsp',2,3);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (54,'/user/create.jsp?create=yes&customer=yes&frompartner=yes',2,46);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (55,'/brandingMaintain.do?action=setup&mode=branding',2,4);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (56,'/currencyMaintain.do?action=setup',2,4);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (57,'/ageingMaintain.do?action=setup',2,4);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (58,'/user/create.jsp?create=yes',3,6);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (79,'HELP|page=items|anchor=',2,15);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (60,'/user/list.jsp',2,5);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (61,'/user/create.jsp?create=yes&partner=yes',3,59);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (62,'/user/listPartner.jsp',3,59);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (63,'/partnerDefaults.do?action=setup&mode=partnerDefault',3,59);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (64,'/reportList.do?type=6',3,59);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (65,'/reportList.do?type=5',3,60);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (66,'/user/list.jsp',3,60);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (67,'/user/create.jsp?create=yes&customer=yes',3,60);


INSERT INTO menu_option (id,link,level_field)
    VALUES (68,'/partnerMaintain.do?action=view&self=yes',1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (69,'/partnerMaintain.do?action=view&self=yes',2,68);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (70,'/user/payoutList.jsp',2,68);


INSERT INTO menu_option (id,link,level_field)
    VALUES (71,'/reportList.do?type=7',1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (72,'/reportTrigger.do?mode=partner&id=15',3,59);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (73,'/reportList.do?type=7',2,71);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (74,'/notificationPreference.do?action=setup&mode=notificationPreference',2,42);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (75,'/payment/customerSelect.jsp?create=yes&ach=yes',2,2);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (76,'/numberingMaintain.do?action=setup&mode=invoiceNumbering',2,35);


INSERT INTO menu_option (id,link,level_field)
    VALUES (5,'/user/maintain.jsp',1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (6,'/user/maintain.jsp',2,5);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (7,'/user/create.jsp?create=yes',3,6);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (80,'HELP|page=reports|anchor=',2,3);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (82,'HELP|page=users|anchor=',2,5);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (83,'HELP|page=orders|anchor=',2,1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (81,'HELP|page=process|anchor=',2,37);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (84,'HELP|page=notifications|anchor=',2,42);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (85,'HELP|page=system|anchor=',2,4);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (86,'HELP|page=payments|anchor=',2,2);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (87,'HELP|page=invoices|anchor=',2,35);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (89,'HELP|page=payments|anchor=refunds',2,31);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (90,'/payment/customerSelect.jsp?create=yes&paypal=yes',2,2);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (91,'/orderPeriod.do?action=setup',2,1);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (92,'/invoice/batchDownload.jsp',2,35);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (93,'/task.do?action=setup',2,4);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (94,'/invoice/logo.jsp',2,35);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (95,'/mediation/processList.do',2,37);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (96,'/mediation/configuration.do?action=setup',2,4);


INSERT INTO menu_option (id,link,level_field,parent_id)
    VALUES (97,'/system/blacklist.jsp',2,4);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (1,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (2,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (3,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (4,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (5,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (6,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (7,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (8,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (9,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (10,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (11,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (12,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (13,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (14,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (15,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (16,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (17,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (18,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (19,1);


INSERT INTO notification_message_type (id,OPTLOCK)
    VALUES (20,1);


INSERT INTO order_billing_type (id)
    VALUES (1);


INSERT INTO order_billing_type (id)
    VALUES (2);


INSERT INTO order_line_type (id,editable)
    VALUES (1,1);


INSERT INTO order_line_type (id,editable)
    VALUES (2,0);


INSERT INTO order_line_type (id,editable)
    VALUES (3,0);


INSERT INTO order_period (id,OPTLOCK)
    VALUES (1,1);


INSERT INTO payment_method (id)
    VALUES (1);


INSERT INTO payment_method (id)
    VALUES (2);


INSERT INTO payment_method (id)
    VALUES (3);


INSERT INTO payment_method (id)
    VALUES (4);


INSERT INTO payment_method (id)
    VALUES (5);


INSERT INTO payment_method (id)
    VALUES (6);


INSERT INTO payment_method (id)
    VALUES (7);


INSERT INTO payment_method (id)
    VALUES (8);


INSERT INTO payment_result (id)
    VALUES (1);


INSERT INTO payment_result (id)
    VALUES (2);


INSERT INTO payment_result (id)
    VALUES (3);


INSERT INTO payment_result (id)
    VALUES (4);


INSERT INTO period_unit (id)
    VALUES (1);


INSERT INTO period_unit (id)
    VALUES (2);


INSERT INTO period_unit (id)
    VALUES (3);


INSERT INTO period_unit (id)
    VALUES (4);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (1,1,1);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (2,1,2);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (3,1,3);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (4,1,4);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (5,1,5);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (6,1,6);


INSERT INTO permission (id,type_id)
    VALUES (7,2);


INSERT INTO permission (id,type_id)
    VALUES (8,2);


INSERT INTO permission (id,type_id)
    VALUES (9,2);


INSERT INTO permission (id,type_id)
    VALUES (10,2);


INSERT INTO permission (id,type_id)
    VALUES (11,2);


INSERT INTO permission (id,type_id)
    VALUES (12,3);


INSERT INTO permission (id,type_id)
    VALUES (13,3);


INSERT INTO permission (id,type_id)
    VALUES (14,3);


INSERT INTO permission (id,type_id)
    VALUES (15,3);


INSERT INTO permission (id,type_id)
    VALUES (16,3);


INSERT INTO permission (id,type_id)
    VALUES (17,3);


INSERT INTO permission (id,type_id)
    VALUES (18,3);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (19,1,7);


INSERT INTO permission (id,type_id)
    VALUES (20,3);


INSERT INTO permission (id,type_id)
    VALUES (21,3);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (22,1,8);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (23,1,9);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (24,1,10);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (25,1,11);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (26,1,12);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (27,1,13);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (28,1,14);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (29,1,15);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (30,1,16);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (31,1,17);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (32,1,18);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (33,1,19);


INSERT INTO permission (id,type_id)
    VALUES (34,4);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (35,1,20);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (39,1,24);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (40,1,25);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (41,1,26);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (42,1,27);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (43,1,28);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (44,1,29);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (45,1,30);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (46,1,31);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (47,1,32);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (48,1,33);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (49,1,34);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (50,1,35);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (51,1,36);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (52,1,37);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (53,1,38);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (54,1,39);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (55,1,40);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (56,1,41);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (57,1,42);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (58,1,43);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (59,1,44);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (60,1,45);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (61,1,46);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (62,1,47);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (63,1,48);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (64,1,49);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (65,1,50);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (66,1,51);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (67,5,1);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (68,5,2);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (69,5,3);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (70,5,4);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (71,5,5);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (72,5,6);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (73,5,7);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (74,5,8);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (75,5,9);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (76,5,10);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (77,1,52);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (78,1,53);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (79,1,54);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (80,1,55);


INSERT INTO permission (id,type_id)
    VALUES (81,3);


INSERT INTO permission (id,type_id)
    VALUES (82,3);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (83,1,56);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (84,5,11);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (85,1,57);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (86,1,6);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (87,1,59);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (88,1,60);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (89,1,61);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (90,1,62);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (91,1,63);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (92,1,64);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (93,1,65);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (94,1,66);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (95,1,67);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (96,1,68);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (97,1,69);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (98,1,70);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (99,5,12);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (100,5,13);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (101,5,14);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (102,5,15);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (103,5,16);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (104,1,71);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (105,1,72);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (106,1,73);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (107,1,74);


INSERT INTO permission (id,type_id)
    VALUES (108,6);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (109,1,75);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (110,1,76);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (111,5,17);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (112,5,18);


INSERT INTO permission (id,type_id)
    VALUES (113,7);


INSERT INTO permission (id,type_id)
    VALUES (114,3);


INSERT INTO permission (id,type_id)
    VALUES (115,2);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (116,1,77);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (117,1,78);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (118,1,79);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (119,1,80);


INSERT INTO permission (id,type_id)
    VALUES (120,8);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (122,5,19);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (123,1,82);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (124,1,81);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (128,1,86);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (125,1,83);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (129,1,87);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (126,1,85);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (127,1,84);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (131,1,89);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (132,1,90);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (133,1,91);


INSERT INTO permission (id,type_id)
    VALUES (134,3);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (135,1,92);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (136,1,93);


INSERT INTO permission (id,type_id)
    VALUES (137,9);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (138,1,94);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (139,5,20);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (140,5,21);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (141,5,22);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (142,5,23);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (143,1,95);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (144,1,96);


INSERT INTO permission (id,type_id)
    VALUES (145,3);


INSERT INTO permission (id,type_id,foreign_id)
    VALUES (146,1,97);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (1,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (2,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (3,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (4,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (80,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (83,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (85,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (5,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (87,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (89,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (90,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (91,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (92,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (105,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (88,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (93,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (94,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (95,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (6,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (86,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (19,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (22,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (23,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (24,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (29,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (30,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (31,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (32,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (33,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (35,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (39,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (40,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (41,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (42,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (43,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (44,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (46,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (47,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (48,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (49,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (50,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (51,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (52,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (53,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (54,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (55,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (56,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (57,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (58,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (59,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (60,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (62,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (63,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (64,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (65,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (78,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (67,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (68,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (69,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (70,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (71,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (72,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (73,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (74,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (75,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (76,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (84,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (99,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (100,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (101,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (102,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (103,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (7,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (8,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (9,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (10,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (11,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (12,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (13,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (15,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (16,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (17,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (20,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (81,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (34,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (1,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (2,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (3,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (4,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (15,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (80,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (83,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (85,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (5,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (87,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (89,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (90,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (91,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (92,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (105,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (88,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (93,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (94,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (95,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (6,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (86,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (19,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (22,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (23,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (24,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (29,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (30,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (31,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (32,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (33,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (35,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (39,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (40,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (41,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (42,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (43,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (44,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (46,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (47,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (48,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (49,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (50,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (51,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (52,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (53,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (54,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (55,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (56,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (57,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (58,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (59,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (60,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (62,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (63,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (64,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (65,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (67,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (68,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (69,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (70,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (71,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (72,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (73,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (74,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (75,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (76,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (84,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (99,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (100,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (101,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (102,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (103,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (78,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (7,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (9,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (10,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (11,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (13,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (47,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (16,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (17,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (20,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (81,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (34,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (1,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (2,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (3,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (4,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (5,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (87,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (89,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (90,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (91,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (92,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (105,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (88,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (93,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (94,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (95,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (6,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (86,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (19,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (22,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (23,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (24,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (29,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (32,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (39,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (40,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (41,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (42,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (43,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (44,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (46,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (109,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (48,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (49,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (50,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (51,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (52,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (53,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (55,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (56,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (62,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (63,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (64,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (65,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (67,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (68,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (69,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (71,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (73,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (74,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (75,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (76,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (84,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (78,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (7,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (10,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (11,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (14,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (16,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (17,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (20,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (82,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (1,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (2,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (104,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (106,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (4,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (96,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (97,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (98,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (22,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (23,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (24,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (40,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (41,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (43,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (44,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (46,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (50,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (51,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (7,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (11,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (18,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (21,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (82,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (61,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (77,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (79,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (99,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (100,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (101,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (1,5);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (2,5);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (109,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (109,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (25,5);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (26,5);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (27,5);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (40,5);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (41,5);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (43,5);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (45,5);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (46,5);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (50,5);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (51,5);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (107,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (107,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (108,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (108,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (108,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (108,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (109,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (109,5);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (110,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (110,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (111,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (112,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (111,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (112,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (111,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (112,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (113,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (113,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (113,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (114,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (114,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (114,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (115,1);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (115,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (115,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (70,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (72,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (114,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (99,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (100,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (101,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (102,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (103,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (116,5);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (42,4);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (117,5);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (118,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (119,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (122,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (123,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (124,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (125,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (125,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (126,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (127,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (128,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (129,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (131,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (132,5);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (133,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (134,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (134,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (135,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (135,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (136,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (137,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (138,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (139,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (139,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (140,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (140,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (141,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (141,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (142,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (142,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (143,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (144,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (145,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (145,3);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (146,2);


INSERT INTO permission_role_map (permission_id,role_id)
    VALUES (146,3);


INSERT INTO permission_type (id,description)
    VALUES (1,'Menu option');


INSERT INTO permission_type (id,description)
    VALUES (2,'User creation');


INSERT INTO permission_type (id,description)
    VALUES (3,'User edition');


INSERT INTO permission_type (id,description)
    VALUES (4,'Item edition');


INSERT INTO permission_type (id,description)
    VALUES (5,'Reports');


INSERT INTO permission_type (id,description)
    VALUES (6,'Orders');


INSERT INTO permission_type (id,description)
    VALUES (7,'Inovices');


INSERT INTO permission_type (id,description)
    VALUES (8,'Web Services');


INSERT INTO permission_type (id,description)
    VALUES (9,'Server Access');


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (1,1,'com.sapienter.jbilling.server.pluggableTask.BasicLineTotalTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (13,4,'com.sapienter.jbilling.server.pluggableTask.CalculateDueDateDfFm',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (3,4,'com.sapienter.jbilling.server.pluggableTask.CalculateDueDate',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (4,4,'com.sapienter.jbilling.server.pluggableTask.BasicCompositionTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (5,2,'com.sapienter.jbilling.server.pluggableTask.BasicOrderFilterTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (6,3,'com.sapienter.jbilling.server.pluggableTask.BasicInvoiceFilterTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (7,5,'com.sapienter.jbilling.server.pluggableTask.BasicOrderPeriodTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (8,6,'com.sapienter.jbilling.server.pluggableTask.PaymentAuthorizeNetTask',2);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (14,3,'com.sapienter.jbilling.server.pluggableTask.NoInvoiceFilterTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (10,8,'com.sapienter.jbilling.server.pluggableTask.BasicPaymentInfoTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (11,6,'com.sapienter.jbilling.server.pluggableTask.PaymentPartnerTestTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (12,7,'com.sapienter.jbilling.server.pluggableTask.PaperInvoiceNotificationTask',1);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (2,1,'com.sapienter.jbilling.server.pluggableTask.GSTTaxTask',2);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (15,9,'com.sapienter.jbilling.server.pluggableTask.BasicPenaltyTask',1);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (16,2,'com.sapienter.jbilling.server.pluggableTask.OrderFilterAnticipatedTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (9,7,'com.sapienter.jbilling.server.pluggableTask.BasicEmailNotificationTask',6);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (17,5,'com.sapienter.jbilling.server.pluggableTask.OrderPeriodAnticipateTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (19,6,'com.sapienter.jbilling.server.pluggableTask.PaymentEmailAuthorizeNetTask',1);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (20,10,'com.sapienter.jbilling.server.pluggableTask.ProcessorEmailAlarmTask',3);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (21,6,'com.sapienter.jbilling.server.pluggableTask.PaymentFakeTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (22,6,'com.sapienter.jbilling.server.payment.tasks.PaymentRouterCCFTask',2);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (23,11,'com.sapienter.jbilling.server.user.tasks.BasicSubscriptionStatusManagerTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (24,6,'com.sapienter.jbilling.server.user.tasks.PaymentACHCommerceTask',5);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (25,12,'com.sapienter.jbilling.server.payment.tasks.NoAsyncParameters',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (26,12,'com.sapienter.jbilling.server.payment.tasks.RouterAsyncParameters',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (27,6,'com.sapienter.jbilling.server.pluggableTask.PaymentEmailAuthorizeNetTask',1);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (28,13,'com.sapienter.jbilling.server.item.tasks.BasicItemManager',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (29,13,'com.sapienter.jbilling.server.item.tasks.RulesItemManager',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (30,1,'com.sapienter.jbilling.server.order.task.RulesLineTotalTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (31,14,'com.sapienter.jbilling.server.item.tasks.RulesPricingTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (32,15,'com.sapienter.jbilling.server.mediation.task.SeparatorFileReader',2);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (33,16,'com.sapienter.jbilling.server.mediation.task.RulesMediationTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (34,15,'com.sapienter.jbilling.server.mediation.task.FixedFileReader',2);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (35,8,'com.sapienter.jbilling.server.user.tasks.PaymentInfoNoValidateTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (36,7,'com.sapienter.jbilling.server.notification.task.TestNotificationTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (37,5,'com.sapienter.jbilling.server.process.task.ProRateOrderPeriodTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (38,4,'com.sapienter.jbilling.server.process.task.DailyProRateCompositionTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (39,6,'com.sapienter.jbilling.server.payment.tasks.PaymentAtlasTask',5);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (40,17,'com.sapienter.jbilling.server.order.task.RefundOnCancelTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (41,17,'com.sapienter.jbilling.server.order.task.CancellationFeeRulesTask',1);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (42,6,'com.sapienter.jbilling.server.payment.tasks.PaymentFilterTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (43,17,'com.sapienter.jbilling.server.payment.blacklist.tasks.BlacklistUserStatusTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (44,15,'com.sapienter.jbilling.server.mediation.task.JDBCReader',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (45,15,'com.sapienter.jbilling.server.mediation.task.MySQLReader',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (46,17,'com.sapienter.jbilling.server.provisioning.task.ProvisioningCommandsRulesTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (47,18,'com.sapienter.jbilling.server.provisioning.task.TestExternalProvisioningTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (48,18,'com.sapienter.jbilling.server.provisioning.task.CAIProvisioningTask',2);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (49,6,'com.sapienter.jbilling.server.payment.tasks.PaymentRouterCurrencyTask',2);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (50,18,'com.sapienter.jbilling.server.provisioning.task.MMSCProvisioningTask',5);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (51,3,'com.sapienter.jbilling.server.invoice.task.NegativeBalanceInvoiceFilterTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (52,17,'com.sapienter.jbilling.server.invoice.task.FileInvoiceExportTask',1);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (53,17,'com.sapienter.jbilling.server.system.event.task.InternalEventsRulesTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (54,17,'com.sapienter.jbilling.server.user.balance.DynamicBalanceManagerTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (55,19,'com.sapienter.jbilling.server.user.tasks.UserBalanceValidatePurchaseTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (56,19,'com.sapienter.jbilling.server.user.tasks.RulesValidatePurchaseTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (57,6,'com.sapienter.jbilling.server.payment.tasks.PaymentsGatewayTask',4);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (59,13,'com.sapienter.jbilling.server.order.task.RulesItemManager2',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (60,1,'com.sapienter.jbilling.server.order.task.RulesLineTotalTask2',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (61,14,'com.sapienter.jbilling.server.item.tasks.RulesPricingTask2',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (62,17,'com.sapienter.jbilling.server.payment.tasks.SaveCreditCardExternallyTask',1);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (63,6,'com.sapienter.jbilling.server.pluggableTask.PaymentFakeExternalStorage',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (64,6,'com.sapienter.jbilling.server.payment.tasks.PaymentWorldPayTask',3);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (65,6,'com.sapienter.jbilling.server.payment.tasks.PaymentWorldPayExternalTask',3);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (66,17,'com.sapienter.jbilling.server.user.tasks.AutoRechargeTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (67,6,'com.sapienter.jbilling.server.payment.tasks.PaymentBeanstreamTask',3);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (68,6,'com.sapienter.jbilling.server.payment.tasks.PaymentSageTask',2);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (69,20,'com.sapienter.jbilling.server.process.task.BasicBillingProcessFilterTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (70,20,'com.sapienter.jbilling.server.process.task.BillableUsersBillingProcessFilterTask',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (71,21,'com.sapienter.jbilling.server.mediation.task.SaveToFileMediationErrorHandler',0);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (73,21,'com.sapienter.jbilling.server.mediation.task.SaveToJDBCMediationErrorHandler',1);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (75,6,'com.sapienter.jbilling.server.payment.tasks.PaymentPaypalExternalTask',3);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (76,6,'com.sapienter.jbilling.server.payment.tasks.PaymentAuthorizeNetCIMTask',2);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (77,6,'com.sapienter.jbilling.server.payment.tasks.PaymentMethodRouterTask',4);


INSERT INTO pluggable_task_type (id,category_id,class_name,min_parameters)
    VALUES (78,23,'com.sapienter.jbilling.server.rule.task.VelocityRulesGeneratorTask',2);


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (1,'order processing task','com.sapienter.jbilling.server.pluggableTask.OrderProcessingTask');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (2,'order_filter task','com.sapienter.jbilling.server.pluggableTask.OrderFilterTask');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (3,'invoice filter task','com.sapienter.jbilling.server.pluggableTask.InvoiceFilterTask');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (4,'invoice composition task','com.sapienter.jbilling.server.pluggableTask.InvoiceCompositionTask');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (5,'order period calculation task','com.sapienter.jbilling.server.pluggableTask.OrderPeriodTask');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (6,'payment processing task','com.sapienter.jbilling.server.pluggableTask.PaymentTask');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (7,'notification task','com.sapienter.jbilling.server.pluggableTask.NotificationTask');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (8,'payment information task','com.sapienter.jbilling.server.pluggableTask.PaymentInfoTask');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (9,'invoice overdue penalty','com.sapienter.jbilling.server.pluggableTask.PenaltyTask');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (10,'processor alarm task','com.sapienter.jbilling.server.pluggableTask.ProcessorAlarm');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (11,'subscription status manager','com.sapienter.jbilling.server.user.tasks.ISubscriptionStatusManager');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (12,'async processor parameters','com.sapienter.jbilling.server.payment.tasks.IAsyncPaymentParameters');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (13,'item purchase manager','com.sapienter.jbilling.server.item.tasks.IItemPurchaseManager');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (14,'item pricing (rating)','com.sapienter.jbilling.server.item.tasks.IPricing');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (15,'Mediation Reader','com.sapienter.jbilling.server.mediation.task.IMediationReader');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (16,'Mediation Processor','com.sapienter.jbilling.server.mediation.task.IMediationProcess');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (17,'Internal events','com.sapienter.jbilling.server.system.event.task.IInternalEventsTask');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (18,'External Provisioning','com.sapienter.jbilling.server.provisioning.task.IExternalProvisioning');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (19,'Validate Purchase','com.sapienter.jbilling.server.user.tasks.IValidatePurchaseTask');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (20,'BillingProcessFilterTask','com.sapienter.jbilling.server.process.task.IBillingProcessFilterTask');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (21,'Mediation Error Handler','com.sapienter.jbilling.server.mediation.task.IMediationErrorHandler');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (22,'Scheduled Tasks','com.sapienter.jbilling.server.process.task.IScheduledTask');


INSERT INTO pluggable_task_type_category (id,description,interface_name)
    VALUES (23,'Rules Generator','com.sapienter.jbilling.server.rule.task.IRulesGenerator');


INSERT INTO preference_type (id)
    VALUES (1);


INSERT INTO preference_type (id,int_def_value)
    VALUES (25,0);


INSERT INTO preference_type (id,int_def_value)
    VALUES (26,20);


INSERT INTO preference_type (id)
    VALUES (4);


INSERT INTO preference_type (id)
    VALUES (5);


INSERT INTO preference_type (id)
    VALUES (6);


INSERT INTO preference_type (id)
    VALUES (7);


INSERT INTO preference_type (id)
    VALUES (8);


INSERT INTO preference_type (id)
    VALUES (9);


INSERT INTO preference_type (id)
    VALUES (10);


INSERT INTO preference_type (id)
    VALUES (11);


INSERT INTO preference_type (id)
    VALUES (12);


INSERT INTO preference_type (id)
    VALUES (13);


INSERT INTO preference_type (id)
    VALUES (14);


INSERT INTO preference_type (id)
    VALUES (15);


INSERT INTO preference_type (id)
    VALUES (16);


INSERT INTO preference_type (id)
    VALUES (17);


INSERT INTO preference_type (id)
    VALUES (18);


INSERT INTO preference_type (id,int_def_value)
    VALUES (27,0);


INSERT INTO preference_type (id)
    VALUES (22);


INSERT INTO preference_type (id)
    VALUES (23);


INSERT INTO preference_type (id,str_def_value)
    VALUES (2,'/billing/css/jbilling.css');


INSERT INTO preference_type (id,str_def_value)
    VALUES (3,'/billing/graphics/jb-log-small.jpg');


INSERT INTO preference_type (id,int_def_value)
    VALUES (20,1);


INSERT INTO preference_type (id,int_def_value)
    VALUES (24,0);


INSERT INTO preference_type (id,int_def_value)
    VALUES (19,1);


INSERT INTO preference_type (id,int_def_value)
    VALUES (21,0);


INSERT INTO preference_type (id)
    VALUES (28);


INSERT INTO preference_type (id,str_def_value)
    VALUES (31,'2000-01-01');


INSERT INTO preference_type (id)
    VALUES (30);


INSERT INTO preference_type (id,str_def_value)
    VALUES (29,'https://www.paypal.com/en_US/i/btn/x-click-but6.gif');


INSERT INTO preference_type (id,int_def_value)
    VALUES (32,0);


INSERT INTO preference_type (id,int_def_value)
    VALUES (33,0);


INSERT INTO preference_type (id,float_def_value)
    VALUES (34,0);


INSERT INTO preference_type (id,int_def_value)
    VALUES (35,0);


INSERT INTO preference_type (id,int_def_value)
    VALUES (36,1);


INSERT INTO preference_type (id,int_def_value)
    VALUES (37,0);


INSERT INTO preference_type (id,int_def_value)
    VALUES (38,1);


INSERT INTO preference_type (id,int_def_value)
    VALUES (39,0);


INSERT INTO preference_type (id,int_def_value)
    VALUES (40,0);


INSERT INTO preference_type (id,int_def_value)
    VALUES (41,0);


INSERT INTO preference_type (id,int_def_value)
    VALUES (42,0);


INSERT INTO preference_type (id,int_def_value)
    VALUES (43,0);


INSERT INTO preference_type (id,int_def_value)
    VALUES (44,0);


INSERT INTO preference_type (id,int_def_value)
    VALUES (45,0);


INSERT INTO preference_type (id,int_def_value)
    VALUES (46,0);


INSERT INTO preference_type (id,int_def_value)
    VALUES (47,0);


INSERT INTO preference_type (id,int_def_value)
    VALUES (48,1);


INSERT INTO preference_type (id)
    VALUES (49);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (1,'report.general_orders.title','report.general_orders.instr','base_user, purchase_order, order_period, order_billing_type, international_description id, jbilling_table bt, international_description id2, jbilling_table bt2, contact','contact.user_id = base_user.id and base_user.id = purchase_order.user_id and bt.name = ''order_period'' and bt2.name = ''order_billing_type'' and id.table_id = bt.id and id2.table_id = bt2.id and id.foreign_id = order_period.id and id2.foreign_id = order_billing_type.id and purchase_order.period_id = order_period.id and purchase_order.billing_type_id = order_billing_type.id and id.language_id = id2.language_id',1,'/orderMaintain.do?action=view',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (2,'report.general_invoices.title','report.general_invoices.instr','base_user, invoice, currency','base_user.id = invoice.user_id and invoice.currency_id = currency.id',1,'/invoiceMaintain.do',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (3,'report.general_payments.title','report.general_payments.instr','base_user, payment, payment_method, payment_result, international_description id, jbilling_table bt, international_description id2, jbilling_table bt2','base_user.id = payment.user_id and bt.name = ''payment_method'' and bt2.name = ''payment_result'' and id.table_id = bt.id and id2.table_id = bt2.id and id.foreign_id = payment_method.id and id2.foreign_id = payment_result.id and payment.method_id = payment_method.id and payment.result_id = payment_result.id and id.language_id = id2.language_id',1,'/paymentMaintain.do?action=view',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (19,'report.item.title','report.item.instr','item_type, item_type_map, entity, international_description itd, item left outer join item_price left outer join currency on item_price.currency_id = currency.id on item.id = item_price.item_id','deleted = 0 and item.id = item_type_map.item_id and item_type.id = item_type_map.type_id and entity.id = item.entity_id and itd.language_id = entity.language_id and itd.table_id = 14 and itd.foreign_id = item.id and itd.psudo_column = ''description''',1,'/itemMaintain.do?action=setup&mode=item',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (5,'report.general_refunds.title','report.general_refunds.instr','base_user, payment, payment_method, payment_result, international_description id, jbilling_table bt, international_description id2, jbilling_table bt2','base_user.id = payment.user_id and bt.name = ''payment_method'' and bt2.name = ''payment_result'' and id.table_id = bt.id and id2.table_id = bt2.id and id.foreign_id = payment_method.id and id2.foreign_id = payment_result.id and payment.method_id = payment_method.id and payment.result_id = payment_result.id and id.language_id = id2.language_id',1,'/paymentMaintain.do?action=view',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,OPTLOCK)
    VALUES (6,'report.invoices_total.title','report.invoices_total.instr','base_user, invoice','base_user.id = invoice.user_id',0,1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,OPTLOCK)
    VALUES (7,'report.payments_total.title','report.payments_total.instr','base_user, payment','base_user.id = payment.user_id and payment.result_id in (1,4) ',0,1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,OPTLOCK)
    VALUES (8,'report.refunds_total.title','report.refunds_total.instr','base_user, payment','base_user.id = payment.user_id and payment.result_id in (1,4) ',0,1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,OPTLOCK)
    VALUES (9,'report.orders_total.title','report.orders_total.instr','base_user, purchase_order, order_line','base_user.id = purchase_order.user_id and purchase_order.id = order_line.order_id and purchase_order.deleted = 0 and order_line.deleted = 0',0,1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (10,'report.customers_overdue.title','report.customers_overdue.instr','base_user, invoice','base_user.id = invoice.user_id and invoice.deleted = 0 and to_process = 1',1,'/invoiceMaintain.do',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (11,'report.customers_carring.title','report.customers_carring.instr','base_user, invoice, currency','base_user.id = invoice.user_id and invoice.currency_id = currency.id and invoice.deleted = 0 and to_process = 1',1,'/invoiceMaintain.do',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (12,'report.partners_orders.title','report.partners_orders.instr','base_user, purchase_order, order_period, international_description id, jbilling_table bt, customer ','base_user.id = purchase_order.user_id and bt.name = ''order_period'' and id.table_id = bt.id and base_user.id = customer.user_id and id.foreign_id = order_period.id and purchase_order.status_id = 1 and purchase_order.deleted = 0 and purchase_order.period_id = order_period.id ',1,'/orderMaintain.do?action=view',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (13,'report.partners_payments.title','report.partners_payments.instr','base_user, payment, payment_method, payment_result, international_description id, jbilling_table bt, customer , international_description id2, jbilling_table bt2','base_user.id = payment.user_id and payment.deleted = 0 and payment.is_refund = 0 and bt.name = ''payment_method'' and bt2.name = ''payment_result'' and base_user.id = customer.user_id and id.table_id = bt.id and id2.table_id = bt2.id and id.foreign_id = payment_method.id and id2.foreign_id = payment_result.id and payment.method_id = payment_method.id and payment.result_id = payment_result.id and id.language_id = id2.language_id',1,'/paymentMaintain.do?action=view',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (14,'report.partners_refunds.title','report.partners_refunds.instr','base_user, payment, payment_method, payment_result, international_description id, jbilling_table bt, customer , international_description id2, jbilling_table bt2','base_user.id = payment.user_id and payment.deleted = 0 and payment.is_refund = 1 and bt.name = ''payment_method'' and bt2.name = ''payment_result'' and base_user.id = customer.user_id and id.table_id = bt.id and id2.table_id = bt2.id and id.foreign_id = payment_method.id and id2.foreign_id = payment_result.id and payment.method_id = payment_method.id and payment.result_id = payment_result.id and id.language_id = id2.language_id',1,'/paymentMaintain.do?action=view',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (16,'report.payouts.title','report.payouts.instr','partner, partner_payout, base_user, payment, payment_result,international_description id, jbilling_table bt','partner_payout.partner_id = partner.id and base_user.id = partner.user_id and partner.id = partner_payout.partner_id and payment.id = partner_payout.payment_id and bt.name = ''payment_result'' and bt.id = id.table_id and payment_result.id = payment.result_id and payment_result.id = id.foreign_id and base_user.deleted = 0',1,'/payout.do?action=view',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (17,'report.invoice_line.title','report.invoice_line.instr','base_user, currency, invoice, invoice_line_type, invoice_line left outer join item on invoice_line.item_id = item.id','base_user.id = invoice.user_id and invoice.currency_id = currency.id and invoice.id = invoice_line.invoice_id and invoice_line.type_id = invoice_line_type.id and invoice_line.deleted = 0 and invoice.is_review = 0',1,'/invoiceMaintain.do',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (18,'report.user.title','report.user.instr','base_user, contact_map, contact, jbilling_table bt1, user_status, user_role_map, jbilling_table bt2, jbilling_table bt3, international_description it1, international_description it2, language, international_description it3, country, jbilling_table bt4 ','base_user.id = contact_map.foreign_id and bt1.name = ''base_user'' and bt1.id = contact_map.table_id and contact_map.contact_id = contact.id  and base_user.status_id = user_status.id and base_user.id = user_role_map.user_id and bt2.name = ''user_status'' and bt3.name = ''role'' and it1.table_id = bt2.id and it1.foreign_id = user_status.id and it1.psudo_column = ''description'' and it2.table_id = bt3.id and it2.foreign_id = user_role_map.role_id and it2.psudo_column = ''title'' and it2.language_id = it1.language_id and base_user.deleted = 0 and base_user.language_id = language.id and contact.country_code = country.code and country.id = it3.foreign_id and it3.language_id = it2.language_id and it3.table_id = bt4.id and bt4.name = ''country'' and it3.psudo_column = ''description''',1,'/userMaintain.do?action=setup',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (4,'report.general_order_line.title','report.general_order_line.instr','base_user, purchase_order, order_line, order_line_type,international_description id, jbilling_table bt, international_description id2, international_description id3, international_description id4, generic_status gs','base_user.id = purchase_order.user_id and purchase_order.id = order_line.order_id and bt.name = ''order_line_type'' and id.table_id = bt.id and id.foreign_id = order_line_type.id and order_line.type_id = order_line_type.id and id2.table_id = 17 and id2.foreign_id = purchase_order.period_id and id2.language_id = id.language_id and id3.table_id = 19 and id3.foreign_id = purchase_order.billing_type_id and id3.language_id = id.language_id and id4.table_id = 20 and id4.foreign_id = gs.status_value and gs.id = purchase_order.status_id and gs.dtype = ''order_status'' and id4.language_id = id.language_id',1,'/orderMaintain.do?action=view',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (15,'report.partners.title','report.partners.instr','partner, base_user, period_unit pu, international_description id, jbilling_table bt ','id.table_id = bt.id and bt.name = ''period_unit'' and id.foreign_id = pu.id and partner.period_unit_id = pu.id and id.psudo_column = ''description'' and base_user.id = partner.user_id and base_user.deleted = 0',1,'/partnerMaintain.do?action=view',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (20,'report.transactions.title','report.transactions.instr','base_user, payment, payment_method, payment_result, international_description id, international_description id2, payment_authorization pa','base_user.id = payment.user_id and id.table_id = 35 and id2.table_id = 41 and id.psudo_column = ''description'' and id2.psudo_column = ''description'' and id.foreign_id = payment_method.id and id2.foreign_id = payment_result.id and payment.method_id = payment_method.id and payment.result_id = payment_result.id and id.language_id = id2.language_id and pa.payment_id = payment.id and base_user.deleted = 0 and payment.deleted = 0',1,'/paymentMaintain.do?action=view',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (21,'report.subscriptions.title','report.subscriptions.instr','purchase_order po, base_user bu, user_role_map urm, order_line ol, item i, international_description id1, international_description id2, international_description id3','po.user_id = bu.id and po.deleted = 0 and bu.deleted = 0 and ol.deleted = 0 and i.deleted = 0 and ol.order_id = po.id and urm.user_id = bu.id and urm.role_id in (5) and po.period_id <> 1 and id1.table_id = 81 and id1.foreign_id = bu.subscriber_status and id1.psudo_column = ''description'' and id2.table_id = 14 and id2.foreign_id = i.id and id2.psudo_column = ''description'' and id2.language_id  = id1.language_id and i.id = ol.item_id and bu.entity_id = i.entity_id and id3.table_id = 20 and id3.psudo_column = ''description'' and id3.foreign_id = po.status_id and id3.language_id  = id2.language_id',1,'/userMaintain.do?action=setup',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (22,'report.transitions.title','report.transitions.instr','purchase_order po, base_user bu, user_role_map urm, order_line ol, item i, international_description id1, international_description id2, international_description id3, international_description id4, event_log el','po.user_id = bu.id and po.deleted = 0 and bu.deleted = 0 and ol.deleted = 0 and i.deleted = 0 and ol.order_id = po.id  and urm.user_id = bu.id  and urm.role_id in (5) and id1.table_id = 81 and id1.foreign_id = bu.subscriber_status and id1.psudo_column = ''description'' and id2.table_id = 14 and id2.foreign_id = i.id and id2.psudo_column = ''description'' and id2.language_id = id1.language_id and id3.table_id = 20 and id3.foreign_id = po.status_id and id3.psudo_column=''description'' and id3.language_id = id2.language_id and id4.table_id = 81 and id4.foreign_id = el.old_num and id4.psudo_column = ''description'' and id4.language_id = id3.language_id and i.id = ol.item_id  and po.period_id <> 1 and bu.entity_id = i.entity_id and el.foreign_id = bu.id  and el.entity_id = i.entity_id  and el.module_id = 2 and el.message_id = 20',1,'/userMaintain.do?action=setup',1);


INSERT INTO report (id,titlekey,instructionskey,tables_list,where_str,id_column,link,OPTLOCK)
    VALUES (23,'report.subscriptionTransitions.title','report.subscriptionTransitions.instr','purchase_order po, base_user bu, order_line ol, order_line ol1, international_description id1, international_description id2, international_description id3, international_description id4, event_log el','po.user_id = bu.id and po.deleted = 0 and bu.deleted = 0 and ol.id = el.foreign_id and ol1.id = el.old_num and ol.order_id = po.id and id1.table_id = 14 and id1.foreign_id = ol.item_id and id1.psudo_column = ''description'' and id2.table_id = 81 and id2.psudo_column = ''description'' and id2.foreign_id = bu.subscriber_status and id2.language_id = id1.language_id and bu.entity_id = el.entity_id and id3.table_id = 14 and id3.psudo_column = ''description'' and id3.foreign_id = ol1.item_id and id3.language_id = id1.language_id and id4.table_id = 20 and id4.psudo_column = ''description'' and id4.foreign_id = po.status_id and id4.language_id  = id1.language_id and el.module_id = 7 and el.message_id = 17',1,'/orderMaintain.do?action=view',1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1,1,1,'purchase_order','id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (2,1,1,'base_user','user_name','report.prompt.base_user.user_name',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (3,1,1,'purchase_order','id','report.prompt.purchase_order.id',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (4,1,3,'purchase_order','period_id','order.prompt.periodId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (5,1,4,'purchase_order','billing_type_id','order.prompt.billingTypeId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (6,1,5,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (7,1,5,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (8,1,6,'purchase_order','active_until','report.prompt.purchase_order.active_until',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (9,1,6,'purchase_order','active_until','report.prompt.purchase_order.active_until',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (10,1,7,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (11,1,7,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (12,1,8,'purchase_order','created_by','report.prompt.purchase_order.created_by',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (13,1,9,'purchase_order','status_id','report.prompt.purchase_order.status',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (14,1,10,'purchase_order','next_billable_day','order.prompt.nextBillableDay',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (15,1,10,'purchase_order','next_billable_day','order.prompt.nextBillableDay',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (16,1,10,'purchase_order','deleted','0',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (17,1,11,'base_user','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (18,1,11,'base_user','id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (19,1,12,'id','language_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (20,1,3,'id','content','order.prompt.period',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (21,1,4,'id2','content','order.prompt.billingType',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (22,1,1,'purchase_order','deleted','0',0,1,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (23,2,1,'invoice','id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (289,17,1,'invoice','id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (25,2,3,'base_user','user_name','user.prompt.username',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (26,2,99,'base_user','id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (27,2,4,'invoice','create_datetime','invoice.create_date',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (28,2,5,'invoice','create_datetime','invoice.create_date',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (29,2,6,'invoice','billing_process_id','process.external.id',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (30,2,7,'invoice','delegated_invoice_id','invoice.delegated.prompt',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (31,2,8,'invoice','due_date','invoice.dueDate.prompt',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (32,2,9,'invoice','due_date','invoice.dueDate.prompt',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (418,4,10,'purchase_order','status_id','report.prompt.purchase_order.status',0,0,'integer','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (34,2,11,'invoice','total','invoice.total.prompt',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (35,2,12,'invoice','payment_attempts','invoice.attempts.prompt',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (36,2,13,'international_description','content','invoice.is_payable',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (37,2,14,'invoice','balance','invoice.balance.prompt',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (38,2,15,'invoice','carried_balance','invoice.carriedBalance.prompt',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (39,2,16,'invoice','deleted','0',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (40,2,17,'invoice','is_review','0',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (41,2,18,'base_user','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (42,3,1,'payment','id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (43,3,2,'payment','id','payment.id',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (44,3,3,'base_user','user_name','user.prompt.username',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (45,3,11,'base_user','id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (46,3,4,'payment','attempt','payment.attempt',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (47,3,5,'payment','result_id','payment.resultId',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (48,3,6,'payment','amount','payment.amount',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (49,3,8,'payment','create_datetime','payment.createDate',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (50,3,8,'payment','create_datetime','payment.createDate',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (51,3,9,'payment','payment_date','payment.date',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (52,3,8,'payment','payment_date','payment.date',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (53,3,9,'payment','method_id','payment.methodId',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (54,3,12,'payment','deleted','0',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (55,3,12,'payment','is_refund','0',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (195,15,18,'base_user','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (196,15,19,'id','language_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (58,3,12,'id','content','payment.method',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (59,3,13,'id2','content','payment.result',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (60,4,0,'purchase_order','id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (61,4,1,'base_user','user_name','user.prompt.username',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (62,4,2,'purchase_order','id','order.external.prompt.id',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (63,4,3,'order_line','item_id','item.prompt.number',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (64,4,4,'order_line','type_id','order.line.prompt.typeid',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (65,4,5,'id','content','order.line.prompt.type',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (66,4,6,'order_line','description','order.line.prompt.description',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (67,4,7,'order_line','amount','order.line.prompt.amount',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (68,4,8,'order_line','quantity','order.line.prompt.quantity',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (69,4,9,'order_line','price','order.line.prompt.price',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (70,4,10,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (71,4,10,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (72,4,0,'purchase_order','deleted','0',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (73,4,0,'order_line','deleted','0',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (74,4,0,'base_user','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (75,4,1,'id','language_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (76,5,1,'payment','id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (77,5,2,'payment','id','payment.id',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (78,5,3,'base_user','user_name','user.prompt.username',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (79,5,11,'base_user','id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (80,5,4,'payment','attempt','payment.attempt',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (81,5,5,'payment','result_id','payment.resultId',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (82,5,6,'payment','amount','payment.amount',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (83,5,8,'payment','create_datetime','payment.createDate',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (84,5,8,'payment','create_datetime','payment.createDate',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (85,5,9,'payment','payment_date','payment.date',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (86,5,8,'payment','payment_date','payment.date',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (87,5,9,'payment','method_id','payment.methodId',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (88,5,10,'payment','payout_id','payout.external.prompt.id',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (89,5,12,'payment','deleted','0',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (90,5,12,'payment','is_refund','1',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (197,16,1,'partner_payout','id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (198,16,2,'partner','id','partner.external.prompt.id',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (93,5,12,'id','content','payment.method',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (94,5,13,'id2','content','payment.result',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,function_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (95,6,1,'invoice','total','invoice.total.prompt','sum',0,1,'float',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (96,6,1,'invoice','create_datetime','invoice.create_date',0,0,'date','>=',0,0,0,0,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (97,6,2,'invoice','create_datetime','invoice.create_date',0,0,'date','<',0,0,0,0,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (98,6,0,'invoice','deleted','0',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (99,6,0,'invoice','is_review','0',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (100,6,0,'base_user','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,function_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (101,7,1,'payment','amount','payment.amount','sum',0,1,'float',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (102,7,2,'payment','payment_date','payment.date',0,0,'date','>=',0,0,0,0,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (103,7,3,'payment','payment_date','payment.date',0,0,'date','<',0,0,0,0,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (104,7,0,'payment','deleted','0',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (105,7,0,'payment','is_refund','0',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (106,7,14,'base_user','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,function_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (107,8,1,'payment','amount','payment.amount','sum',0,1,'float',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (108,8,2,'payment','payment_date','payment.date',0,0,'date','>=',0,0,0,0,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (109,8,3,'payment','payment_date','payment.date',0,0,'date','<',0,0,0,0,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (110,8,0,'payment','deleted','0',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (111,8,0,'payment','is_refund','1',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (112,8,14,'base_user','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (113,9,1,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date','>=',0,0,0,0,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (114,9,2,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date','<',0,0,0,0,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,function_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (115,9,1,'order_line','amount','order.line.prompt.amount','sum',0,1,'float',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (116,9,0,'base_user','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (117,10,1,'invoice','id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (118,10,2,'invoice','id','invoice.id.prompt',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (119,10,3,'base_user','user_name','user.prompt.username',0,1,'string',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (120,10,4,'invoice','create_datetime','invoice.create_date',0,1,'date',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (121,10,5,'invoice','total','invoice.total.prompt',0,1,'float',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (122,10,10,'base_user','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (123,10,11,'invoice','due_date','?','invoice.due_date',0,1,'date','<',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (124,11,1,'invoice','id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (125,11,2,'invoice','id','invoice.number',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (126,11,3,'base_user','user_name','user.prompt.username',0,1,'string',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (127,11,4,'invoice','create_datetime','invoice.create_date',0,1,'date',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (128,11,5,'currency','symbol','currency.external.prompt.name',0,1,'string',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (129,11,6,'invoice','total','invoice.total.prompt',0,1,'float',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (130,11,99,'base_user','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (131,11,99,'invoice','carried_balance','0','invoice.due_date',0,1,'float','>',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (132,12,1,'purchase_order','id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (133,12,2,'base_user','id','customer.prompt.id',0,1,'integer',0,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (134,12,3,'base_user','user_name','report.prompt.base_user.user_name',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (135,12,4,'purchase_order','id','report.prompt.purchase_order.id',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (136,12,5,'purchase_order','period_id','order.prompt.periodId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (137,12,6,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (138,12,7,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (139,12,8,'purchase_order','active_until','report.prompt.purchase_order.active_until',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (140,12,9,'purchase_order','active_until','report.prompt.purchase_order.active_until',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (141,12,10,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (142,12,11,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (143,12,12,'customer','partner_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (144,12,13,'id','language_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (145,12,14,'id','content','order.prompt.period',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (146,13,1,'payment','id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (147,13,2,'payment','id','payment.id',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (419,10,2,'invoice','public_number','invoice.number.prompt',0,1,'string',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (149,13,4,'base_user','id','customer.prompt.id',0,1,'integer',0,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (150,13,5,'payment','attempt','payment.attempt',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (151,13,6,'payment','result_id','payment.resultId',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (152,13,7,'id2','content','payment.result',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (153,13,8,'payment','amount','payment.amount',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (154,13,9,'payment','create_datetime','payment.createDate',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (155,13,10,'payment','create_datetime','payment.createDate',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (156,13,11,'payment','payment_date','payment.date',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (157,13,12,'payment','payment_date','payment.date',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (158,13,13,'payment','method_id','payment.methodId',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (159,13,14,'id','content','payment.method',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (160,13,15,'customer','partner_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (161,13,16,'id','language_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (162,14,1,'payment','id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (163,14,2,'payment','id','payment.id',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (164,14,3,'base_user','user_name','user.prompt.username',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (165,14,4,'base_user','id','customer.prompt.id',0,1,'integer','=',0,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (166,14,5,'payment','attempt','payment.attempt',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (167,14,6,'payment','result_id','payment.resultId',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (168,14,7,'id2','content','payment.result',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (169,14,8,'payment','amount','payment.amount',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (170,14,9,'payment','create_datetime','payment.createDate',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (171,14,10,'payment','create_datetime','payment.createDate',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (172,14,11,'payment','payment_date','payment.date',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (173,14,12,'payment','payment_date','payment.date',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (174,14,13,'payment','method_id','payment.methodId',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (175,14,14,'id','content','payment.method',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (176,14,15,'customer','partner_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (177,14,16,'id','language_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (178,15,1,'base_user','id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (179,15,2,'partner','id','partner.prompt.id',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (180,15,3,'base_user','user_name','user.prompt.username',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (181,15,4,'partner','balance','partner.prompt.balance',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (182,15,5,'partner','total_payments','partner.prompt.totalPayments',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (183,15,6,'partner','total_refunds','partner.prompt.totalRefunds',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (184,15,7,'partner','total_payouts','partner.prompt.totalPayouts',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (185,15,8,'partner','percentage_rate','partner.prompt.rate',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (186,15,9,'partner','referral_fee','partner.prompt.fee',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (187,15,10,'partner','one_time','partner.prompt.onetime',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (188,15,11,'partner','period_unit_id','partner.prompt.periodId',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (189,15,12,'id','content','partner.prompt.period',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (190,15,13,'partner','period_value','partner.prompt.periodValue',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (191,15,14,'partner','next_payout_date','partner.prompt.nextPayout',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (192,15,15,'partner','next_payout_date','partner.prompt.nextPayout',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (193,15,16,'partner','automatic_process','partner.prompt.process',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (194,15,17,'partner','related_clerk','partner.prompt.clerk',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (265,35,1,'base_user','user_name','','report.prompt.base_user.user_name',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (266,35,1,'purchase_order','id','','report.prompt.purchase_order.id',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (267,35,1,'contact','organization_name','contact.prompt.organizationName',0,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (268,35,1,'contact','first_name','contact.prompt.firstName',0,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (199,16,3,'base_user','user_name','user.prompt.username',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (200,16,4,'partner_payout','starting_date','payout.prompt.startDate',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (201,16,5,'partner_payout','ending_date','payout.prompt.endDate',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (202,16,6,'partner_payout','payments_amount','payout.prompt.payments',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (203,16,7,'partner_payout','refunds_amount','payout.prompt.refunds',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (204,16,8,'partner_payout','balance_left','payout.prompt.balance',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (205,16,9,'payment','amount','payout.prompt.paid',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (206,16,10,'payment','create_datetime','payout.prompt.date',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (207,16,11,'payment','create_datetime','payout.prompt.date',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (208,16,12,'payment','method_id','payment.methodId',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (209,16,13,'id','content','payment.method',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (210,16,14,'base_user','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (211,16,15,'id','language_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (269,35,1,'contact','last_name','contact.prompt.lastName',0,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (270,35,1,'contact','phone_phone_number','contact.prompt.phoneNumber',0,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (271,35,3,'purchase_order','period_id','','order.prompt.periodId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (272,35,3,'id','content','order.prompt.period',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (273,35,4,'purchase_order','billing_type_id','','order.prompt.billingTypeId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (274,35,4,'id2','content','order.prompt.billingType',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (275,35,5,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (276,35,5,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (277,35,6,'purchase_order','active_until',1,'2004-08-01','report.prompt.purchase_order.active_until',0,1,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (278,35,6,'purchase_order','active_until','2004-09-01','report.prompt.purchase_order.active_until',0,0,'date','<',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (279,35,7,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (280,35,7,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (281,35,8,'purchase_order','created_by','','report.prompt.purchase_order.created_by',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (282,35,9,'purchase_order','status_id','','report.prompt.purchase_order.status',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (283,35,10,'purchase_order','next_billable_day','order.prompt.nextBillableDay',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (284,35,10,'purchase_order','next_billable_day','order.prompt.nextBillableDay',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (212,2,0,'purchase_order','id','report.prompt.purchase_order.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (213,2,0,'purchase_order','deleted','0','report.prompt.purchase_order.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (214,2,0,'order_line','deleted','0','report.prompt.order_line.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (215,2,0,'base_user','entity_id','277','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (216,2,1,'base_user','user_name','','user.prompt.username',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (217,2,1,'id','language_id','1','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (218,2,2,'purchase_order','id','','order.external.prompt.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (219,2,3,'order_line','item_id','70','item.prompt.number',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (220,2,4,'order_line','type_id','','order.line.prompt.typeid',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (221,2,5,'id','content','order.line.prompt.type',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (222,2,6,'order_line','description','','order.line.prompt.description',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (223,2,7,'order_line','amount','','order.line.prompt.amount',0,0,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (224,2,8,'order_line','quantity','','order.line.prompt.quantity','sum',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (225,2,9,'order_line','price','','order.line.prompt.price',0,0,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (226,2,10,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (227,2,10,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (56,3,12,'base_user','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (57,3,14,'id','language_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (92,5,14,'id','language_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (91,5,12,'base_user','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (285,35,10,'purchase_order','deleted','0','report.prompt.purchase_order.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (286,35,11,'base_user','entity_id','?','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (287,35,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (288,35,12,'id','language_id','?','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (332,17,10,'invoice','create_datetime','invoice.createDateTime.prompt',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (290,17,2,'invoice','id','invoice.id.prompt',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (291,17,2,'invoice','public_number','invoice.number.prompt',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (292,17,2,'invoice_line','type_id','report.prompt.invoice_line.type_id',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (293,17,3,'invoice_line_type','description','report.prompt.invoice_line.type',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (294,17,4,'invoice_line','item_id','report.prompt.invoice_line.item_id',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (295,17,5,'invoice_line','description','report.prompt.invoice_line.description',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (296,17,6,'invoice_line','amount','report.prompt.invoice_line.amount',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (297,17,7,'invoice_line','quantity','report.prompt.invoice_line.quantity',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (298,17,8,'invoice_line','price','report.prompt.invoice_line.price',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (299,17,9,'currency','symbol','currency.external.prompt.name',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (260,1,1,'contact','organization_name','contact.prompt.organizationName',0,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (261,1,1,'contact','first_name','contact.prompt.firstName',0,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (262,1,1,'contact','last_name','contact.prompt.lastName',0,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (263,1,1,'contact','phone_phone_number','contact.prompt.phoneNumber',0,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (300,17,10,'base_user','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (301,18,1,'base_user','id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (302,18,2,'base_user','id','user.prompt.id',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (303,18,3,'base_user','user_name','user.prompt.username',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (304,18,4,'base_user','language_id','report.prompt.user.languageCode',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (305,18,4,'language','description','user.prompt.language',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (306,18,5,'base_user','status_id','report.prompt.user.statusCode',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (307,18,6,'it1','content','user.prompt.status',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (308,18,7,'base_user','create_datetime','report.prompt.user.create',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (309,18,8,'base_user','create_datetime','report.prompt.user.create',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (310,18,9,'base_user','last_status_change','report.prompt.user.status_change',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (311,18,10,'base_user','last_status_change','report.prompt.user.status_change',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (312,18,11,'user_role_map','role_id','report.prompt.user.roleCode',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (313,18,12,'it2','content','report.prompt.user.role',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (314,18,13,'contact','organization_name','contact.prompt.organizationName',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (315,18,14,'contact','street_addres1','contact.prompt.address1',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (316,18,15,'contact','street_addres2','contact.prompt.address2',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (317,18,16,'contact','city','contact.prompt.city',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (318,18,17,'contact','state_province','contact.prompt.stateProvince',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (319,18,18,'contact','postal_code','contact.prompt.postalCode',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (320,18,19,'contact','country_code','report.prompt.user.countryCode',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (324,18,23,'contact','phone_country_code','contact.prompt.phoneCountryCode',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (322,18,21,'contact','last_name','contact.prompt.lastName',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (323,18,22,'contact','first_name','contact.prompt.firstName',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (325,18,24,'contact','phone_area_code','contact.prompt.phoneAreaCode',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (326,18,25,'contact','phone_phone_number','contact.prompt.phoneNumber',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (327,18,26,'contact','email','contact.prompt.email',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (328,18,27,'base_user','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (329,18,28,'it1','language_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (321,18,20,'it3','content','contact.prompt.countryCode',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (330,1,11,'purchase_order','notify','report.prompt.purchase_order.notify',0,0,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (398,72,1,'invoice','id','report.prompt.invoice.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (24,2,2,'invoice','id','invoice.id.prompt',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (333,17,11,'invoice','create_datetime','invoice.createDateTime.prompt',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (33,2,10,'currency','symbol','currency.external.prompt.name',0,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (334,17,12,'invoice','user_id','invoice.userId.prompt',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (399,72,2,'invoice','id','','invoice.id.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (400,72,2,'invoice','public_number','','invoice.number.prompt',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (401,72,3,'base_user','user_name','','user.prompt.username',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (402,72,4,'invoice','create_datetime','invoice.create_date',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (403,72,5,'invoice','create_datetime','invoice.create_date',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (404,72,6,'invoice','billing_process_id','','process.external.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (405,72,7,'invoice','delegated_invoice_id','','invoice.delegated.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (406,72,8,'invoice','due_date','invoice.dueDate.prompt',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (407,72,9,'invoice','due_date','invoice.dueDate.prompt',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (264,35,1,'purchase_order','id','report.prompt.purchase_order.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (408,72,10,'currency','symbol','currency.external.prompt.name',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (409,72,11,'invoice','total','','invoice.total.prompt','sum',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (410,72,12,'invoice','payment_attempts','','invoice.attempts.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (411,72,13,'invoice','to_process','','invoice.is_payable',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (412,72,14,'invoice','balance','','invoice.balance.prompt',0,0,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (413,72,15,'invoice','carried_balance','','invoice.carriedBalance.prompt',0,0,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (414,72,16,'invoice','deleted','0','report.prompt.invoice.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (415,72,17,'invoice','is_review','0','report.prompt.invoice.is_review',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (498,105,1,'invoice','id','report.prompt.invoice.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (499,105,2,'invoice','id','','invoice.id.prompt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (500,105,2,'invoice','public_number','','invoice.number.prompt',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (501,105,3,'base_user','user_name','','user.prompt.username',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (502,105,4,'invoice','create_datetime',1,'2004-09-01','invoice.create_date',1,1,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (503,105,5,'invoice','create_datetime','2004-09-12','invoice.create_date',0,0,'date','<=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (504,105,6,'invoice','billing_process_id','','process.external.id',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (505,105,7,'invoice','delegated_invoice_id','','invoice.delegated.prompt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (506,105,8,'invoice','due_date','invoice.dueDate.prompt',1,1,'date','<=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (507,105,9,'invoice','due_date','invoice.dueDate.prompt',0,0,'date','<=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (508,105,10,'currency','symbol','currency.external.prompt.name',1,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (509,105,11,'invoice','total','','invoice.total.prompt',1,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (510,105,12,'invoice','payment_attempts','','invoice.attempts.prompt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (511,105,13,'invoice','to_process','','invoice.is_payable',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (512,105,14,'invoice','balance','0.00','invoice.balance.prompt',1,1,'float','>',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (513,105,15,'invoice','carried_balance','','invoice.carriedBalance.prompt',1,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (514,105,16,'invoice','deleted','0','report.prompt.invoice.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (515,105,17,'invoice','is_review','0','report.prompt.invoice.is_review',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (516,105,18,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (517,105,99,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (416,72,18,'base_user','entity_id','303','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (417,72,99,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1537,289,9,'invoice','due_date','invoice.dueDate.prompt',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (331,2,2,'invoice','public_number','invoice.number.prompt',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (420,18,29,'base_user','last_login','user.prompt.lastLogin',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (421,18,29,'base_user','last_login','user.prompt.lastLogin',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (422,86,1,'base_user','id','report.prompt.base_user.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (423,86,2,'base_user','id','','user.prompt.id',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (424,86,3,'base_user','user_name','','user.prompt.username',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (425,86,4,'base_user','language_id','','report.prompt.user.languageCode',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (426,86,4,'language','description','user.prompt.language',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1538,289,10,'currency','symbol','currency.external.prompt.name',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1539,289,11,'invoice','total','','invoice.total.prompt','sum',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1540,289,12,'invoice','payment_attempts','','invoice.attempts.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1541,289,13,'invoice','to_process','','invoice.is_payable',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1542,289,14,'invoice','balance',1,'','invoice.balance.prompt','sum',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1543,289,15,'invoice','carried_balance','','invoice.carriedBalance.prompt','sum',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1544,289,16,'invoice','deleted','0','report.prompt.invoice.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1545,289,17,'invoice','is_review','0','report.prompt.invoice.is_review',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1546,289,18,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (427,86,5,'base_user','status_id','','report.prompt.user.statusCode',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (428,86,6,'it1','content','user.prompt.status',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (429,86,7,'base_user','create_datetime','report.prompt.user.create',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (430,86,8,'base_user','create_datetime','report.prompt.user.create',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (431,86,9,'base_user','last_status_change','report.prompt.user.status_change',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (432,86,10,'base_user','last_status_change','report.prompt.user.status_change',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (433,86,11,'user_role_map','role_id','5','report.prompt.user.roleCode',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (434,86,12,'it2','content','report.prompt.user.role',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (435,86,13,'contact','organization_name','','contact.prompt.organizationName',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (594,138,12,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (595,138,12,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (596,138,12,'id','content','payment.method',1,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (597,138,12,'base_user','entity_id','?','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (598,138,13,'id2','content','payment.result',1,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (599,138,14,'id','language_id','?','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (562,137,1,'invoice','id','report.prompt.invoice.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (563,137,2,'invoice','id','','invoice.id.prompt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (564,137,2,'invoice','public_number','','invoice.number.prompt',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (565,137,3,'base_user','user_name','','user.prompt.username',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (566,137,4,'invoice','create_datetime',1,'invoice.create_date',1,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (567,137,5,'invoice','create_datetime','invoice.create_date',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (568,137,6,'invoice','billing_process_id','','process.external.id',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (569,137,7,'invoice','delegated_invoice_id','','invoice.delegated.prompt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (528,120,1,'invoice','id','report.prompt.invoice.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (529,120,2,'invoice','id','','invoice.id.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (530,120,2,'invoice','public_number','','invoice.number.prompt',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (531,120,3,'base_user','user_name','','user.prompt.username',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (532,120,4,'invoice','create_datetime','2004-09-01','invoice.create_date',0,0,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (533,120,5,'invoice','create_datetime','2004-09-30','invoice.create_date',0,0,'date','<=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (534,120,6,'invoice','billing_process_id','','process.external.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (535,120,7,'invoice','delegated_invoice_id','','invoice.delegated.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (536,120,8,'invoice','due_date','invoice.dueDate.prompt',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (537,120,9,'invoice','due_date','invoice.dueDate.prompt',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (538,120,10,'currency','symbol','currency.external.prompt.name',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (539,120,11,'invoice','total','','invoice.total.prompt',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (540,120,12,'invoice','payment_attempts','','invoice.attempts.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (541,120,13,'invoice','to_process','','invoice.is_payable',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (542,120,14,'invoice','balance','','invoice.balance.prompt',0,0,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (543,120,15,'invoice','carried_balance','','invoice.carriedBalance.prompt',0,0,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (544,120,16,'invoice','deleted','0','report.prompt.invoice.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (545,120,17,'invoice','is_review','0','report.prompt.invoice.is_review',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (436,86,14,'contact','street_addres1','','contact.prompt.address1',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (437,86,15,'contact','street_addres2','','contact.prompt.address2',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (438,86,16,'contact','city','','contact.prompt.city',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (439,86,17,'contact','state_province','','contact.prompt.stateProvince',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (440,86,18,'contact','postal_code','','contact.prompt.postalCode',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (441,86,19,'contact','country_code','','report.prompt.user.countryCode',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (442,86,20,'it3','content','contact.prompt.countryCode',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (443,86,21,'contact','last_name','','contact.prompt.lastName',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (444,86,22,'contact','first_name','','contact.prompt.firstName',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (445,86,23,'contact','phone_country_code','','contact.prompt.phoneCountryCode',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (446,86,24,'contact','phone_area_code','','contact.prompt.phoneAreaCode',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (447,86,25,'contact','phone_phone_number','','contact.prompt.phoneNumber',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (448,86,26,'contact','email','','contact.prompt.email',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (449,86,27,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (450,86,28,'it1','language_id','1','report.prompt.it1.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (451,86,29,'base_user','last_login',1,'user.prompt.lastLogin',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (452,86,29,'base_user','last_login','user.prompt.lastLogin',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1547,289,99,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1568,309,1,'payment','id','report.prompt.payment.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1569,309,2,'payment','id','','payment.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1570,309,3,'base_user','user_name','','user.prompt.username',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1571,309,4,'payment','attempt','','payment.attempt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1572,309,5,'payment','result_id','','payment.resultId',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1573,309,6,'payment','amount','','payment.amount',1,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (546,120,18,'base_user','entity_id','277','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (547,120,99,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (651,156,2,'invoice','public_number','','invoice.number.prompt',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (652,156,3,'base_user','user_name','','user.prompt.username',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (653,156,4,'invoice','create_datetime',1,'invoice.create_date',1,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (655,156,6,'invoice','billing_process_id','','process.external.id',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (656,156,7,'invoice','delegated_invoice_id','','invoice.delegated.prompt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (657,156,8,'invoice','due_date','invoice.dueDate.prompt',1,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (658,156,9,'invoice','due_date','invoice.dueDate.prompt',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (659,156,10,'currency','symbol','currency.external.prompt.name',1,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (660,156,11,'invoice','total','','invoice.total.prompt',1,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (661,156,12,'invoice','payment_attempts','','invoice.attempts.prompt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (662,156,13,'invoice','to_process','','invoice.is_payable',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (663,156,14,'invoice','balance','0.00','invoice.balance.prompt',1,1,'float','>',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (664,156,15,'invoice','carried_balance','','invoice.carriedBalance.prompt',1,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (665,156,16,'invoice','deleted','0','report.prompt.invoice.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (666,156,17,'invoice','is_review','0','report.prompt.invoice.is_review',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (667,156,18,'base_user','entity_id','?','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (668,156,99,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (631,155,1,'payment','id','report.prompt.payment.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (632,155,2,'payment','id','','payment.id',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (633,155,3,'base_user','user_name','','user.prompt.username',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (634,155,4,'payment','attempt','','payment.attempt','sum',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (635,155,5,'payment','result_id','','payment.resultId','sum',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (636,155,6,'payment','amount','','payment.amount','sum',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (637,155,8,'payment','create_datetime','payment.createDate',1,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (638,155,8,'payment','create_datetime','payment.createDate',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (639,155,8,'payment','payment_date','2004-9-1','payment.date',0,0,'date','>=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (640,155,9,'payment','payment_date',1,'2004-10-1','payment.date',1,1,'date','<=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (641,155,9,'payment','method_id','','payment.methodId','sum',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (570,137,8,'invoice','due_date','2004-9-1','invoice.dueDate.prompt',1,1,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (571,137,9,'invoice','due_date','2004-9-15','invoice.dueDate.prompt',0,0,'date','<=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (572,137,10,'currency','symbol','currency.external.prompt.name',1,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (573,137,11,'invoice','total','','invoice.total.prompt',1,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (574,137,12,'invoice','payment_attempts','','invoice.attempts.prompt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (575,137,13,'invoice','to_process','','invoice.is_payable',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (576,137,14,'invoice','balance','0.0','invoice.balance.prompt',1,1,'float','>',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (577,137,15,'invoice','carried_balance','','invoice.carriedBalance.prompt',1,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (578,137,16,'invoice','deleted','0','report.prompt.invoice.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (579,137,17,'invoice','is_review','0','report.prompt.invoice.is_review',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (580,137,18,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (581,137,99,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (642,155,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (643,155,12,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (644,155,12,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (645,155,12,'id','content','payment.method',1,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (646,155,12,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (647,155,13,'id2','content','payment.result',1,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (582,138,1,'payment','id','report.prompt.payment.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (583,138,2,'payment','id','','payment.id',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (584,138,3,'base_user','user_name','','user.prompt.username',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (585,138,4,'payment','attempt','','payment.attempt','sum',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (586,138,5,'payment','result_id','','payment.resultId','sum',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (587,138,6,'payment','amount','','payment.amount','sum',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (588,138,8,'payment','create_datetime','payment.createDate',1,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (589,138,8,'payment','create_datetime','payment.createDate',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (590,138,8,'payment','payment_date','2004-9-1','payment.date',0,0,'date','>=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (591,138,9,'payment','payment_date',1,'2004-9-15','payment.date',1,1,'date','<=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (592,138,9,'payment','method_id','','payment.methodId','sum',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (593,138,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (921,207,8,'payment','create_datetime','payment.createDate',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (922,207,8,'payment','payment_date','payment.date',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (923,207,9,'payment','payment_date','payment.date',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (924,207,9,'payment','method_id','','payment.methodId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (925,207,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (926,207,12,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (927,207,12,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (928,207,12,'id','content','payment.method',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (929,207,12,'base_user','entity_id','?','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (930,207,13,'id2','content','payment.result',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (931,207,14,'id','language_id','?','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (875,198,7,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (876,198,7,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (877,198,8,'purchase_order','created_by','','report.prompt.purchase_order.created_by',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (878,198,9,'purchase_order','status_id','','report.prompt.purchase_order.status',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (879,198,10,'purchase_order','next_billable_day','order.prompt.nextBillableDay',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (880,198,10,'purchase_order','next_billable_day','order.prompt.nextBillableDay',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (881,198,10,'purchase_order','deleted','0','report.prompt.purchase_order.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (882,198,11,'base_user','entity_id','306','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (884,198,11,'purchase_order','notify','','report.prompt.purchase_order.notify',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1021,161,4,'payment','attempt','','payment.attempt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1022,161,5,'payment','result_id','','payment.resultId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1023,161,6,'payment','amount','','payment.amount','sum',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1024,161,8,'payment','create_datetime','2004-11-1','payment.createDate',0,0,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1025,161,8,'payment','create_datetime','2004-11-23','payment.createDate',0,0,'date','<=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1026,161,8,'payment','payment_date','payment.date',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1027,161,9,'payment','payment_date','payment.date',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1028,161,9,'payment','method_id','','payment.methodId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (648,155,14,'id','language_id','1','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1029,161,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1030,161,12,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1031,161,12,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1032,161,12,'id','content','payment.method',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1033,161,12,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1034,161,13,'id2','content','payment.result',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1035,161,14,'id','language_id','1','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1038,18,29,'contact_map','type_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1116,19,1,'item','id','item.prompt.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1117,19,10,'item','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1118,19,20,'item','id','item.prompt.id',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1119,19,30,'item','internal_number','item.prompt.internalNumber',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (885,198,12,'id','language_id','1','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (902,205,0,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (903,205,0,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,function_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (904,205,1,'payment','amount','payment.amount','sum',0,1,'float',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (905,205,2,'payment','payment_date','2004-10-1','payment.date',0,0,'date','>=',0,0,0,0,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (906,205,3,'payment','payment_date','2005-10-1','payment.date',0,0,'date','<',0,0,0,0,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (817,194,11,'invoice','total','','invoice.total.prompt',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1178,199,1,'payment','id','report.prompt.payment.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1179,199,2,'payment','id','','payment.id',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1180,199,3,'base_user','user_name','','user.prompt.username',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1181,199,4,'payment','attempt','','payment.attempt',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1182,199,5,'payment','result_id','','payment.resultId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1183,199,6,'payment','amount','','payment.amount',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (649,156,1,'invoice','id','report.prompt.invoice.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (650,156,2,'invoice','id','','invoice.id.prompt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (654,156,5,'invoice','create_datetime','invoice.create_date',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1184,199,8,'payment','create_datetime',1,'2004-12-1','payment.createDate',0,1,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1185,199,8,'payment','create_datetime','2004-12-31','payment.createDate',0,0,'date','<=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1120,19,35,'itd','content','item.prompt.description',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1186,199,8,'payment','payment_date','payment.date',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1187,199,9,'payment','payment_date','payment.date',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1188,199,9,'payment','method_id','','payment.methodId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1189,199,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1190,199,12,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1191,199,12,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1192,199,12,'id','content','payment.method',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1193,199,12,'base_user','entity_id','?','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1194,199,13,'id2','content','payment.result',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1195,199,14,'id','language_id','?','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1121,19,40,'item','percentage','item.prompt.pricePercentage',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1122,19,50,'item','price_manual','item.prompt.priceManual',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (907,205,14,'base_user','entity_id','306','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (908,206,0,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (909,206,0,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,function_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (910,206,1,'payment','amount','payment.amount','sum',0,1,'float',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (911,206,2,'payment','payment_date','2004-10-1','payment.date',0,0,'date','>=',0,0,0,0,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (912,206,3,'payment','payment_date','2005-10-1','payment.date',0,0,'date','<',0,0,0,0,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (913,206,14,'base_user','entity_id','306','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (914,207,1,'payment','id','report.prompt.payment.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (915,207,2,'payment','id','','payment.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (916,207,3,'base_user','user_name','','user.prompt.username',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (917,207,4,'payment','attempt','','payment.attempt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (918,207,5,'payment','result_id','','payment.resultId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (919,207,6,'payment','amount','','payment.amount',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (920,207,8,'payment','create_datetime','payment.createDate',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (854,197,0,'invoice','deleted','0','report.prompt.invoice.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (855,197,0,'invoice','is_review','0','report.prompt.invoice.is_review',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (856,197,0,'base_user','entity_id','?','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,function_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (857,197,1,'invoice','total','invoice.total.prompt','sum',0,1,'float',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (858,197,1,'invoice','create_datetime','2004-10-01','invoice.create_date',0,0,'date','>=',0,0,0,0,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (755,190,1,'purchase_order','id','report.prompt.purchase_order.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (756,190,1,'base_user','user_name','','report.prompt.base_user.user_name',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (757,190,1,'purchase_order','id','','report.prompt.purchase_order.id',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (758,190,1,'contact','organization_name','contact.prompt.organizationName',0,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (759,190,1,'contact','first_name','contact.prompt.firstName',0,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (760,190,1,'contact','last_name','contact.prompt.lastName',0,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (761,190,1,'contact','phone_phone_number','contact.prompt.phoneNumber',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (762,190,3,'purchase_order','period_id','','order.prompt.periodId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (763,190,3,'id','content','order.prompt.period',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (764,190,4,'purchase_order','billing_type_id','','order.prompt.billingTypeId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (765,190,4,'id2','content','order.prompt.billingType',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (766,190,5,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (767,190,5,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (768,190,6,'purchase_order','active_until','report.prompt.purchase_order.active_until',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (769,190,6,'purchase_order','active_until','report.prompt.purchase_order.active_until',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (770,190,7,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (771,190,7,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (772,190,8,'purchase_order','created_by','','report.prompt.purchase_order.created_by',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (773,190,9,'purchase_order','status_id','','report.prompt.purchase_order.status',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (774,190,10,'purchase_order','next_billable_day','order.prompt.nextBillableDay',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (775,190,10,'purchase_order','next_billable_day','order.prompt.nextBillableDay',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (776,190,10,'purchase_order','deleted','0','report.prompt.purchase_order.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (777,190,11,'base_user','entity_id','306','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (778,190,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (779,190,11,'purchase_order','notify','','report.prompt.purchase_order.notify',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (998,160,1,'invoice','id','report.prompt.invoice.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (780,190,12,'id','language_id','1','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (859,197,2,'invoice','create_datetime','2005-10-01','invoice.create_date',0,0,'date','<',0,0,0,0,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (860,198,1,'purchase_order','id','report.prompt.purchase_order.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (861,198,1,'base_user','user_name','','report.prompt.base_user.user_name',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (862,198,1,'purchase_order','id','','report.prompt.purchase_order.id',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (781,191,0,'base_user','entity_id','?','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (782,191,1,'purchase_order','create_datetime','2004-10-15','report.prompt.purchase_order.create_datetime',0,0,'date','>=',0,0,0,0,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,function_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (783,191,1,'order_line','amount','order.line.prompt.amount','sum',0,1,'float',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (784,191,2,'purchase_order','create_datetime','2005-10-15','report.prompt.purchase_order.create_datetime',0,0,'date','<',0,0,0,0,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (863,198,1,'contact','organization_name','contact.prompt.organizationName',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (864,198,1,'contact','first_name','contact.prompt.firstName',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (865,198,1,'contact','last_name','contact.prompt.lastName',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (866,198,1,'contact','phone_phone_number','contact.prompt.phoneNumber',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (785,192,0,'base_user','entity_id','306','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (786,192,1,'purchase_order','create_datetime','2004-10-15','report.prompt.purchase_order.create_datetime',0,0,'date','>=',0,0,0,0,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,function_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (787,192,1,'order_line','amount','order.line.prompt.amount','sum',0,1,'float',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (788,192,2,'purchase_order','create_datetime','2005-10-15','report.prompt.purchase_order.create_datetime',0,0,'date','<',0,0,0,0,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (867,198,3,'purchase_order','period_id','','order.prompt.periodId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (868,198,3,'id','content','order.prompt.period',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (869,198,4,'purchase_order','billing_type_id','','order.prompt.billingTypeId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (870,198,4,'id2','content','order.prompt.billingType',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (871,198,5,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (872,198,5,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (873,198,6,'purchase_order','active_until','report.prompt.purchase_order.active_until',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (874,198,6,'purchase_order','active_until','report.prompt.purchase_order.active_until',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (883,198,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (806,194,1,'invoice','id','report.prompt.invoice.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (807,194,2,'invoice','id','','invoice.id.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (808,194,2,'invoice','public_number','','invoice.number.prompt',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (809,194,3,'base_user','user_name','','user.prompt.username',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (810,194,4,'invoice','create_datetime','invoice.create_date',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (811,194,5,'invoice','create_datetime','invoice.create_date',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (812,194,6,'invoice','billing_process_id','','process.external.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (813,194,7,'invoice','delegated_invoice_id','','invoice.delegated.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (789,193,0,'purchase_order','id','report.prompt.purchase_order.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (790,193,0,'purchase_order','deleted','0','report.prompt.purchase_order.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (791,193,0,'order_line','deleted','0','report.prompt.order_line.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (792,193,0,'base_user','entity_id','?','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (793,193,1,'base_user','user_name','','user.prompt.username',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (794,193,1,'id','language_id','?','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (795,193,2,'purchase_order','id','','order.external.prompt.id',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (796,193,3,'order_line','item_id','','item.prompt.number',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (797,193,4,'order_line','type_id','','order.line.prompt.typeid',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (798,193,5,'id','content','order.line.prompt.type',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (799,193,6,'order_line','description','','order.line.prompt.description',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (800,193,7,'order_line','amount','','order.line.prompt.amount',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (801,193,8,'order_line','quantity','','order.line.prompt.quantity',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (802,193,9,'order_line','price','','order.line.prompt.price',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (803,193,10,'purchase_order','status_id','','report.prompt.purchase_order.status',0,0,'integer','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (804,193,10,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (805,193,10,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (814,194,8,'invoice','due_date','invoice.dueDate.prompt',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (815,194,9,'invoice','due_date','invoice.dueDate.prompt',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (816,194,10,'currency','symbol','currency.external.prompt.name',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (943,157,5,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1157,17,4,'item','internal_number','item.prompt.internalNumber',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (944,157,5,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (945,157,6,'purchase_order','active_until','report.prompt.purchase_order.active_until',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (946,157,6,'purchase_order','active_until','report.prompt.purchase_order.active_until',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (947,157,7,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (948,157,7,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (949,157,8,'purchase_order','created_by','','report.prompt.purchase_order.created_by',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (950,157,9,'purchase_order','status_id','','report.prompt.purchase_order.status',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (951,157,10,'purchase_order','next_billable_day','order.prompt.nextBillableDay',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (952,157,10,'purchase_order','next_billable_day','order.prompt.nextBillableDay',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (953,157,10,'purchase_order','deleted','0','report.prompt.purchase_order.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (954,157,11,'base_user','entity_id','277','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (955,157,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (956,157,11,'purchase_order','notify','','report.prompt.purchase_order.notify',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (957,157,12,'id','language_id','4','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (958,158,1,'invoice','id','report.prompt.invoice.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (959,158,2,'invoice','id','','invoice.id.prompt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (818,194,12,'invoice','payment_attempts','','invoice.attempts.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (819,194,13,'invoice','to_process','','invoice.is_payable',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (820,194,14,'invoice','balance','','invoice.balance.prompt',0,0,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (821,194,15,'invoice','carried_balance','','invoice.carriedBalance.prompt',0,0,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (822,194,16,'invoice','deleted','0','report.prompt.invoice.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (823,194,17,'invoice','is_review','0','report.prompt.invoice.is_review',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (824,194,18,'base_user','entity_id','?','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (825,194,99,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (932,157,1,'purchase_order','id','report.prompt.purchase_order.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (933,157,1,'base_user','user_name','','report.prompt.base_user.user_name',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (934,157,1,'purchase_order','id','','report.prompt.purchase_order.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (935,157,1,'contact','organization_name','contact.prompt.organizationName',0,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (936,157,1,'contact','first_name','contact.prompt.firstName',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (937,157,1,'contact','last_name','contact.prompt.lastName',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (938,157,1,'contact','phone_phone_number','contact.prompt.phoneNumber',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (939,157,3,'purchase_order','period_id','','order.prompt.periodId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (940,157,3,'id','content','order.prompt.period',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (941,157,4,'purchase_order','billing_type_id','','order.prompt.billingTypeId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (942,157,4,'id2','content','order.prompt.billingType',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (826,195,1,'invoice','id','report.prompt.invoice.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (827,195,2,'invoice','id','','invoice.id.prompt',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (828,195,2,'invoice','public_number','','invoice.number.prompt',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (829,195,3,'base_user','user_name','','user.prompt.username',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (830,195,4,'invoice','create_datetime','invoice.create_date',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (831,195,5,'invoice','create_datetime','invoice.create_date',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (832,195,6,'invoice','billing_process_id','','process.external.id',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (833,195,7,'invoice','delegated_invoice_id','','invoice.delegated.prompt',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (834,195,8,'invoice','due_date','invoice.dueDate.prompt',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (835,195,9,'invoice','due_date','invoice.dueDate.prompt',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (836,195,10,'currency','symbol','currency.external.prompt.name',0,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (837,195,11,'invoice','total','','invoice.total.prompt',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (838,195,12,'invoice','payment_attempts','','invoice.attempts.prompt',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (839,195,13,'invoice','to_process','','invoice.is_payable',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (840,195,14,'invoice','balance','','invoice.balance.prompt',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (841,195,15,'invoice','carried_balance','','invoice.carriedBalance.prompt',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (842,195,16,'invoice','deleted','0','report.prompt.invoice.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (843,195,17,'invoice','is_review','0','report.prompt.invoice.is_review',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (844,195,18,'base_user','entity_id','?','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (845,195,99,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1068,172,1,'contact','organization_name','contact.prompt.organizationName',0,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1069,172,1,'contact','first_name','contact.prompt.firstName',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1070,172,1,'contact','last_name','contact.prompt.lastName',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1071,172,1,'contact','phone_phone_number','contact.prompt.phoneNumber',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1072,172,3,'purchase_order','period_id','','order.prompt.periodId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1073,172,3,'id','content','order.prompt.period',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1074,172,4,'purchase_order','billing_type_id','','order.prompt.billingTypeId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1075,172,4,'id2','content','order.prompt.billingType',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1076,172,5,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1077,172,5,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1078,172,6,'purchase_order','active_until','report.prompt.purchase_order.active_until',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1079,172,6,'purchase_order','active_until','report.prompt.purchase_order.active_until',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1080,172,7,'purchase_order','create_datetime',1,'2004-10-1','report.prompt.purchase_order.create_datetime',0,1,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1081,172,7,'purchase_order','create_datetime','2004-11-1','report.prompt.purchase_order.create_datetime',0,0,'date','<',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1082,172,8,'purchase_order','created_by','','report.prompt.purchase_order.created_by',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1083,172,9,'purchase_order','status_id','','report.prompt.purchase_order.status',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1084,172,10,'purchase_order','next_billable_day','order.prompt.nextBillableDay',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1085,172,10,'purchase_order','next_billable_day','order.prompt.nextBillableDay',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1086,172,10,'purchase_order','deleted','0','report.prompt.purchase_order.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1087,172,11,'base_user','entity_id','303','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1088,172,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1089,172,11,'purchase_order','notify','','report.prompt.purchase_order.notify',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1090,172,12,'id','language_id','1','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1106,4,20,'purchase_order','period_id','order.prompt.periodId',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1107,4,30,'purchase_order','status_id','report.prompt.purchase_order.status',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1108,4,40,'purchase_order','billing_type_id','order.prompt.billingTypeId',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1109,4,50,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1110,4,51,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1111,4,60,'purchase_order','active_until','report.prompt.purchase_order.active_until',0,1,'date',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1112,4,61,'purchase_order','active_until','report.prompt.purchase_order.active_until',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1113,4,21,'id2','content','order.prompt.period',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1114,4,41,'id3','content','order.prompt.billingType',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1115,4,31,'id4','content','order.prompt.status',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1065,172,1,'purchase_order','id','report.prompt.purchase_order.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1066,172,1,'base_user','user_name','','report.prompt.base_user.user_name',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1067,172,1,'purchase_order','id','','report.prompt.purchase_order.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1018,161,1,'payment','id','report.prompt.payment.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (960,158,2,'invoice','public_number','','invoice.number.prompt',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (961,158,3,'base_user','user_name','','user.prompt.username',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (962,158,4,'invoice','create_datetime',1,'invoice.create_date',1,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (963,158,5,'invoice','create_datetime','invoice.create_date',0,0,'date','<=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (964,158,6,'invoice','billing_process_id','','process.external.id',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (965,158,7,'invoice','delegated_invoice_id','','invoice.delegated.prompt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (966,158,8,'invoice','due_date','invoice.dueDate.prompt',1,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (967,158,9,'invoice','due_date','2004-11-1','invoice.dueDate.prompt',0,0,'date','<=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (968,158,10,'currency','symbol','currency.external.prompt.name',1,1,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (969,158,11,'invoice','total','','invoice.total.prompt',1,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (970,158,12,'invoice','payment_attempts','','invoice.attempts.prompt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (971,158,13,'invoice','to_process','','invoice.is_payable',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (972,158,14,'invoice','balance','','invoice.balance.prompt',1,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (973,158,15,'invoice','carried_balance','0.0','invoice.carriedBalance.prompt',1,1,'float','>',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (974,158,16,'invoice','deleted','0','report.prompt.invoice.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (975,158,17,'invoice','is_review','0','report.prompt.invoice.is_review',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (976,158,18,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (977,158,99,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1019,161,2,'payment','id','','payment.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1020,161,3,'base_user','user_name','','user.prompt.username',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1226,220,1,'payment','id','report.prompt.payment.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1227,220,2,'payment','id','','payment.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1228,220,3,'base_user','user_name','','user.prompt.username',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1229,220,4,'payment','attempt','','payment.attempt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1230,220,5,'payment','result_id','2','payment.resultId',0,0,'integer','!=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1231,220,6,'payment','amount','','payment.amount','sum',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1232,220,8,'payment','create_datetime','payment.createDate',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1233,220,8,'payment','create_datetime','payment.createDate',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1234,220,8,'payment','payment_date','2005-2-1','payment.date',0,0,'date','>=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1235,220,9,'payment','payment_date','2005-3-1','payment.date',0,0,'date','<',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1236,220,9,'payment','method_id','','payment.methodId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1237,220,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1238,220,12,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1239,220,12,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1240,220,12,'id','content','payment.method',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1241,220,12,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1242,220,13,'id2','content','payment.result',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1243,220,14,'id','language_id','1','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1208,219,1,'payment','id','report.prompt.payment.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1209,219,2,'payment','id','','payment.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1210,219,3,'base_user','user_name','','user.prompt.username',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1211,219,4,'payment','attempt','','payment.attempt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1212,219,5,'payment','result_id','','payment.resultId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1213,219,6,'payment','amount','','payment.amount',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1214,219,8,'payment','create_datetime','payment.createDate',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1215,219,8,'payment','create_datetime','payment.createDate',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1216,219,8,'payment','payment_date','2005-01-01','payment.date',0,0,'date','>=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1217,219,9,'payment','payment_date',1,'2005-02-01','payment.date',0,1,'date','<',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1218,219,9,'payment','method_id','','payment.methodId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1219,219,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1220,219,12,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1221,219,12,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1222,219,12,'id','content','payment.method',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1223,219,12,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (999,160,2,'invoice','id','','invoice.id.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1000,160,2,'invoice','public_number','','invoice.number.prompt',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1001,160,3,'base_user','user_name','','user.prompt.username',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1002,160,4,'invoice','create_datetime','2004-11-1','invoice.create_date',0,0,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1003,160,5,'invoice','create_datetime','2004-11-23','invoice.create_date',0,0,'date','<=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1004,160,6,'invoice','billing_process_id','','process.external.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1005,160,7,'invoice','delegated_invoice_id','','invoice.delegated.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1006,160,8,'invoice','due_date','invoice.dueDate.prompt',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1007,160,9,'invoice','due_date','invoice.dueDate.prompt',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1008,160,10,'currency','symbol','currency.external.prompt.name',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1009,160,11,'invoice','total',1,'0','invoice.total.prompt','sum',0,1,'float','>',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1010,160,12,'invoice','payment_attempts','','invoice.attempts.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1011,160,13,'invoice','to_process','','invoice.is_payable',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1012,160,14,'invoice','balance','','invoice.balance.prompt',0,0,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1013,160,15,'invoice','carried_balance','0','invoice.carriedBalance.prompt',0,0,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1014,160,16,'invoice','deleted','0','report.prompt.invoice.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1015,160,17,'invoice','is_review','0','report.prompt.invoice.is_review',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1016,160,18,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1017,160,99,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1123,19,60,'item_type','description','item.prompt.types',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1124,19,70,'item_price','price','item.prompt.price',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1125,19,70,'currency','code','item.prompt.currency',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1224,219,13,'id2','content','payment.result',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1225,219,14,'id','language_id','1','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1248,229,0,'purchase_order','id','report.prompt.purchase_order.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1318,249,1,'payment','id','report.prompt.payment.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1319,249,2,'payment','id','','payment.id',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1320,249,3,'base_user','user_name','','user.prompt.username',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1321,249,4,'payment','attempt','','payment.attempt',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1322,249,5,'payment','result_id','1','payment.resultId',0,1,'integer','!=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1323,249,6,'payment','amount','','payment.amount',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1324,249,8,'payment','create_datetime','payment.createDate',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1325,249,8,'payment','create_datetime','payment.createDate',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1326,249,8,'payment','payment_date','payment.date',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1327,249,9,'payment','payment_date','payment.date',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1328,249,9,'payment','method_id','','payment.methodId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1329,249,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1330,249,12,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1331,249,12,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1332,249,12,'id','content','payment.method',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1333,249,12,'base_user','entity_id','307','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1334,249,13,'id2','content','payment.result',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1335,249,14,'id','language_id','1','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1286,239,8,'base_user','create_datetime','report.prompt.user.create',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1287,239,9,'base_user','last_status_change','report.prompt.user.status_change',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1288,239,10,'base_user','last_status_change','report.prompt.user.status_change',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1289,239,11,'user_role_map','role_id','','report.prompt.user.roleCode',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1290,239,12,'it2','content','report.prompt.user.role',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1398,269,9,'payment','method_id','','payment.methodId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1249,229,0,'purchase_order','deleted','0','report.prompt.purchase_order.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1250,229,0,'order_line','deleted','0','report.prompt.order_line.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1251,229,0,'base_user','entity_id','307','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1252,229,1,'base_user','user_name','','user.prompt.username',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1253,229,1,'id','language_id','1','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1254,229,2,'purchase_order','id','','order.external.prompt.id',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1255,229,3,'order_line','item_id','','item.prompt.number',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1256,229,4,'order_line','type_id','','order.line.prompt.typeid',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1257,229,5,'id','content','order.line.prompt.type',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1258,229,6,'order_line','description','','order.line.prompt.description',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1259,229,7,'order_line','amount','69','order.line.prompt.amount',0,1,'float','!=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1260,229,8,'order_line','quantity','','order.line.prompt.quantity',0,0,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1261,229,9,'order_line','price','','order.line.prompt.price',0,0,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1262,229,10,'purchase_order','status_id','1','report.prompt.purchase_order.status',0,0,'integer','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1263,229,10,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1264,229,10,'purchase_order','create_datetime','report.prompt.purchase_order.create_datetime',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1265,229,20,'purchase_order','period_id','','order.prompt.periodId',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1266,229,21,'id2','content','order.prompt.period',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1267,229,30,'purchase_order','status_id','','report.prompt.purchase_order.status',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1268,229,31,'id4','content','order.prompt.status',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1269,229,40,'purchase_order','billing_type_id','','order.prompt.billingTypeId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1270,229,41,'id3','content','order.prompt.billingType',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1271,229,50,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1272,229,51,'purchase_order','active_since','report.prompt.purchase_order.active_since',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1273,229,60,'purchase_order','active_until','report.prompt.purchase_order.active_until',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1274,229,61,'purchase_order','active_until','report.prompt.purchase_order.active_until',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1278,239,1,'base_user','id','report.prompt.base_user.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1279,239,2,'base_user','id','','user.prompt.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1280,239,3,'base_user','user_name','','user.prompt.username',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1281,239,4,'base_user','language_id','','report.prompt.user.languageCode',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1282,239,4,'language','description','user.prompt.language',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1283,239,5,'base_user','status_id','','report.prompt.user.statusCode',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1284,239,6,'it1','content','user.prompt.status',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1285,239,7,'base_user','create_datetime','report.prompt.user.create',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1399,269,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1400,269,12,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1401,269,12,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1403,269,12,'base_user','entity_id','303','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1404,269,13,'id2','content','payment.result',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1291,239,13,'contact','organization_name',1,'','contact.prompt.organizationName',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1292,239,14,'contact','street_addres1','','contact.prompt.address1',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1293,239,15,'contact','street_addres2','','contact.prompt.address2',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1294,239,16,'contact','city','','contact.prompt.city',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1295,239,17,'contact','state_province','','contact.prompt.stateProvince',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1296,239,18,'contact','postal_code','','contact.prompt.postalCode',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1297,239,19,'contact','country_code','','report.prompt.user.countryCode',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1298,239,20,'it3','content','contact.prompt.countryCode',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1299,239,21,'contact','last_name','','contact.prompt.lastName',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1300,239,22,'contact','first_name','','contact.prompt.firstName',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1301,239,23,'contact','phone_country_code','','contact.prompt.phoneCountryCode',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1302,239,24,'contact','phone_area_code','','contact.prompt.phoneAreaCode',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1303,239,25,'contact','phone_phone_number','','contact.prompt.phoneNumber',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1304,239,26,'contact','email','','contact.prompt.email',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1305,239,27,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1306,239,28,'it1','language_id','1','report.prompt.it1.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1307,239,29,'base_user','last_login','user.prompt.lastLogin',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1308,239,29,'base_user','last_login','user.prompt.lastLogin',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1309,239,29,'contact_map','type_id','3','report.prompt.contact_map.type_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1405,269,14,'id','language_id','1','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1338,259,0,'invoice','deleted','0','report.prompt.invoice.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1339,259,0,'invoice','is_review','0','report.prompt.invoice.is_review',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1340,259,0,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,function_name,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1341,259,1,'invoice','total','invoice.total.prompt','sum',0,1,'float',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1342,259,1,'invoice','create_datetime','2004-01-01','invoice.create_date',0,0,'date','>=',0,0,0,0,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1343,259,2,'invoice','create_datetime','2005-01-01','invoice.create_date',0,0,'date','<',0,0,0,0,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1406,270,1,'payment','id','report.prompt.payment.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1407,270,2,'payment','id','','payment.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1408,270,3,'base_user','user_name','','user.prompt.username',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1409,270,4,'payment','attempt','','payment.attempt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1410,270,5,'payment','result_id','','payment.resultId',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1411,270,6,'payment','amount','','payment.amount',1,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1412,270,8,'payment','create_datetime','2005-1-1','payment.createDate',1,1,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1413,270,8,'payment','create_datetime','2005-2-1','payment.createDate',0,0,'date','<',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1414,270,8,'payment','payment_date','payment.date',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1415,270,9,'payment','payment_date',1,'payment.date',1,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1416,270,9,'payment','method_id',2,'1','payment.methodId',1,1,'integer','>',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1417,270,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1418,270,12,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1344,260,1,'invoice','id','report.prompt.invoice.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1345,260,2,'invoice','id','','invoice.id.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1346,260,2,'invoice','public_number','','invoice.number.prompt',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1347,260,3,'base_user','user_name','','user.prompt.username',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1348,260,4,'invoice','create_datetime',1,'2005-1-1','invoice.create_date',1,1,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1349,260,5,'invoice','create_datetime','2005-1-31','invoice.create_date',0,0,'date','<=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1350,260,6,'invoice','billing_process_id','','process.external.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1351,260,7,'invoice','delegated_invoice_id','','invoice.delegated.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1352,260,8,'invoice','due_date','invoice.dueDate.prompt',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1353,260,9,'invoice','due_date','invoice.dueDate.prompt',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1354,260,10,'currency','symbol','currency.external.prompt.name',0,0,'string',1,1,1,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1355,260,11,'invoice','total','','invoice.total.prompt','sum',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1356,260,12,'invoice','payment_attempts','','invoice.attempts.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1357,260,13,'invoice','to_process','','invoice.is_payable',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1358,260,14,'invoice','balance','','invoice.balance.prompt','sum',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,function_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1359,260,15,'invoice','carried_balance','','invoice.carriedBalance.prompt','sum',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1360,260,16,'invoice','deleted','0','report.prompt.invoice.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1361,260,17,'invoice','is_review','0','report.prompt.invoice.is_review',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1362,260,18,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1363,260,99,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1419,270,12,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1420,270,12,'id','content','payment.method',1,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1421,270,12,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1422,270,13,'id2','content','payment.result',1,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1423,270,14,'id','language_id','1','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1491,281,8,'payment','create_datetime','2005-2-1','payment.createDate',0,0,'date','<',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1492,281,8,'payment','payment_date','payment.date',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1493,281,9,'payment','payment_date',1,'payment.date',1,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1494,281,9,'payment','method_id',2,'4','payment.methodId',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1495,281,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1496,281,12,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1497,281,12,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1498,281,12,'id','content','payment.method',1,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1499,281,12,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1500,281,13,'id2','content','payment.result',1,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1501,281,14,'id','language_id','1','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1574,309,8,'payment','create_datetime','2005-1-1','payment.createDate',1,1,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1424,271,1,'payment','id','report.prompt.payment.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1425,271,2,'payment','id','','payment.id',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1426,271,3,'base_user','user_name','','user.prompt.username',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1427,271,4,'payment','attempt','','payment.attempt',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1428,271,5,'payment','result_id','','payment.resultId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1429,271,6,'payment','amount','','payment.amount',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1430,271,8,'payment','create_datetime','2005-04-12','payment.createDate',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1431,271,8,'payment','create_datetime','payment.createDate',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1432,271,8,'payment','payment_date','payment.date',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1433,271,9,'payment','payment_date','payment.date',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1434,271,9,'payment','method_id','','payment.methodId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1435,271,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1436,271,12,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1437,271,12,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1438,271,12,'id','content','payment.method',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1439,271,12,'base_user','entity_id','?','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1440,271,13,'id2','content','payment.result',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1441,271,14,'id','language_id','?','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1448,279,1,'payment','id','report.prompt.payment.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1449,279,2,'payment','id','','payment.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1450,279,3,'base_user','user_name','','user.prompt.username',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1451,279,4,'payment','attempt','','payment.attempt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1452,279,5,'payment','result_id','','payment.resultId',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1453,279,6,'payment','amount','','payment.amount',1,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1454,279,8,'payment','create_datetime','2005-1-1','payment.createDate',1,1,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1455,279,8,'payment','create_datetime','2005-2-1','payment.createDate',0,0,'date','<',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1388,269,1,'payment','id','report.prompt.payment.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1389,269,2,'payment','id','','payment.id',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1390,269,3,'base_user','user_name','','user.prompt.username',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1391,269,4,'payment','attempt','','payment.attempt',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1392,269,5,'payment','result_id','','payment.resultId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1393,269,6,'payment','amount','','payment.amount',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1394,269,8,'payment','create_datetime','payment.createDate',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1395,269,8,'payment','create_datetime','payment.createDate',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1396,269,8,'payment','payment_date','payment.date',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1397,269,9,'payment','payment_date','payment.date',0,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1402,269,12,'id','content','payment.method',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1456,279,8,'payment','payment_date','payment.date',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1457,279,9,'payment','payment_date',1,'payment.date',1,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1458,279,9,'payment','method_id',2,'2','payment.methodId',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1459,279,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1460,279,12,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1461,279,12,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1462,279,12,'id','content','payment.method',1,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1463,279,12,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1464,279,13,'id2','content','payment.result',1,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1465,279,14,'id','language_id','1','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1575,309,8,'payment','create_datetime','2005-2-1','payment.createDate',0,0,'date','<',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1576,309,8,'payment','payment_date','payment.date',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1577,309,9,'payment','payment_date',1,'payment.date',1,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1578,309,9,'payment','method_id',2,'1','payment.methodId',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1579,309,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1580,309,12,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1581,309,12,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1582,309,12,'id','content','payment.method',1,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1583,309,12,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1584,309,13,'id2','content','payment.result',1,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1585,309,14,'id','language_id','1','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1528,289,1,'invoice','id','report.prompt.invoice.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1529,289,2,'invoice','id','','invoice.id.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1466,280,1,'payment','id','report.prompt.payment.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1467,280,2,'payment','id','','payment.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1468,280,3,'base_user','user_name','','user.prompt.username',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1469,280,4,'payment','attempt','','payment.attempt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1470,280,5,'payment','result_id','','payment.resultId',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1471,280,6,'payment','amount','','payment.amount',1,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1472,280,8,'payment','create_datetime','2005-1-1','payment.createDate',1,1,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1473,280,8,'payment','create_datetime','2005-2-1','payment.createDate',0,0,'date','<',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1474,280,8,'payment','payment_date','payment.date',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1475,280,9,'payment','payment_date',1,'payment.date',1,1,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,order_position,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1476,280,9,'payment','method_id',2,'3','payment.methodId',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1477,280,11,'base_user','id','report.prompt.base_user.id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1478,280,12,'payment','deleted','0','report.prompt.payment.deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1479,280,12,'payment','is_refund','0','report.prompt.payment.is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1480,280,12,'id','content','payment.method',1,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1481,280,12,'base_user','entity_id','301','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1482,280,13,'id2','content','payment.result',1,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1483,280,14,'id','language_id','1','report.prompt.id.language_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1530,289,2,'invoice','public_number','','invoice.number.prompt',0,0,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1531,289,3,'base_user','user_name','','user.prompt.username',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1532,289,4,'invoice','create_datetime','2005-4-1','invoice.create_date',1,1,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1533,289,5,'invoice','create_datetime','2005-4-30','invoice.create_date',0,0,'date','<=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1534,289,6,'invoice','billing_process_id','','process.external.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1535,289,7,'invoice','delegated_invoice_id','','invoice.delegated.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1536,289,8,'invoice','due_date','invoice.dueDate.prompt',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1484,281,1,'payment','id','report.prompt.payment.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1485,281,2,'payment','id','','payment.id',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1486,281,3,'base_user','user_name','','user.prompt.username',1,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1487,281,4,'payment','attempt','','payment.attempt',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1488,281,5,'payment','result_id','','payment.resultId',1,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1489,281,6,'payment','amount','','payment.amount',1,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1490,281,8,'payment','create_datetime','2005-1-1','payment.createDate',1,1,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1588,319,1,'invoice','id','report.prompt.invoice.id',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1589,319,2,'invoice','id','','invoice.id.prompt',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1590,319,2,'invoice','public_number','','invoice.number.prompt',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1591,319,2,'invoice_line','type_id','','report.prompt.invoice_line.type_id',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1592,319,3,'invoice_line_type','description','report.prompt.invoice_line.type',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1593,319,4,'invoice_line','item_id','','report.prompt.invoice_line.item_id',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1594,319,4,'item','internal_number','','item.prompt.internalNumber',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1595,319,5,'invoice_line','description','','report.prompt.invoice_line.description',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1596,319,6,'invoice_line','amount','','report.prompt.invoice_line.amount',0,0,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1597,319,7,'invoice_line','quantity','','report.prompt.invoice_line.quantity',0,0,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1598,319,8,'invoice_line','price','','report.prompt.invoice_line.price',0,1,'float','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1599,319,9,'currency','symbol','currency.external.prompt.name',0,0,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1600,319,10,'invoice','create_datetime','invoice.createDateTime.prompt',0,0,'date','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1601,319,10,'base_user','entity_id','?','report.prompt.base_user.entity_id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1602,319,11,'invoice','create_datetime','invoice.createDateTime.prompt',0,0,'date','=',0,0,0,1,1,1);


INSERT INTO report_field (id,report_user_id,position_number,table_name,column_name,where_value,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1603,319,12,'invoice','user_id','','invoice.userId.prompt',0,0,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1604,20,1,'payment','id','',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1605,20,2,'payment','id','transaction.payment.id',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1606,20,3,'base_user','user_name','user.prompt.username',0,1,'string',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1607,20,4,'payment','attempt','payment.attempt',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1608,20,5,'payment','result_id','payment.resultId',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1609,20,6,'payment','amount','payment.amount',0,1,'float',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1610,20,7,'pa','create_datetime','transaction.createDate',0,1,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1611,20,8,'pa','create_datetime','transaction.createDate',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1625,20,20,'pa','code1','transaction.code1',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1624,20,19,'pa','transaction_id','transaction.id',0,0,'string',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1614,20,9,'payment','method_id','payment.methodId',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1615,20,10,'base_user','id',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1616,20,11,'id','content','payment.method',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1617,20,12,'base_user','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1618,20,13,'payment','deleted',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1619,20,14,'payment','is_refund',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1620,20,15,'id2','content','payment.result',0,1,'string',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1621,20,16,'id','language_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1622,20,17,'pa','processor','transaction.processor',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1623,20,18,'pa','transaction_id','transaction.id',0,1,'string','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1632,21,1,'bu','id','subscription.userId',0,1,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1633,21,2,'bu','create_datetime','subscription.createDate',0,1,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1636,21,5,'bu','subscriber_status','subscription.statusId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1637,21,6,'id1','content','subscription.subscriptionStatus',0,1,'string','=',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1641,21,10,'i','internal_number','subscription.internalNumber',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1642,21,11,'id2','content','subscription.description',0,1,'string','=',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1643,21,12,'id1','language_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1634,21,3,'bu','create_datetime','subscription.createDate',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1644,21,12,'i','id','item.id',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1679,22,1,'bu','id','subscription.userId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1680,22,2,'bu','id','subscription.userId',0,1,'integer',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1707,22,3,'bu','user_name','report.prompt.base_user.user_name',0,1,'string',1,1,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1681,22,3,'el','create_datetime','transition.createDate',0,1,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1682,22,3,'el','create_datetime','transition.createDate',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1684,22,6,'el','old_num','transition.oldNum',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1689,22,9,'i','id','item.id',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1686,22,11,'i','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1688,22,5,'id1','content','transition.userStatus',0,1,'string','=',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1685,22,10,'id2','content','subscription.description',0,1,'string','=',1,1,1,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1690,22,8,'el','old_str','transition.oldStr',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1703,23,1,'po','id','subscriptionTransition.orderId',0,1,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1691,23,1,'po','id','subscriptionTransition.orderId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1692,23,4,'bu','id','subscription.userId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1693,23,5,'el','create_datetime','subscriptionTransition.createDate',0,1,'date','>=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1694,23,6,'el','create_datetime','subscriptionTransition.createDate',0,0,'date',0,0,0,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1695,23,7,'ol1','item_id','subscriptionTransition.oldNum',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1696,23,8,'id3','content','subscriptionTransition.oldStr',0,1,'string','=',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1697,23,9,'el','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1698,23,10,'ol','item_id','subscriptionTransition.newItemId',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1700,23,12,'id1','content','subscriptionTransition.description',0,1,'string','=',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1626,20,21,'pa','code2','transaction.code2',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1627,20,22,'pa','code3','transaction.code3',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1628,20,23,'pa','avs','transaction.avs',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1629,20,24,'pa','md5','transaction.md5',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1630,20,25,'pa','approval_code','transaction.approvalCode',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1631,20,26,'pa','card_code','transaction.cardCode',0,1,'string','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1706,20,27,'pa','response_message','transaction.responseMessage',0,1,'string','=',0,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1635,21,4,'i','entity_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1687,22,12,'id1','language_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1683,22,4,'bu','subscriber_status','transition.statusId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,where_value,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1699,23,11,'id1','language_id','?',0,0,'integer','=',0,0,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1638,21,7,'po','id','subscription.orderId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1639,21,8,'po','status_id','subscription.orderStatusId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1640,21,9,'id3','content','subscription.orderStatus',0,1,'string','=',1,1,0,0,11,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1678,22,13,'po','status_id','subscription.orderStatusId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1677,22,14,'id3','content','subscription.orderStatus',0,1,'string','=',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1676,22,7,'id4','content','transition.fromStatus',0,1,'string','=',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1701,23,13,'bu','subscriber_status','subscriptionTransition.subscriberStatus',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1702,23,14,'id2','content','subscriptionTransition.subscriberStatusDesc',0,1,'string','=',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1704,23,2,'po','status_id','subscriptionTransition.orderStatusId',0,1,'integer','=',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,operator_value,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1705,23,3,'id4','content','subscriptionTransition.orderStatus',0,1,'string','=',1,1,0,0,0,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1708,3,15,'payment','is_preauth','payment.isPreauth',0,1,'integer',1,1,1,1,1,1);


INSERT INTO report_field (id,report_id,position_number,table_name,column_name,title_key,is_grouped,is_shown,data_type,functionable,selectable,ordenable,operatorable,whereable,OPTLOCK)
    VALUES (1709,20,6,'payment','amount','payment.amount',0,1,'float',0,0,0,1,1,1);


INSERT INTO report_type (id,showable,OPTLOCK)
    VALUES (1,1,1);


INSERT INTO report_type (id,showable,OPTLOCK)
    VALUES (2,1,1);


INSERT INTO report_type (id,showable,OPTLOCK)
    VALUES (3,1,1);


INSERT INTO report_type (id,showable,OPTLOCK)
    VALUES (4,1,1);


INSERT INTO report_type (id,showable,OPTLOCK)
    VALUES (5,1,1);


INSERT INTO report_type (id,showable,OPTLOCK)
    VALUES (6,1,1);


INSERT INTO report_type (id,showable,OPTLOCK)
    VALUES (7,0,1);


INSERT INTO report_type (id,showable,OPTLOCK)
    VALUES (8,1,1);


INSERT INTO report_type (id,showable,OPTLOCK)
    VALUES (9,1,1);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (1,1);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (2,2);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (3,3);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (4,1);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (5,4);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (6,2);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (7,3);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (8,4);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (9,1);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (10,2);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (10,5);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (11,2);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (11,5);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (12,7);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (13,7);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (14,7);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (15,6);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (16,6);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (17,2);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (18,8);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (19,9);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (20,3);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (21,8);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (22,8);


INSERT INTO report_type_map (report_id,type_id)
    VALUES (23,8);


INSERT INTO role (id)
    VALUES (1);


INSERT INTO role (id)
    VALUES (2);


INSERT INTO role (id)
    VALUES (3);


INSERT INTO role (id)
    VALUES (4);


INSERT INTO role (id)
    VALUES (5);


INSERT INTO generic_status_type (id)
    VALUES ('order_line_provisioning_status');


INSERT INTO generic_status_type (id)
    VALUES ('order_status');


INSERT INTO generic_status_type (id)
    VALUES ('subscriber_status');


INSERT INTO generic_status_type (id)
    VALUES ('user_status');


INSERT INTO generic_status_type (id)
    VALUES ('invoice_status');


INSERT INTO generic_status_type (id)
    VALUES ('mediation_record_status');


INSERT INTO generic_status_type (id)
    VALUES ('process_run_status');


INSERT INTO generic_status (id,dtype,status_value,can_login)
    VALUES (1,'user_status',1,1);


INSERT INTO generic_status (id,dtype,status_value,can_login)
    VALUES (2,'user_status',2,1);


INSERT INTO generic_status (id,dtype,status_value,can_login)
    VALUES (3,'user_status',3,1);


INSERT INTO generic_status (id,dtype,status_value,can_login)
    VALUES (4,'user_status',4,1);


INSERT INTO generic_status (id,dtype,status_value,can_login)
    VALUES (5,'user_status',5,0);


INSERT INTO generic_status (id,dtype,status_value,can_login)
    VALUES (6,'user_status',6,0);


INSERT INTO generic_status (id,dtype,status_value,can_login)
    VALUES (7,'user_status',7,0);


INSERT INTO generic_status (id,dtype,status_value,can_login)
    VALUES (8,'user_status',8,0);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (9,'subscriber_status',1);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (10,'subscriber_status',2);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (11,'subscriber_status',3);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (12,'subscriber_status',4);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (13,'subscriber_status',5);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (14,'subscriber_status',6);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (15,'subscriber_status',7);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (16,'order_status',1);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (17,'order_status',2);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (18,'order_status',3);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (19,'order_status',4);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (20,'order_line_provisioning_status',1);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (21,'order_line_provisioning_status',2);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (22,'order_line_provisioning_status',3);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (23,'order_line_provisioning_status',4);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (24,'order_line_provisioning_status',5);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (25,'order_line_provisioning_status',6);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (26,'invoice_status',1);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (27,'invoice_status',2);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (28,'invoice_status',3);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (29,'mediation_record_status',1);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (30,'mediation_record_status',2);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (31,'mediation_record_status',3);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (32,'mediation_record_status',4);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (33,'process_run_status',1);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (34,'process_run_status',2);


INSERT INTO generic_status (id,dtype,status_value)
    VALUES (35,'process_run_status',3);


